﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MyClass;
using System.Data;
using System.Data.OracleClient;

using System.Globalization;
using System.Threading;

public partial class ShowPendingSanctionList : System.Web.UI.Page
{
    OracleConnection ocon = new OracleConnection(); string myQ = "";
    OracleDataAdapter da; DataSet ds; string userid = "", map_userid="";
    CultureInfo hindi = new CultureInfo("hi-IN");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["emp_code"] != null && Session["emp_code"].ToString() != "")
        {
            userid = Session["emp_code"].ToString();
        }
        if (Session["emp_code_map"] != null && Session["emp_code_map"].ToString() != "")
        {
            map_userid = Session["emp_code_map"].ToString();
        }
        
        if (!IsPostBack)
        {
            getdata();
            ds = CommonFunc.GetEntity1( userid);
            ddlEntity.Items.Clear(); ddlEntity.Items.Add(new ListItem("--Select--", "0"));
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                ddlEntity.Items.Add(new ListItem(ds.Tables[0].Rows[k]["LEGAL_NAME"].ToString(), ds.Tables[0].Rows[k]["ENTITY_CODE"].ToString()));
            }
           
            ds = CommonFunc.GetDeptbyEmp(userid);
            ddlDept.Items.Clear(); ddlDept.Items.Add(new ListItem("--Select--", "0"));
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                ddlDept.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["DEPARTMENT_CODE"].ToString()));
            }
        }
    }

    protected override void InitializeCulture()
    {
        //CultureInfo ci = new CultureInfo("en-IN");
        hindi.NumberFormat.CurrencySymbol = "₹";
        Thread.CurrentThread.CurrentCulture = hindi;

        base.InitializeCulture();
    }
    protected void getdata()
    {
        ocon = CommonFunc.con();
        string qry = "select distinct SNS_RECID, (SELECT LEGAL_NAME FROM OC_ENTITY B where b.ENTITY_CODE = m.ENTITY_CODE)  ENTITY_CODE,m.sANCTION_NO,to_char(m.SANCTION_DATE,'dd/MM/yyyy')SANCTION_DATE,FISCAL_YEAR, ";
        qry += " (select DESCRIPTION from OC_SBU  where status='A' and SBU_CODE= m.SBU_CODE) SBU_CODE,  (SELECT DEPARTMENT_DESC FROM ALL_DEPARTMENTS where DEPARTMENT_CODE = DEPT_CODE AND COMPANY = 'DS') DEPT_CODE, ";
        qry += " (SELECT  B.FUNC_DESC    FROM PROJECTS A, HRM_FUNCTION B, HRM_MAPPING_DEPT_FUNCTIONS C WHERE A.COMPANY = 'DS' AND A.HRIS_FUNCTION_CODE = B.FUNC_CODE AND A.STATUS  =  'A' AND A.HRIS_FUNCTION_CODE = C.FUNC_CODE  and C.DEPT_CODE= m.DEPT_CODE and A.PROJECT  = m.PROJECT) PROJECT, ";
        //--PROJECT,    --HRIS_FUNCTION_CODE,
        qry += " VERSION_NO,m.HIERARCHY_CODE,SANCTION_SOUGHT_FOR,round(TOTAL_AMOUNT,0) TOTAL_AMOUNT,BACKGROUD_INFO,CRITICAL_ISSUES_DETAIL,STATUS,CREATED_BY,CREATED_ON ";
        qry += " From SN_SANCTIONS  m , SN_SANCTION_APPROVALS a  where  m.current_status =  a.S_NO   ";
        qry += "  and  m.HIERARCHY_CODE=   a.  HIERARCHY_CODE  and m.SANCTION_NO = a.SANCTION_NO   and m.ENTITY_CODE = a.ENTITY_CODE    and emp_code='" + userid + "' and status='P' and approved_by is null ";

        if (map_userid != "")
        {
            qry = "select distinct SNS_RECID, (SELECT LEGAL_NAME FROM OC_ENTITY B where b.ENTITY_CODE = m.ENTITY_CODE)  ENTITY_CODE,m.sANCTION_NO,to_char(m.SANCTION_DATE,'dd/MM/yyyy')SANCTION_DATE,FISCAL_YEAR, ";
            qry += " (select DESCRIPTION from OC_SBU  where status='A' and SBU_CODE= m.SBU_CODE) SBU_CODE,  (SELECT DEPARTMENT_DESC FROM ALL_DEPARTMENTS where DEPARTMENT_CODE = DEPT_CODE AND COMPANY = 'DS') DEPT_CODE, ";
            qry += " (SELECT  B.FUNC_DESC    FROM PROJECTS A, HRM_FUNCTION B, HRM_MAPPING_DEPT_FUNCTIONS C WHERE A.COMPANY = 'DS' AND A.HRIS_FUNCTION_CODE = B.FUNC_CODE AND A.STATUS  =  'A' AND A.HRIS_FUNCTION_CODE = C.FUNC_CODE  and C.DEPT_CODE= m.DEPT_CODE and A.PROJECT  = m.PROJECT) PROJECT, ";
            //--PROJECT,    --HRIS_FUNCTION_CODE,
            qry += " VERSION_NO,m.HIERARCHY_CODE,SANCTION_SOUGHT_FOR,round(TOTAL_AMOUNT,0) TOTAL_AMOUNT,BACKGROUD_INFO,CRITICAL_ISSUES_DETAIL,STATUS,CREATED_BY,CREATED_ON ";
            qry += " From SN_SANCTIONS  m , SN_SANCTION_APPROVALS a  where  m.current_status =  a.S_NO and a.SKIPPED ='Y' ";
            qry += "  and  m.HIERARCHY_CODE=   a.  HIERARCHY_CODE  and m.SANCTION_NO = a.SANCTION_NO   and m.ENTITY_CODE = a.ENTITY_CODE    and (emp_code='" + userid + "' or emp_code='" + map_userid + "') and status='P' and approved_by is null order by m.SANCTION_NO";

        }
        try
        {
            ocon = CommonFunc.con();
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);//SNS_RECID  ENTITY_CODE sANCTION_NO SANCTION_DATE SBU_CODE PROJECT TOTAL_AMOUNT
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvData.DataSource = ds;
                gvData.DataBind();
            }
        }
        catch (Exception ex)
        {
            CommonFunc.ShowAlert("Error " + ex.Message);
        }
    }
    protected void gvData_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "view")
        {
            Response.Redirect("SanctionDetails.aspx?sid=" + e.CommandArgument.ToString());
        }
        if (e.CommandName == "app")
        {
            Response.Redirect("SDetails.aspx?sid=" + e.CommandArgument.ToString());
        }
    }
    protected void ddlouCode_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void ddlSBU_SelectedIndexChanged(object sender, EventArgs e)
    {
        ds = CommonFunc.GetUNITbyEmp("DSL", ddlSBU.SelectedValue, userid);
        ddlouCode.Items.Clear(); ddlouCode.Items.Add(new ListItem("--Select--", "0"));

        for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
        {
            ddlouCode.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["OU_CODE"].ToString()));

        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        ocon = CommonFunc.con();
        string qry = "select distinct SNS_RECID, (SELECT LEGAL_NAME FROM OC_ENTITY B where b.ENTITY_CODE = m.ENTITY_CODE)  ENTITY_CODE,m.sANCTION_NO,to_char(m.SANCTION_DATE,'dd/MM/yyyy')SANCTION_DATE,FISCAL_YEAR, ";
        qry += " (select DESCRIPTION from OC_SBU  where status='A' and SBU_CODE= m.SBU_CODE) SBU_CODE,  (SELECT DEPARTMENT_DESC FROM ALL_DEPARTMENTS where DEPARTMENT_CODE = DEPT_CODE AND COMPANY = 'DS') DEPT_CODE, ";
        qry += " (SELECT  B.FUNC_DESC    FROM PROJECTS A, HRM_FUNCTION B, HRM_MAPPING_DEPT_FUNCTIONS C WHERE A.COMPANY = 'DS' AND A.HRIS_FUNCTION_CODE = B.FUNC_CODE AND A.STATUS  =  'A' AND A.HRIS_FUNCTION_CODE = C.FUNC_CODE  and C.DEPT_CODE= m.DEPT_CODE and A.PROJECT  = m.PROJECT) PROJECT, ";
        //--PROJECT,    --HRIS_FUNCTION_CODE,
        qry += " VERSION_NO,m.HIERARCHY_CODE,SANCTION_SOUGHT_FOR,round(TOTAL_AMOUNT,0) TOTAL_AMOUNT,BACKGROUD_INFO,CRITICAL_ISSUES_DETAIL,STATUS,CREATED_BY,CREATED_ON ";
        qry += " From SN_SANCTIONS  m , SN_SANCTION_APPROVALS a  where  m.current_status =  a.S_NO  ";
        qry += "  and  m.HIERARCHY_CODE=   a.  HIERARCHY_CODE  and m.SANCTION_NO = a.SANCTION_NO   and m.ENTITY_CODE = a.ENTITY_CODE    and emp_code='" + userid + "' and status='P' and approved_by is null ";

        if (map_userid != "")
        {
            qry = "select distinct SNS_RECID, (SELECT LEGAL_NAME FROM OC_ENTITY B where b.ENTITY_CODE = m.ENTITY_CODE)  ENTITY_CODE,m.sANCTION_NO,to_char(m.SANCTION_DATE,'dd/MM/yyyy')SANCTION_DATE,FISCAL_YEAR, ";
            qry += " (select DESCRIPTION from OC_SBU  where status='A' and SBU_CODE= m.SBU_CODE) SBU_CODE,  (SELECT DEPARTMENT_DESC FROM ALL_DEPARTMENTS where DEPARTMENT_CODE = DEPT_CODE AND COMPANY = 'DS') DEPT_CODE, ";
            qry += " (SELECT  B.FUNC_DESC    FROM PROJECTS A, HRM_FUNCTION B, HRM_MAPPING_DEPT_FUNCTIONS C WHERE A.COMPANY = 'DS' AND A.HRIS_FUNCTION_CODE = B.FUNC_CODE AND A.STATUS  =  'A' AND A.HRIS_FUNCTION_CODE = C.FUNC_CODE  and C.DEPT_CODE= m.DEPT_CODE and A.PROJECT  = m.PROJECT) PROJECT, ";
            //--PROJECT,    --HRIS_FUNCTION_CODE,
            qry += " VERSION_NO,m.HIERARCHY_CODE,SANCTION_SOUGHT_FOR,round(TOTAL_AMOUNT,0) TOTAL_AMOUNT,BACKGROUD_INFO,CRITICAL_ISSUES_DETAIL,STATUS,CREATED_BY,CREATED_ON ";
            qry += " From SN_SANCTIONS  m , SN_SANCTION_APPROVALS a  where  m.current_status =  a.S_NO  ";
            qry += "  and  m.HIERARCHY_CODE=   a.  HIERARCHY_CODE  and m.SANCTION_NO = a.SANCTION_NO   and m.ENTITY_CODE = a.ENTITY_CODE    and (emp_code='" + userid + "' or emp_code='" + map_userid + "') and status='P' and approved_by is null ";

        }
        if (ddlSBU.SelectedIndex > 0)
        {
            qry += " and m.SBU_CODE='" + ddlSBU.SelectedValue + "' ";
        }
        if (ddlDept.SelectedIndex > 0)
        {
            qry += " and m.DEPT_CODE='" + ddlDept.SelectedValue + "' ";
        }
        if (txtSanc.Text != "")
        {
            qry += " and m.sANCTION_NO like '%" + txtSanc.Text + "%' ";
        }
        if (txtAmtFrom.Text != "")
        {
            qry += " and m.TOTAL_AMOUNT >= '" + txtAmtFrom.Text + "' ";
        }
        if (txtAmtTo.Text != "")
        {
            qry += " and m.TOTAL_AMOUNT <= '" + txtAmtTo.Text + "' ";
        }
        if (ddlouCode.SelectedIndex > 0)
        {
            string c = ddlouCode.SelectedValue;
            qry += " and '" + c + "' in (select ou_code from sn_sanctions_details where parent_recid= m.SNS_RECID ) ";
        }
        qry += " order by m.SANCTION_NO ";
        try
        {
            ocon = CommonFunc.con();
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);//SNS_RECID  ENTITY_CODE sANCTION_NO SANCTION_DATE SBU_CODE PROJECT TOTAL_AMOUNT
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvData.DataSource = ds;
                gvData.DataBind();
            }
        }
        catch (Exception ex)
        {
            CommonFunc.ShowAlert("Error " + ex.Message);
        }
    }
    protected void ddlEntity_SelectedIndexChanged(object sender, EventArgs e)
    {
        ds = CommonFunc.GetSBU1(ddlEntity.SelectedValue, userid);
        ddlSBU.Items.Clear(); ddlSBU.Items.Add(new ListItem("--Select--", "0"));
        for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
        {
            ddlSBU.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["SBU_CODE"].ToString()));
        }
    }
}