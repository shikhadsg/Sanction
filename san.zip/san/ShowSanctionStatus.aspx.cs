﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MyClass;
using System.Data;
using System.Data.OracleClient;
using System.Globalization;
using System.Threading;

public partial class ShowSanctionStatus : System.Web.UI.Page
{
    OracleConnection ocon = new OracleConnection(); string myQ = "";
    OracleDataAdapter da; DataSet ds; string userid = "";
    CultureInfo hindi = new CultureInfo("hi-IN");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["emp_code"] != null && Session["emp_code"].ToString() != "")
        {
            userid = Session["emp_code"].ToString();
            //email = Session["email"].ToString();
        }
        else { Response.Redirect("login.aspx"); }
        if (!IsPostBack)
        {
            getdata();

            ds = CommonFunc.GetSBU1("DSL",userid);
            ddlSBU.Items.Clear(); ddlSBU.Items.Add(new ListItem("--Select--", "0"));
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                ddlSBU.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["SBU_CODE"].ToString()));
            }
            ds = CommonFunc.GetDeptbyEmp(userid);
            ddlDept.Items.Clear(); ddlDept.Items.Add(new ListItem("--Select--", "0"));
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                ddlDept.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["DEPARTMENT_CODE"].ToString()));
            }
            ViewState["SortColumn"] = "ASC";
        }
    }

    protected override void InitializeCulture()
    {
        //CultureInfo ci = new CultureInfo("en-IN");
        hindi.NumberFormat.CurrencySymbol = "₹";
        Thread.CurrentThread.CurrentCulture = hindi;

        base.InitializeCulture();
    }

    protected void getdata()
    {
        ocon = CommonFunc.con();
        string qry = "select SNS_RECID, (SELECT LEGAL_NAME FROM OC_ENTITY B where b.ENTITY_CODE = m.ENTITY_CODE)  ENTITY_CODE,  ";
        // qry += " sANCTION_NO, ";
        // qry += " to_char(SANCTION_DATE,'dd/MM/yyyy')SANCTION_DATE, current_status, 'Yet To be Approve by ' ||(select (select title|| ' ' || employee_name from hrm_employee where emp_code=a.emp_code) emp_code from SN_SANCTION_APPROVALS a  where  m.current_status =  a.S_NO and a.PARENT_RECID= m.SNS_RECID) curr_status, ";
        // qry += " FISCAL_YEAR,  (select DESCRIPTION from OC_SBU  where status='A' and SBU_CODE= m.SBU_CODE) SBU_CODE, ";
        // qry += " (SELECT DEPARTMENT_DESC FROM ALL_DEPARTMENTS where DEPARTMENT_CODE = DEPT_CODE AND COMPANY = 'DS') DEPT_CODE, ";
        // qry += " (SELECT  B.FUNC_DESC    FROM PROJECTS A, HRM_FUNCTION B, HRM_MAPPING_DEPT_FUNCTIONS C WHERE A.COMPANY = 'DS' AND A.HRIS_FUNCTION_CODE = B.FUNC_CODE AND A.STATUS  =  'A' AND A.HRIS_FUNCTION_CODE = C.FUNC_CODE  and C.DEPT_CODE= m.DEPT_CODE and A.PROJECT  = m.PROJECT) PROJECT, ";
        // qry += " VERSION_NO,HIERARCHY_CODE,SANCTION_SOUGHT_FOR,TOTAL_AMOUNT,BACKGROUD_INFO,CRITICAL_ISSUES_DETAIL,STATUS,CREATED_BY,CREATED_ON ";
        // qry += " From SN_SANCTIONS  m where  created_by='"+userid+"' and status='P'";

        qry = "select distinct SNS_RECID, (SELECT LEGAL_NAME FROM OC_ENTITY B where b.ENTITY_CODE = m.ENTITY_CODE)  ENTITY_CODE, ";
        qry += " m.sANCTION_NO, ";
        qry += " to_char(SANCTION_DATE,'dd/MM/yyyy')SANCTION_DATE, current_status, 'Yet To be Aprroved by ' ||(select (select title|| ' ' || employee_name from hrm_employee where emp_code=a.emp_code) emp_code from SN_SANCTION_APPROVALS a  where  m.current_status =  a.S_NO and a.PARENT_RECID= m.SNS_RECID and approved_by is null and rownum=1) curr_status, ";
        qry += " FISCAL_YEAR,  (select DESCRIPTION from OC_SBU  where status='A' and SBU_CODE= m.SBU_CODE) SBU_CODE, ";
        qry += " (SELECT DEPARTMENT_DESC FROM ALL_DEPARTMENTS where DEPARTMENT_CODE = DEPT_CODE AND COMPANY = 'DS') DEPT_CODE, ";
        qry += " (SELECT  B.FUNC_DESC    FROM PROJECTS A, HRM_FUNCTION B, HRM_MAPPING_DEPT_FUNCTIONS C WHERE A.COMPANY = 'DS' AND A.HRIS_FUNCTION_CODE = B.FUNC_CODE AND A.STATUS  =  'A' AND A.HRIS_FUNCTION_CODE = C.FUNC_CODE  and C.DEPT_CODE= m.DEPT_CODE and A.PROJECT  = m.PROJECT) PROJECT, ";
        qry += " VERSION_NO,m.HIERARCHY_CODE,m.SANCTION_SOUGHT_FOR,m.TOTAL_AMOUNT,m.BACKGROUD_INFO,m.CRITICAL_ISSUES_DETAIL,m.STATUS,m.CREATED_BY,m.CREATED_ON, case status when 'P' then 'In Process' when 'A' then 'Approved' when 'E' then 'Re-Intiated' when 'R' then 'Rejected' end status1 ";
        qry += " From SN_SANCTIONS  m, SN_SANCTION_APPROVALS a where  (m.created_by='" + userid + "' or a.EMP_CODE= '" + userid + "' ) and status='P' and m.current_status =  a.S_NO and a.PARENT_RECID= m.SNS_RECID order by to_date(SANCTION_DATE,'dd/MM/yyyy') desc ";
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
        DataSet ds = new DataSet();
        da.Fill(ds);//SNS_RECID  ENTITY_CODE sANCTION_NO SANCTION_DATE SBU_CODE PROJECT TOTAL_AMOUNT
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvData.DataSource = ds;
            gvData.DataBind();
        }


        qry = "select distinct SNS_RECID, (SELECT LEGAL_NAME FROM OC_ENTITY B where b.ENTITY_CODE = m.ENTITY_CODE)  ENTITY_CODE, ";
        qry += " m.sANCTION_NO, SANCTION_DATE,LAST_UPD_ON,";
        qry += " to_char(SANCTION_DATE,'dd/MM/yyyy')SANCTION_DATE1, current_status, ";//'Yet To be Aprrov by ' ||(select (select title|| ' ' || employee_name from hrm_employee where emp_code=a.emp_code) emp_code from SN_SANCTION_APPROVALS a  where  m.current_status =  a.S_NO and a.PARENT_RECID= m.SNS_RECID) curr_status, 
        qry += " FISCAL_YEAR,  (select DESCRIPTION from OC_SBU  where status='A' and SBU_CODE= m.SBU_CODE) SBU_CODE, ";
        qry += " (SELECT DEPARTMENT_DESC FROM ALL_DEPARTMENTS where DEPARTMENT_CODE = DEPT_CODE AND COMPANY = 'DS') DEPT_CODE, ";
        qry += " (SELECT  B.FUNC_DESC    FROM PROJECTS A, HRM_FUNCTION B, HRM_MAPPING_DEPT_FUNCTIONS C WHERE A.COMPANY = 'DS' AND A.HRIS_FUNCTION_CODE = B.FUNC_CODE AND A.STATUS  =  'A' AND A.HRIS_FUNCTION_CODE = C.FUNC_CODE  and C.DEPT_CODE= m.DEPT_CODE and A.PROJECT  = m.PROJECT) PROJECT, ";
        qry += " VERSION_NO,m.HIERARCHY_CODE,m.SANCTION_SOUGHT_FOR,m.TOTAL_AMOUNT,m.BACKGROUD_INFO,m.CRITICAL_ISSUES_DETAIL,m.STATUS,m.CREATED_BY,m.CREATED_ON, case status when 'P' then 'In Process' when 'A' then 'Approved' when 'E' then 'Re-Intiated' when 'R' then 'Rejected' when 'I' then 'Blocked'  end status1 ";
        qry += " From SN_SANCTIONS  m, SN_SANCTION_APPROVALS a where  (m.created_by='" + userid + "' or a.EMP_CODE= '" + userid + "' )  and a.PARENT_RECID= m.SNS_RECID and m.status not in ('N','C') order by LAST_UPD_ON desc  ";
         da = new OracleDataAdapter(qry, ocon);
         ds = new DataSet();
        da.Fill(ds);//SNS_RECID  ENTITY_CODE sANCTION_NO SANCTION_DATE SBU_CODE PROJECT TOTAL_AMOUNT
        if (ds.Tables[0].Rows.Count > 0)
        {
            GridView1.DataSource = ds;
            GridView1.DataBind();
            Session["ds"] = ds;
        }
    }
    protected void gvData_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "view")
        {
            Response.Redirect("SanctionFormat.aspx?sid=" + e.CommandArgument.ToString());
        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        ocon = CommonFunc.con();
        string qry = "select SNS_RECID, (SELECT LEGAL_NAME FROM OC_ENTITY B where b.ENTITY_CODE = m.ENTITY_CODE)  ENTITY_CODE,  ";

        qry = "select distinct SNS_RECID, (SELECT LEGAL_NAME FROM OC_ENTITY B where b.ENTITY_CODE = m.ENTITY_CODE)  ENTITY_CODE, ";
        qry += " m.sANCTION_NO, SANCTION_DATE,LAST_UPD_ON,";
        qry += " to_char(SANCTION_DATE,'dd/MM/yyyy')SANCTION_DATE1, current_status, ";//'Yet To be Aprrov by ' ||(select (select title|| ' ' || employee_name from hrm_employee where emp_code=a.emp_code) emp_code from SN_SANCTION_APPROVALS a  where  m.current_status =  a.S_NO and a.PARENT_RECID= m.SNS_RECID) curr_status, 
        qry += " FISCAL_YEAR,  (select DESCRIPTION from OC_SBU  where status='A' and SBU_CODE= m.SBU_CODE) SBU_CODE, ";
        qry += " (SELECT DEPARTMENT_DESC FROM ALL_DEPARTMENTS where DEPARTMENT_CODE = DEPT_CODE AND COMPANY = 'DS') DEPT_CODE, ";
        qry += " (SELECT  B.FUNC_DESC    FROM PROJECTS A, HRM_FUNCTION B, HRM_MAPPING_DEPT_FUNCTIONS C WHERE A.COMPANY = 'DS' AND A.HRIS_FUNCTION_CODE = B.FUNC_CODE AND A.STATUS  =  'A' AND A.HRIS_FUNCTION_CODE = C.FUNC_CODE  and C.DEPT_CODE= m.DEPT_CODE and A.PROJECT  = m.PROJECT) PROJECT, ";
        qry += " VERSION_NO,m.HIERARCHY_CODE,m.SANCTION_SOUGHT_FOR,m.TOTAL_AMOUNT,m.BACKGROUD_INFO,m.CRITICAL_ISSUES_DETAIL,m.STATUS,m.CREATED_BY,m.CREATED_ON, case status when 'P' then 'In Process' when 'A' then 'Approved' when 'E' then 'Re-Intiated' when 'R' then 'Rejected' when 'I' then 'Blocked' end status1 ";
        qry += " From SN_SANCTIONS  m, SN_SANCTION_APPROVALS a where  (m.created_by='" + userid + "' or a.EMP_CODE= '" + userid + "' )  and a.PARENT_RECID= m.SNS_RECID and m.status not in ('N','C') ";
         
        
        if (ddlSBU.SelectedIndex > 0)
        {
            qry += " and m.SBU_CODE='" + ddlSBU.SelectedValue + "' ";
        }
        if (ddlDept.SelectedIndex > 0)
        {
            qry += " and m.DEPT_CODE='" + ddlDept.SelectedValue + "' ";
        }
        if (txtSanc.Text != "")
        {
            qry += " and m.sANCTION_NO like '%" + txtSanc.Text + "%' ";
        }
        if (txtAmtFrom.Text != "")
        {
            qry += " and m.TOTAL_AMOUNT >= '" + txtAmtFrom.Text + "' ";
        }
        if (txtAmtTo.Text != "")
        {
            qry += " and m.TOTAL_AMOUNT <= '" + txtAmtTo.Text + "' ";
        }
        if (ddlouCode.SelectedIndex > 0)
        {
            string c = ddlouCode.SelectedValue;
            qry += " and '" + c + "' in (select ou_code from sn_sanctions_details where parent_recid= m.SNS_RECID ) ";
        }

        qry += "   order by LAST_UPD_ON desc ";
        DataSet ds = new DataSet();
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
        da.Fill(ds);//SNS_RECID  ENTITY_CODE sANCTION_NO SANCTION_DATE SBU_CODE PROJECT TOTAL_AMOUNT 5504105
        if (ds.Tables[0].Rows.Count > 0)
        {
            GridView1.DataSource = ds;
            GridView1.DataBind();
            GridView1.Visible = true;
            Session["ds"] = ds;
        }
        else
        {
            GridView1.Visible = false;
            CommonFunc.ShowAlert("No Record Found.");
        }
    }
    protected void ddlouCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }
    protected void ddlSBU_SelectedIndexChanged(object sender, EventArgs e)
    {
        ds = CommonFunc.GetUNITbyEmp("DSL", ddlSBU.SelectedValue, userid);
        ddlouCode.Items.Clear(); ddlouCode.Items.Add(new ListItem("--Select--", "0"));

        for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
        {
            ddlouCode.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["OU_CODE"].ToString()));
           
        }
    }
    protected void GridView1_Sorting(object sender, GridViewSortEventArgs e)
    {
        DataTable dtSortTable = new DataTable(); ;
        DataSet dtSort = (DataSet)Session["ds"];//(DataSet)GridView1.DataSource;

        if (dtSort != null && dtSort.Tables.Count > 0)
            dtSortTable = dtSort.Tables[0];

        if (dtSortTable != null)
        {
            DataView dvSortedView = new DataView(dtSortTable);

            dvSortedView.Sort = e.SortExpression + " " + getSortDirectionString(e.SortDirection); //+ " " +  getSortDirectionString(e.SortDirection)

            GridView1.DataSource = dvSortedView;
            GridView1.DataBind();
        }
    }
    private string getSortDirectionString(SortDirection sortDirection)
    {
        string newSortDirection = String.Empty;
        newSortDirection = ViewState["SortColumn"].ToString();
       
        if (ViewState["SortColumn"].ToString() == "DESC")
            ViewState["SortColumn"] = "ASC";
        else
            ViewState["SortColumn"] = "DESC";
        newSortDirection = ViewState["SortColumn"].ToString();
        return newSortDirection;
    }
}