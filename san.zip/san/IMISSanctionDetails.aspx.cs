﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MyClass;
using System.Data;
using System.Data.OracleClient;

public partial class IMISSanctionDetails : System.Web.UI.Page
{
    OracleConnection ocon = new OracleConnection(); string qry = ""; string email = "";
    OracleDataAdapter da; DataSet ds; string userid = ""; string recid = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        //if(Session["recid"] !=null && Session["recid"].ToString()!="")
        //{
        //    recid = Session["recid"].ToString();
        //}
        //if (Session["emp_code"] != null && Session["emp_code"].ToString() != "")
        //{
        //    userid = Session["emp_code"].ToString();
        //    email = Session["email"].ToString();
        //}
           
        //else { Server.Transfer("login.aspx"); }
        if (Request.QueryString["sid"] != null && Request.QueryString["sid"].ToString() != "")
        {
            recid = Request.QueryString["sid"].ToString();
        }
        if (!IsPostBack)
        {
            ds = CommonFunc.getMasterDetail(recid,"");
            //   FISCAL_YEAR     VERSION_NO HIERARCHY_CODE  TOTAL_AMOUNT current_status          }
            if(ds.Tables[0].Rows.Count>0)
            {
                DataRow dr =ds.Tables[0].Rows[0];
                lblSancDate.Text = dr["SANCTION_DATE"].ToString();
                lblSancNo.Text = dr["SANCTION_NO"].ToString();
                lblEntity.Text = dr["ENTITY_CODE_d"].ToString();
                lblEnt.Text = dr["ENTITY_CODE"].ToString();
                lblVersion.Text = dr["VERSION_NO"].ToString();
                lblTotal.Text = dr["TOTAL_AMOUNT"].ToString();
                lblSBU.Text = dr["SBU_CODE_d"].ToString();
                lblsb.Text = dr["SBU_CODE"].ToString();
                lblDepartment.Text = dr["DEPT_CODE_d"].ToString();
                lblDept.Text = dr["DEPT_CODE"].ToString();
                lblFunction.Text = dr["PROJECT"].ToString();
                lblFyear.Text = dr["FISCAL_YEAR"].ToString();
                lblSoughtFor.Text = dr["SANCTION_SOUGHT_FOR"].ToString();
                txtback.Text = dr["BACKGROUD_INFO"].ToString();
                txtIssues.Text = dr["CRITICAL_ISSUES_DETAIL"].ToString();
                lblstatus.Text = dr["current_status"].ToString();
                getDetailData();
            }
        }
    }

    protected string gettoMailId()
    {
        int st = Convert.ToInt32(lblstatus.Text);
        st = st + 1;
        qry = "select (select email_id from hrm_employee where  emp_code = s.emp_code) mailid from SN_SANCTION_APPROVALS s where PARENT_RECID= '" + recid + "'  and S_NO= " + st;
        ocon = CommonFunc.con();
        if (ocon.State == ConnectionState.Closed)
            ocon.Open();
        OracleCommand cmd = new OracleCommand(qry, ocon);
        string toid= Convert.ToString(cmd.ExecuteScalar());
        return toid;
    }

    protected string getCreatedMailId()
    {
        int st = Convert.ToInt32(lblstatus.Text);
        st = st + 1;
        qry = "select (select email_id from hrm_employee where  emp_code = s.created_by) mailid from SN_SANCTIONS s where SNS_RECID= '" + recid + "'  and status= 'P'";
        ocon = CommonFunc.con();
        if (ocon.State == ConnectionState.Closed)
            ocon.Open();
        OracleCommand cmd = new OracleCommand(qry, ocon);
        string toid =  Convert.ToString(cmd.ExecuteScalar());
        return toid;
    }

    protected string gettoempcode()
    {
        int st = Convert.ToInt32(lblstatus.Text);
        st = st + 1;
        qry = "select   emp_code  from SN_SANCTION_APPROVALS s where PARENT_RECID= '" + recid + "'  and S_NO= " + st;
        ocon = CommonFunc.con();
        if (ocon.State == ConnectionState.Closed)
            ocon.Open();
        OracleCommand cmd = new OracleCommand(qry, ocon);
        string toid = Convert.ToString(cmd.ExecuteScalar());
        return toid;
    }

    protected void getDetailData()
    {
                        //BUDGET_AMOUNT CONSUMED_AMOUNT BALANCE_AMOUNT  

        qry = " select  SNSD_RECID,  (SELECT LEGAL_NAME FROM OC_ENTITY B WHERE status='A' and ENTITY_CODE= s.ENTITY_CODE and rownum=1) ENTITY_CODE, s.SANCTION_NO,to_char(s.SANCTION_DATE,'dd/mm/yyyy') SANCTION_DATE, ";
        qry += " (select DESCRIPTION from OC_OPERATING_UNIT o where o.ENTITY_CODE = s.ENTITY_CODE and o.OU_CODE = s.OU_CODE  ) OU_CODE, ";
        qry += "  (SELECT  B.DESCRIPTION FROM  OC_SBU_CATEGORY B WHERE  b.SBU_CODE = m.SBU_CODE and B.SBU_CATEGORY_CODE =s.SBU_CATEGORY_CODE  )SBU_CATEGORY_CODE, ";
        //--(SELECT   C.DESCRIPTION FROM  OC_BRANDS  C WHERE C.SBU_CATEGORY_CODE =  s.SBU_CATEGORY_CODE AND C.STATUS = 'A' AND EXISTS (SELECT '1' FROM OC_SBU_MAPPING D WHERE D.OU_CODE = s.OU_CODE AND D.SBU_CATEGORY_CODE = s.SBU_CATEGORY_CODE AND D.BRAND_CODE = C.BRAND_CODE AND D.STATUS = 'A'))
        qry += " (SELECT  C.DESCRIPTION FROM  OC_BRANDS C WHERE  c.SBU_CODE = m.SBU_CODE and C.BRAND_CODE = s.BRAND_CODE AND c.SBU_CATEGORY_CODE = s.SBU_CATEGORY_CODE )  BRAND_CODE, ";
        qry += " (SELECT  C.DESCRIPTION FROM  OC_PRODUCTS C WHERE  c.SBU_CODE = m.SBU_CODE and C.BRAND_CODE = s.BRAND_CODE AND c.SBU_CATEGORY_CODE = s.SBU_CATEGORY_CODE and c.PRODUCT_ID = s.PRODUCT_ID) product_ID, ";
        qry += " EXPENSE_CODE_BUDGET ||'-' || (select head_description from OC_EXPENSE_MASTER where status='A' and record_type='I' and EXPENSE_CODE_BUDGET=s.EXPENSE_CODE_BUDGET and HRIS_DEPT_CODE= s.HRIS_DEPT_CODE) EXPENSE_CODE_BUDGET, ";

        qry += " SEQ_NO,  PARTICULARS,SPECIFICATIONS,case when BUDGET_APPROVED='Y' then 'Yes' else 'No' end BUDGET_APPROVED, BUDGET_REF_NO,SANCTION_AMOUNT,BUDGET_AMOUNT,CONSUMED_AMOUNT,BALANCE_AMOUNT,BUDGET_AMOUNT_UPTO ,BALANCE_AMOUNT_UPTO,SANCTION_AMOUNT_GST ";
            qry +=" from SN_SANCTIONS_DETAILS  s,SN_SANCTIONS m where PARENT_RECID = '"+recid+"' and s. PARENT_RECID =  m.SNS_RECID ";
            ocon = CommonFunc.con(); 
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvDetail.DataSource = ds;
                gvDetail.DataBind();
                gvBudget.DataSource = ds;
                gvBudget.DataBind();
            }
            Label l = (Label)gvDetail.FooterRow.FindControl("lblTotal");
            if (l != null)
            {
                l.Text = lblTotal.Text;
            }
    }
    protected void btnEdit_Click(object sender, EventArgs e)
    {
        Response.Redirect("editSanction.aspx?sid=" + recid);
    }
    

   
    protected void getapp()
    {
        qry = " select  S_NO SNO, (select employee_name from hrm_employee where EMP_CODE= s.EMP_CODE) EmployeeName, SKIPPED Mandatory,APPROVED_BY,APPROVED_ON,REMARKS from SN_SANCTION_APPROVALS s where sanction_no= '" + lblSancNo.Text + "'";
        ocon = CommonFunc.con();
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvApproval.DataSource = ds;
            gvApproval.DataBind();
        }
    }
    protected void getAttach()
    {
        qry = " select SUBSTR(FILE_NAME,INSTR(FILE_NAME, '_',1,2 )+1 ) FILE_NAME_disp, FILE_NAME from SN_SANCTION_ATTACHMENTS where SANCTION_NO = '" + lblSancNo.Text + "'";
        ocon = CommonFunc.con();
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvAttachment.DataSource = ds;
            gvAttachment.DataBind();
        }
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        pnlApproval.Visible = true; getapp(); pnlAttachment.Visible = false;
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        pnlAttachment.Visible = true; getAttach(); pnlApproval.Visible = false;
    }
    protected void imgcloseA_Click(object sender, ImageClickEventArgs e)
    {
        pnlApproval.Visible = false;
    }
    protected void imgcloseA0_Click(object sender, ImageClickEventArgs e)
    {
        pnlAttachment.Visible = false;
    }
    protected void gvApproval_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        
    }
    protected void gvAttachment_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string path = e.CommandArgument.ToString();
        string fpath = Server.MapPath("~/SancDocs/") + e.CommandArgument.ToString(); // @"c:/abc/doc/abc1.doc";
        System.IO.FileInfo myDoc = new System.IO.FileInfo(fpath);

        Response.Clear();
        Response.ContentType = "Application/msword";
        Response.AddHeader("content-disposition", "attachment;filename=" + myDoc.Name);
        Response.AddHeader("Content-Length", myDoc.Length.ToString());
        Response.ContentType = "application/octet-stream";

        Response.WriteFile(myDoc.FullName);

        Response.End();
    }
    
    protected string mailLog(string flag, string message,string empcde, string toid)
    {
        qry="insert into SN_SANCTION_EMAIL_LOG (SNSEL_RECID,ENTITY_CODE,SANCTION_NO,PARENT_RECID,EMP_CODE,EMAIL_ID,EMAIL_SENT_ON,TO_EMP_CODE,TO_EMAIL_ID,DELIVERY_FLAG,MESSAGE) ";
        qry += " values (portal_RECID.nextval,'" + lblEnt.Text + "','" + lblSancNo.Text + "','" + recid + "','" + userid + "','" + email + "',to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + "', 'dd/mm/yyyy hh:mi:ss AM'),'" + empcde + "','" + toid + "','" + flag + "','" + message + "') ";
        return qry;
    }
}