﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MyClass;
using System.Data;
using System.Data.OracleClient;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class Change_HIERARCHY : System.Web.UI.Page
{
    //protected void Page_Load(object sender, EventArgs e)
    //{

    //}
    OracleConnection ocon = new OracleConnection();
    OracleDataAdapter da; DataSet ds; string userid = "55000";
    private void FillDropDownList1(DropDownList ddl) {
           // ArrayList arr = GetDummyData();
        ds = CommonFunc.GetEmpList(ddlDept.SelectedValue);
        for (int k = 0; k < ds.Tables[0].Rows.Count; k++ )
        {
            ddl.Items.Add(new ListItem(ds.Tables[0].Rows[k]["employee_name"].ToString(),ds.Tables[0].Rows[k]["emp_code"].ToString()));
        }
        }

        private void SetInitialRow1() {

            DataTable dt = new DataTable();
            DataRow dr = null;

            dt.Columns.Add(new DataColumn("RowNumber", typeof(string)));
            dt.Columns.Add(new DataColumn("Column1", typeof(string)));//for TextBox value 
            dt.Columns.Add(new DataColumn("Column2", typeof(string)));//for TextBox value 
            dt.Columns.Add(new DataColumn("Column3", typeof(string)));//for DropDownList selected item 
            dt.Columns.Add(new DataColumn("Column4", typeof(string)));//for DropDownList selected item 

            dr = dt.NewRow();
            dr["RowNumber"] = 1;
            dr["Column1"] = string.Empty;
            dr["Column2"] = string.Empty;
            dt.Rows.Add(dr);

            //Store the DataTable in ViewState for future reference 
            ViewState["CurrentTable"] = dt;

            //Bind the Gridview 
            gvNew.DataSource = dt;
            gvNew.DataBind();

            //After binding the gridview, we can then extract and fill the DropDownList with Data 
            DropDownList ddlEmp = (DropDownList)gvNew.Rows[0].Cells[1].FindControl("ddlEmp");
            //DropDownList ddl2 = (DropDownList)Gridview1.Rows[0].Cells[4].FindControl("DropDownList2");
            FillDropDownList1(ddlEmp);
            
        }

        private void AddNewRowToGrid1() {

            if (ViewState["CurrentTable"] != null) {

                DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
                DataRow drCurrentRow = null;

                if (dtCurrentTable.Rows.Count > 0) {
                    drCurrentRow = dtCurrentTable.NewRow();
                    drCurrentRow["RowNumber"] = dtCurrentTable.Rows.Count + 1;

                    //add new row to DataTable 
                    dtCurrentTable.Rows.Add(drCurrentRow);
                   

                    for (int i = 0; i < dtCurrentTable.Rows.Count -1; i++) {

                        DropDownList ddlEmp = (DropDownList)gvNew.Rows[i].Cells[3].FindControl("ddlEmp");
                        DropDownList ddlM = (DropDownList)gvNew.Rows[i].Cells[4].FindControl("ddlM");
                        DropDownList ddlRole = (DropDownList)gvNew.Rows[i].Cells[4].FindControl("ddlRole");

                        // Update the DataRow with the DDL Selected Items 

                        dtCurrentTable.Rows[i]["Column1"] = ddlEmp.SelectedItem.Text;
                        dtCurrentTable.Rows[i]["Column2"] = ddlM.SelectedItem.Text;
                        dtCurrentTable.Rows[i]["Column3"] = ddlRole.SelectedItem.Text;

                    }

                    //Store the current data to ViewState for future reference 
                    ViewState["CurrentTable"] = dtCurrentTable;


                    //Rebind the Grid with the current data to reflect changes 
                    gvNew.DataSource = dtCurrentTable;
                    gvNew.DataBind();
                }
            }
            else {
                Response.Write("ViewState is null");

            }
            //Set Previous Data on Postbacks 
            SetPreviousData1();
        }

        private void SetPreviousData1() {

            int rowIndex = 0;
            if (ViewState["CurrentTable"] != null) {

                DataTable dt = (DataTable)ViewState["CurrentTable"];
                if (dt.Rows.Count > 0) {

                    for (int i = 0; i < dt.Rows.Count; i++) {

                        //TextBox box1 = (TextBox)Gridview1.Rows[i].Cells[1].FindControl("TextBox1");
                        //TextBox box2 = (TextBox)Gridview1.Rows[i].Cells[2].FindControl("TextBox2");

                        DropDownList ddlEmp = (DropDownList)gvNew.Rows[i].Cells[3].FindControl("ddlEmp");
                        DropDownList ddlM = (DropDownList)gvNew.Rows[i].Cells[4].FindControl("ddlM");
                        DropDownList ddlRole = (DropDownList)gvNew.Rows[i].Cells[4].FindControl("ddlRole");

                        //Fill the DropDownList with Data 
                        FillDropDownList1(ddlEmp);
                        //FillDropDownList(ddl2);

                        if (i < dt.Rows.Count  ) {

                            //Assign the value from DataTable to the TextBox 
                            //box1.Text = dt.Rows[i]["Column1"].ToString();
                            //box2.Text = dt.Rows[i]["Column2"].ToString();

                            //Set the Previous Selected Items on Each DropDownList  on Postbacks 
                            if(dt.Rows[i]["Column1"].ToString() !="")
                            {
                            ddlEmp.ClearSelection();
                            ddlEmp.Items.FindByText(dt.Rows[i]["Column1"].ToString()).Selected = true;

                            ddlM.ClearSelection();
                            ddlM.Items.FindByText(dt.Rows[i]["Column2"].ToString()).Selected = true;

                            ddlRole.ClearSelection();
                            ddlRole.Items.FindByText(dt.Rows[i]["Column3"].ToString()).Selected = true;

                            }
                        }

                        rowIndex++;
                    }
                }
            }
        }

        protected void gvNew_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DataTable dt = (DataTable)ViewState["CurrentTable"];
                LinkButton lb = (LinkButton)e.Row.FindControl("LinkButton1");
                if (lb != null)
                {
                    if (dt.Rows.Count > 1)
                    {
                        if (e.Row.RowIndex == dt.Rows.Count - 1)
                        {
                            lb.Visible = false;
                        }
                    }
                    else
                    {
                        lb.Visible = false;
                    }
                }
            }
        }
        protected void Page_Load(object sender, EventArgs e) {
            if (!Page.IsPostBack) {
                //if (Session["emp_code"] != null && Session["emp_code"].ToString() != "")
                //{
                //    userid = Session["emp_code"].ToString();
                //}
                                
                //DEPT_CODE,DESCRIPTION
                ds = CommonFunc.GetDept();
                ddlDept.Items.Clear(); ddlDept.Items.Add("--Select--");
                ddlEntity.Items.Clear(); ddlEntity.Items.Add("--Select--");
                for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                {
                    ddlDept.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["DEPARTMENT_CODE"].ToString()));
                }
                ds = CommonFunc.GetEntity();
                for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                {
                    ddlEntity.Items.Add(new ListItem(ds.Tables[0].Rows[k]["LEGAL_NAME"].ToString(), ds.Tables[0].Rows[k]["ENTITY_CODE"].ToString()));
                }
                if (Session["dept"] != null && Session["entity"] != null)
                {
                    ddlDept.Items.FindByValue(Session["dept"].ToString()).Selected=true;
                    ddlEntity.Items.FindByValue(Session["entity"].ToString()).Selected = true;
                }
                //Session["dept"] = ddlDept.SelectedValue;
                //Session["entity"] = ddlEntity.SelectedValue;
                SetInitialRow1();
            }
        }

        protected void ButtonAdd_Click1(object sender, EventArgs e) {
            AddNewRowToGrid1();
        }

        

        protected void LinkDelete_Click1(object sender, EventArgs e) {
            LinkButton lb = (LinkButton)sender;
            GridViewRow gvRow = (GridViewRow)lb.NamingContainer;
            int rowID = gvRow.RowIndex;
            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
            //DataRow drCurrentRow = null;

            for (int i = 0; i < dtCurrentTable.Rows.Count ; i++)
            {

                DropDownList ddlEmp = (DropDownList)gvNew.Rows[i].Cells[3].FindControl("ddlEmp");
                DropDownList ddlM = (DropDownList)gvNew.Rows[i].Cells[4].FindControl("ddlM");
                DropDownList ddlRole = (DropDownList)gvNew.Rows[i].Cells[4].FindControl("ddlRole");

                // Update the DataRow with the DDL Selected Items 

                dtCurrentTable.Rows[i]["Column1"] = ddlEmp.SelectedItem.Text;
                dtCurrentTable.Rows[i]["Column2"] = ddlM.SelectedItem.Text;
                dtCurrentTable.Rows[i]["Column3"] = ddlRole.SelectedItem.Text;

            }

            //Store the current data to ViewState for future reference 
            ViewState["CurrentTable"] = dtCurrentTable;


            if (ViewState["CurrentTable"] != null) {

                DataTable dt = (DataTable)ViewState["CurrentTable"];
                if (dt.Rows.Count > 1) {
                    if (gvRow.RowIndex <= dt.Rows.Count - 1) {
                        //Remove the Selected Row data and reset row number
                        dt.Rows.Remove(dt.Rows[rowID]);
                        ResetRowID1(dt);
                    }
                }

                //Store the current data in ViewState for future reference
                ViewState["CurrentTable"] = dt;

                //Re bind the GridView for the updated data
                gvNew.DataSource = dt;
                gvNew.DataBind();
            }

            //Set Previous Data on Postbacks
            SetPreviousData1();
        }

        private void ResetRowID1(DataTable dt) {
            int rowNumber = 1;
            if (dt.Rows.Count > 0) {
                foreach (DataRow row in dt.Rows) {
                    row[0] = rowNumber;
                    rowNumber++;
                }
            }
        }
        protected void ddlDept_SelectedIndexChanged(object sender, EventArgs e)
        {
            //FillDropDownList(ddlEmp);
        }
        protected void btnCreate_Click(object sender, EventArgs e)
        {
            if ( ddlEntity.SelectedIndex > 0 && ddlSBU.SelectedIndex > 0)
            {
                //ddlDept.Enabled = false;
                //btnCreate.Enabled = false;
                string qry = "SELECT entity_code,ou_code,hierarchy_code,sbu_code,sbu_category_code,dept_code ";
                qry += ",(select description from hrm_department where dept_code=f.dept_code) dept_nm ";
                qry += ",anoop.cg$initator(snh_recid,0) initator ,anoop.cg$initator(snh_recid,1) reveiwer_1,anoop.cg$initator(snh_recid,2) reveiwer_2,anoop.cg$initator(snh_recid,3) reveiwer_3 ";
                qry += ",anoop.cg$initator(snh_recid,4) reveiwer_4 ,anoop.cg$initator(snh_recid,5) reveiwer_5,anoop.cg$initator(snh_recid,6) reveiwer_6,anoop.cg$initator(snh_recid,7) reveiwer_7 ";
                qry += ",anoop.cg$initator(snh_recid,8) reveiwer_8 ,anoop.cg$initator(snh_recid,9) reveiwer_9,anoop.cg$initator (snh_recid,10) reveiwer_10,SNH_RECID  ";
                qry += " from sn_hierarchy  f  where 1=1 ";
                if(ddlEntity.SelectedIndex >0)
                {
                    qry += " and ENTITY_CODE ='" + ddlEntity.SelectedValue + "'";
                } 
                if(ddlSBU.SelectedIndex >0)
                {
                    qry += " and SBU_CODE='" + ddlSBU.SelectedValue + "'";
                }
                if(ddlCategory.SelectedIndex>0)
                {
                    qry += " and SBU_CATEGORY_CODE='" + ddlCategory.SelectedValue + "'";
                }
                if(ddlUnit.SelectedIndex>0)
                {
                qry += " and  ou_code in ('" + ddlUnit.SelectedValue + "') ";
                }
                if (ddlDept.SelectedIndex > 0)
                {
                    qry += " and dept_code in ('" + ddlDept.SelectedValue + "') ";
                }
                
                qry += " order by OU_CODE,DEPT_CODE,snh_recid";
                ocon = CommonFunc.con();
                OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
                DataSet ds = new DataSet();
                da.Fill(ds);
                gvShow.DataSource = ds;
                gvShow.DataBind();
                SetInitialRow1();
                //btnSave.Visible = true;
            }
            else
            {
                CommonFunc.ShowAlert("Kindly select Entity, SBU, Department!!");
            }
        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            btnSave.Enabled = false;
            ocon = CommonFunc.con(); ocon.Open(); OracleTransaction trns = ocon.BeginTransaction(); ; OracleCommand cmd; string qry = "";
            try
            {

                qry = "select imis_rcid.nextval from dual";
                cmd = new OracleCommand(qry, ocon, trns);
                string rid =  cmd.ExecuteScalar().ToString();

                qry = " insert into SN_HIERARCHY_change (SNH_RECID,ENTITY_CODE,OU_CODE,SBU_CODE,SBU_CATEGORY_CODE,DEPT_CODE,HIERARCHY_CODE,Remark,STATUS,CREATED_BY,CREATED_ON)  ";
                qry += " values ('"+rid+"','" + ddlEntity.SelectedValue + "','" + ddlDept.SelectedValue + "','','','A','" + userid + "',to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh.mm.ss") + "','dd/MM/YYYY HH24.MI.SS')  )";

                cmd = new OracleCommand(qry, ocon, trns);
                //cmd.ExecuteNonQuery();
                //DataTable dt = (DataTable)ViewState["CurrentTable"]; //(DataTable)Gridview1.DataSource;
                string intiator = "", rev1 = "", rev2 = "", rev3 = "", rev4 = "";
                for (int a = 0; a < gvNew.Rows.Count; a++)
                {
                    string id = gvNew.Rows[a].Cells[0].Text.ToString();
                    DropDownList ddlecode = (DropDownList)gvNew.Rows[a].FindControl("ddlEmp");
                    DropDownList ddlM = (DropDownList)gvNew.Rows[a].FindControl("ddlM");
                    DropDownList ddlRole = (DropDownList)gvNew.Rows[a].FindControl("ddlRole");
                    if (ddlRole.SelectedValue == "I")
                    {
                        if (intiator == "")
                            intiator = ddlecode.SelectedValue;
                        else
                            intiator += "," + ddlecode.SelectedValue;

                    }
                    if (ddlRole.SelectedValue == "R1")
                    {
                        if (rev1 == "")
                            rev1 = ddlecode.SelectedValue;
                        else
                            rev1 += "," + ddlecode.SelectedValue;
                    }
                    if (ddlRole.SelectedValue == "R2")
                    {
                        if (rev2 == "")
                            rev2 = ddlecode.SelectedValue;
                        else
                            rev2 += "," + ddlecode.SelectedValue;
                    }
                    if (ddlRole.SelectedValue == "R3")
                    {
                        if (rev3 == "")
                            rev3 = ddlecode.SelectedValue;
                        else
                            rev3 += "," + ddlecode.SelectedValue;
                    }
                    if (ddlRole.SelectedValue == "R4")
                    {
                        if (rev4 == "")
                            rev4 = ddlecode.SelectedValue;
                        else
                            rev4 += "," + ddlecode.SelectedValue;
                    }
                    
                }
                qry = "update SN_HIERARCHY_change  set S_NO,EMP_CODE,MANDATORY,ROLE,STATUS, where SNHD_RECID ='"+rid+"' ";
                //qry += " values (imis_reid.nextval,'" + ddlEntity.SelectedValue + "','','" + id + "','" + ddlecode.SelectedValue + "','" + ddlM.SelectedValue + "','" + ddlRole.SelectedValue + "','A','" + userid + "',to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh.mm.ss") + "','dd/MM/YYYY HH24.MI.SS'))";
                cmd = new OracleCommand(qry, ocon, trns);
                //cmd.ExecuteNonQuery();
                //trns.Commit();

                DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
                for (int i = 0; i < dtCurrentTable.Rows.Count ; i++)
                {

                    DropDownList ddlEmp = (DropDownList)gvNew.Rows[i].Cells[3].FindControl("ddlEmp");
                    DropDownList ddlM = (DropDownList)gvNew.Rows[i].Cells[4].FindControl("ddlM");
                    DropDownList ddlRole = (DropDownList)gvNew.Rows[i].Cells[4].FindControl("ddlRole");

                    // Update the DataRow with the DDL Selected Items 

                    dtCurrentTable.Rows[i]["Column1"] = ddlEmp.SelectedItem.Text;
                    dtCurrentTable.Rows[i]["Column2"] = ddlM.SelectedItem.Text;
                    dtCurrentTable.Rows[i]["Column3"] = ddlRole.SelectedItem.Text;

                }

                //Store the current data to ViewState for future reference 
                ViewState["CurrentTable"] = dtCurrentTable;
                DataTable dt = (DataTable)ViewState["CurrentTable"];
                Session["dt"] = dt;
                CommonFunc.ShowAlert("Data saved sucessfully");
                Response.Write("<script>window.close();</" + "script>");

                Response.End();
            }
            catch (Exception ex)
            {
                trns.Rollback();
                CommonFunc.ShowAlert("Error : " + ex.Message);
            }
            finally { ocon.Close(); }
        }
        protected void ddlEntity_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlSBU.Items.Clear();
            ddlSBU.Items.Add("--Select--");
            ds = CommonFunc.GetSBU(ddlEntity.SelectedValue);
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                ddlSBU.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["SBU_CODE"].ToString()));
            }
        }
        protected void ddlSBU_SelectedIndexChanged(object sender, EventArgs e)
        {
            ds = CommonFunc.GetUNIT(ddlEntity.SelectedValue, ddlSBU.SelectedValue); //DataSet ds1 = CommonFunc.GetbudRefNo(ddlEntity.SelectedValue, lblFyear.Text);
            ddlUnit.Items.Clear(); ddlUnit.Items.Add(new ListItem("--Select--", "0"));
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                {
                    ddlUnit.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["OU_CODE"].ToString()));
                }
           
        }
        protected void ddlUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlCategory.Items.Clear(); ddlCategory.Items.Add(new ListItem("--Select--", "0"));
            ds = CommonFunc.GetCategoryAll(ddlSBU.SelectedValue, ddlUnit.SelectedValue, ddlEntity.SelectedValue);
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                ddlCategory.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["SBU_CATEGORY_CODE"].ToString()));
            }
        }
}
