﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Data.OracleClient;
using System.Web.UI.WebControls;
using MyClass;
using CustomClass;

[ObsoleteAttribute("OracleConnection has been deprecated. http://go.microsoft.com/fwlink/?LinkID=144260", false)]
public partial class MISLogin : System.Web.UI.Page
{
    OracleConnection con1 = new OracleConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        //CommonFunc.ShowAlert("Alert");
        if (IsPostBack)
        {
            //Session["comp"] = "55";
            if (Session["err"] != null && Session["err"].ToString() != "")
            {
                lblmsg.Visible = true;
                lblmsg.Text = Session["err"].ToString();
                //Response.Redirect("login.aspx");
            }
        }
    }
    protected void ImageButton1_Click(object sender, EventArgs e)
    {
        lblmsg.Visible = false;
        
        if (txtLoginID.Text == "")
        {
            lblmsg.Text = "UserId should not be blank.";
            lblmsg.Visible = true;
        }
            else if (txtPwd.Text == "")
        {
            lblmsg.Text = "Password should not be blank.";
            lblmsg.Visible = true;
        }
       
        try
        {

            if (txtLoginID.Text.ToUpper() == "RCHOUBEY" || txtLoginID.Text.ToUpper() == "VJKUMAR" || txtLoginID.Text.ToUpper() == "VSAINI55" || txtLoginID.Text.ToUpper() == "ARJUNS55" || txtLoginID.Text.ToUpper() == "SACHIN4O" || txtLoginID.Text.ToUpper() == "SKATIYAR")
            {

            }
            else
            {
                Response.Redirect("mislogin.aspx");
            }
            
            con1 = CommonFunc.CreateConnection(txtLoginID.Text, txtPwd.Text);            
            con1.Open();
            con1.Close();
            OracleDataAdapter da = new OracleDataAdapter();
            DataSet ds = new DataSet();
            
            con1 = CommonFunc.con();
            string q = "select TITLE,employee_name,dept_code,emp_code,email_id from hrm_employee where imis_login_id ='" + txtLoginID.Text.ToUpper() + "' and status in ('C','P','N') AND NVL(MULTI_ALLOW,'M') ='M'";
                da = new OracleDataAdapter(q, con1);
                ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    Session["name"] = ds.Tables[0].Rows[0]["TITLE"].ToString() + " " + ds.Tables[0].Rows[0]["employee_name"].ToString();
                    Session["emp_code"] = ds.Tables[0].Rows[0]["emp_code"].ToString();
                    Session["dept"] = ds.Tables[0].Rows[0]["dept_code"].ToString();
                    Session["email"] = ds.Tables[0].Rows[0]["email_id"].ToString();
                    Session["imisid"] = txtLoginID.Text;
                    //Session["name"] = ds.Tables[0].Rows[0]["employee_name"].ToString();
                    CustomFunc.userid = ds.Tables[0].Rows[0]["emp_code"].ToString(); ;
                    q = "select MAPPING_CODE from EMP_MAPPING_APPROVAL where EMP_CODE = '" + ds.Tables[0].Rows[0]["emp_code"].ToString() + "'   ";
                    da = new OracleDataAdapter(q, con1);
                    DataSet ds1 = new DataSet();
                    da.Fill(ds1);
                    if (ds1.Tables[0].Rows.Count > 0)
                    {
                        Session["emp_code_map"] = ds1.Tables[0].Rows[0]["MAPPING_CODE"].ToString();
                        Session["org_emp_code"] = ds.Tables[0].Rows[0]["emp_code"].ToString();
                    }

                    //if (Request.QueryString["sid"] != null && Request.QueryString["sid"].ToString() != "")
                    //{
                    //   string  recid = Request.QueryString["sid"].ToString();
                    //   Response.Redirect("SanctionDetails.aspx?sid=" + recid);
                    //}
                    //else
                    Response.Redirect("~/ShowSanctionMIS.aspx");
                }
                else
                {
                    lblmsg.Text = "No Details Found.";
                    Session["err"] = lblmsg.Text;
                    lblmsg.Visible = true;
                }
            //}            
        }
        catch (Exception ex)
        {
            string err = ex.Message;
            lblmsg.Text = "Invalid User Name/Password; Logon Denied!";
            Session["err"] = lblmsg.Text;
            lblmsg.Visible = true;
        }
    }


    
}