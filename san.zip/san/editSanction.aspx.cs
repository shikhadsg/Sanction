﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MyClass;
using System.Data;
using System.Data.OracleClient;

public partial class editSanction : System.Web.UI.Page
{
    OracleConnection ocon = new OracleConnection(); string myQ = "", budgetEmpCode=null;
    OracleDataAdapter da; DataSet ds; string userid = ""; //string recid = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["emp_code"] != null && Session["emp_code"].ToString() != "")
        {
            userid = Session["emp_code"].ToString();
            //email = Session["email"].ToString();
        }
        
        if (!IsPostBack)
        {
            
            btnPrew.Visible = false;
            if (Request.QueryString["sid"] != null && Request.QueryString["sid"].ToString() != "")
            {
                //recid = Request.QueryString["sid"].ToString();
                lblpid.Text =Request.QueryString["sid"].ToString();
            }
            try{
            ocon = CommonFunc.con();
            myQ = "select SNS_RECID,ENTITY_CODE,SANCTION_NO,SANCTION_DATE,FISCAL_YEAR,SBU_CODE,DEPT_CODE,HRIS_DEPT_CODE,PROJECT,HRIS_FUNCTION_CODE,VERSION_NO,HIERARCHY_CODE,SANCTION_SOUGHT_FOR,TOTAL_AMOUNT,BACKGROUD_INFO,CRITICAL_ISSUES_DETAIL,STATUS,CREATED_BY,CREATED_ON from SN_SANCTIONS where SNS_RECID= " + lblpid.Text + "";  //and CREATED_BY = '" + userid + "'";
            OracleDataAdapter myDa = new OracleDataAdapter(myQ, ocon);
            DataSet myDs = new DataSet();
            myDa.Fill(myDs);
            

            ds = CommonFunc.GetDeptbyEmp(userid);
            ddlDept.Items.Clear(); ddlDept.Items.Add(new ListItem("--Select--", "0"));
            ddlEntity.Items.Clear(); ddlEntity.Items.Add(new ListItem("--Select--", "0"));
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                ddlDept.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["DEPARTMENT_CODE"].ToString()));
            }
            ds = CommonFunc.GetEntity1(userid);
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                ddlEntity.Items.Add(new ListItem(ds.Tables[0].Rows[k]["LEGAL_NAME"].ToString(), ds.Tables[0].Rows[k]["ENTITY_CODE"].ToString()));
            }

            ds = CommonFunc.getAllOpenFiscalYear();
            if (ds != null && ds.Tables[0].Rows.Count > 0)
            {
                ddlFYear.Items.Clear();
                for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                {
                    ddlFYear.Items.Add(new ListItem(ds.Tables[0].Rows[k]["FISCAL_YEAR"].ToString(), ds.Tables[0].Rows[k]["FISCAL_YEAR"].ToString()));
                }
            }

            ds = CommonFunc.Getfyear();
            if (ds != null && ds.Tables[0].Rows.Count > 0)
            {
                lblFyear.Text = ds.Tables[0].Rows[0][0].ToString();
                

            }
            lblDate.Text = DateTime.Now.ToString("dd/MM/yyyy");
            //SetInitialRow(); FISCAL_YEAR
            //for (int i = 0; i < 2; i++)
            //{
            //    AddNewRowToGrid();
            //},,,,,
            if (myDs.Tables[0].Rows.Count > 0)
            {
                DataRow dr = myDs.Tables[0].Rows[0];
                ddlEntity.Items.FindByValue(dr["ENTITY_CODE"].ToString()).Selected = true;
                ddlFYear.ClearSelection();
                ddlFYear.Items.FindByValue(dr["FISCAL_YEAR"].ToString()).Selected = true;
                ds = CommonFunc.GetSBU(ddlEntity.SelectedValue);
                ddlSBU.Items.Clear(); ddlSBU.Items.Add(new ListItem("--Select--", "0"));
                for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                {
                    ddlSBU.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["SBU_CODE"].ToString()));
                }
                ddlDept.Items.FindByValue(dr["hris_DEPT_CODE"].ToString()).Selected = true;
                ddlSBU.Items.FindByValue(dr["SBU_CODE"].ToString()).Selected = true;
                lblSancNo.Text = dr["SANCTION_NO"].ToString();
                if (lblSancNo.Text.Contains("Temp"))
                {
                    ddlFYear.Enabled = true;
                }
                else ddlFYear.Enabled = false;
                lblDate.Text = dr["SANCTION_DATE"].ToString();
                lblFyear.Text = dr["FISCAL_YEAR"].ToString(); ddlFYear.ClearSelection();
                ddlFYear.Items.FindByValue(lblFyear.Text).Selected = true;
                getddlDept();
                ddlProject.Items.FindByValue(dr["PROJECT"].ToString()).Selected = true;
                lblVersion.Text = dr["VERSION_NO"].ToString();
                lblHCode.Text = dr["HIERARCHY_CODE"].ToString();
                lblHierarcode.Text = dr["HIERARCHY_CODE"].ToString();
                txtSoughtFor.Text = Server.HtmlDecode(dr["SANCTION_SOUGHT_FOR"].ToString());
                txtBack.Text = Server.HtmlDecode(dr["BACKGROUD_INFO"].ToString());
                txtIssue.Text = Server.HtmlDecode(dr["CRITICAL_ISSUES_DETAIL"].ToString());
                txtTotal.Text = Server.HtmlDecode(dr["TOTAL_AMOUNT"].ToString());
                lblStatus.Text = dr["STATUS"].ToString();
            }

            if (lblStatus.Text == "P")
            {
                btnPrew.Visible = false;
            }

            ocon = CommonFunc.con();
            myQ = "select SNSD_RECID,OU_CODE,SBU_CATEGORY_CODE,BRAND_CODE,PRODUCT_ID,SEQ_NO,EXPENSE_CODE_BUDGET,PARTICULARS,SPECIFICATIONS,BUDGET_APPROVED,BUDGET_REF_NO,SANCTION_AMOUNT,BUDGET_AMOUNT,CONSUMED_AMOUNT,BALANCE_AMOUNT,SANCTION_AMOUNT_GST ";
            myQ += "    from SN_SANCTIONS_DETAILS where  PARENT_RECID=  " + lblpid.Text + " and nvl(status,'A')='A'  order by    SEQ_NO";//and CREATED_BY = '" + userid + "'
             myDa = new OracleDataAdapter(myQ, ocon);
             myDs = new DataSet();
            myDa.Fill(myDs);

            SetInitialRow(); bool flag = false;
            if (myDs.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < myDs.Tables[0].Rows.Count-1; i++)
                {
                    AddNewRowToGrid();
                }
                for (int i = 0; i < myDs.Tables[0].Rows.Count; i++)
                {
                    DataRow dr = myDs.Tables[0].Rows[i];
                    DropDownList ddlUnit = (DropDownList)Gridview1.Rows[i].FindControl("ddlunit");
                    ddlUnit.Items.Clear(); ddlUnit.Items.Add(new ListItem("--Select--", "0"));
                    ds = CommonFunc.GetUNITbyEmp(ddlEntity.SelectedValue, ddlSBU.SelectedValue,userid);
                    for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                    {
                        ddlUnit.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["OU_CODE"].ToString()));
                        //ListBox1.Items.Add(new ListItem(  ds.Tables[0].Rows[k]["OU_CODE"].ToString() + " " + ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["OU_CODE"].ToString()));
                    }
                    ddlUnit.ClearSelection();
                    ddlUnit.Items.FindByValue(dr["OU_CODE"].ToString()).Selected = true;

                    DropDownList ddlCategory = (DropDownList)Gridview1.Rows[i].FindControl("ddlCategory");

                    ddlCategory.Items.Clear(); ddlCategory.Items.Add(new ListItem("--Select--", "0"));
                    ds = CommonFunc.GetCategory(ddlSBU.SelectedValue, ddlUnit.SelectedValue, ddlEntity.SelectedValue,userid);
                    for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                    {
                        ddlCategory.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["SBU_CATEGORY_CODE"].ToString()));
                    }
                    ddlCategory.ClearSelection();
                    ddlCategory.Items.FindByValue(dr["SBU_CATEGORY_CODE"].ToString()).Selected = true;

                    DropDownList ddlBrand = (DropDownList)Gridview1.Rows[i].FindControl("ddlBrand");
                    ddlBrand.Items.Clear(); ddlBrand.Items.Add(new ListItem("--Select--", "0"));
                    ds = CommonFunc.GetBrand(ddlSBU.SelectedValue, ddlCategory.SelectedValue, ddlUnit.SelectedValue, ddlEntity.SelectedValue);
                    for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                    {
                        ddlBrand.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["BRAND_CODE"].ToString()));
                    }
                    ddlBrand.ClearSelection();
                    ddlBrand.Items.FindByValue(dr["BRAND_CODE"].ToString()).Selected = true;
                    //,SEQ_NO,,,BUDGET_APPROVED,,,
                    DropDownList ddlProduct = (DropDownList)Gridview1.Rows[i].FindControl("ddlProduct");
                    ddlProduct.Items.Clear(); ddlProduct.Items.Add(new ListItem("--Select--", "0"));
                    ds = CommonFunc.Getproduct(ddlBrand.SelectedValue, ddlCategory.SelectedValue, ddlUnit.SelectedValue,ddlSBU.SelectedValue,ddlEntity.SelectedValue);
                    for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                    {
                        ddlProduct.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["PRODUCT_ID"].ToString()));
                    }
                    ddlProduct.Items.FindByValue(dr["PRODUCT_ID"].ToString()).Selected = true;
                    Gridview1.Rows[i].Cells[0].Text = dr["SEQ_NO"].ToString();

                    TextBox txtParticular = (TextBox)Gridview1.Rows[i].FindControl("txtParticular");
                    TextBox txtDetail = (TextBox)Gridview1.Rows[i].FindControl("txtDetail");//txtAmount
                    TextBox txtAmount = (TextBox)Gridview1.Rows[i].FindControl("txtAmount");
                    TextBox txtAmountGST = (TextBox)Gridview1.Rows[i].FindControl("txtAmountGST");
                  
                    DropDownList ddlBudApp = (DropDownList)Gridview1.Rows[i].FindControl("ddlBudApp");
                    txtParticular.Text = Server.HtmlDecode(dr["PARTICULARS"].ToString());
                    txtDetail.Text = Server.HtmlDecode(dr["SPECIFICATIONS"].ToString());
                    txtAmount.Text = dr["SANCTION_AMOUNT"].ToString();
                    txtAmountGST.Text = dr["SANCTION_AMOUNT_GST"].ToString();

                    DropDownList ddlExpCode = (DropDownList)Gridview1.Rows[i].FindControl("ddlExpCode");
                    ds = CommonFunc.GetExpCodeSbu(ddlDept.SelectedValue,lblFyear.Text,ddlSBU.SelectedValue);

                    ddlExpCode.Items.Clear(); ddlExpCode.Items.Add(new ListItem("--Select--", "0"));
                    for (int k = 0; k < ds.Tables[0].Rows.Count; k++)//
                    {
                        ddlExpCode.Items.Add(new ListItem(ds.Tables[0].Rows[k]["head_description"].ToString(), ds.Tables[0].Rows[k]["EXPENSE_CODE_BUDGET"].ToString()));
                    }
                    ddlExpCode.Items.FindByValue(dr["EXPENSE_CODE_BUDGET"].ToString()).Selected = true;

                    ddlBudApp.Items.FindByValue(dr["BUDGET_APPROVED"].ToString()).Selected = true;

                    DropDownList ddlBudRefNo = (DropDownList)Gridview1.Rows[i].FindControl("ddlBudRefNo");
                    
                    if (ddlBudApp.SelectedValue == "Y")
                        ddlBudRefNo.Enabled = true;
                    DataSet ds1 = CommonFunc.GetbudRefNo(ddlEntity.SelectedValue, ddlUnit.SelectedValue, ddlSBU.SelectedValue, ddlCategory.SelectedValue, ddlBrand.SelectedValue, ddlProduct.SelectedValue, ddlDept.SelectedValue, ddlProject.SelectedValue, ddlExpCode.SelectedValue, lblFyear.Text,userid);
                    ddlBudRefNo.Items.Clear(); ddlBudRefNo.Items.Add(new ListItem("--Select--", "NA"));
                    for (int k = 0; k < ds1.Tables[0].Rows.Count; k++)
                    {
                        ddlBudRefNo.Items.Add(new ListItem(ds1.Tables[0].Rows[k]["BUDGET_REF_NO"].ToString(), ds1.Tables[0].Rows[k]["BUDGET_REF_NO"].ToString()));
                    }
                    ddlBudRefNo.ClearSelection();//EXPENSE_CODE_BUDGET
                    ddlBudRefNo.Items.FindByValue(dr["BUDGET_REF_NO"].ToString()).Selected = true;
                    Label lblid = (Label)Gridview1.Rows[i].Cells[7].FindControl("lblid");//shikha
                    lblid.Text = dr["SNSD_RECID"].ToString();
                    string flagROI = CommonFunc.ROIFlag(ddlExpCode.SelectedValue);
                   
                    if (flagROI == "Y")
                    {
                        pnlROI.Visible = true;
                        flag = true;
                    }
                    else 
                    {
                        if (flag == false)
                        pnlROI.Visible = false;
                    }
                }
               

                if (lblHCode.Text == "CUSTOM")
                {

                    DataSet myds = new DataSet();

                    myds = CommonFunc.GetApproval_Detail(lblpid.Text);
                    SetInitialRow1();
                    if (myds.Tables[0].Rows.Count > 0)
                    {
                        for (int i = 0; i < myds.Tables[0].Rows.Count - 1; i++)
                        {
                            AddNewRowToGrid1();
                        }
                        for (int i = 0; i < myds.Tables[0].Rows.Count; i++)
                        {
                            //ddlEmp ddlM ddlRole  S_NO,EMP_CODE,MANDATORY,  S_NO,EMP_CODE,SKIPPED
                            DataRow dr = myds.Tables[0].Rows[i];
                            DropDownList ddlEmp = (DropDownList)gvNew.Rows[i].FindControl("ddlEmp");
                            DropDownList ddlM = (DropDownList)gvNew.Rows[i].FindControl("ddlM");
                            DropDownList ddlRole = (DropDownList)gvNew.Rows[i].FindControl("ddlRole");
                            Label SNHD_RECID = (Label)gvNew.Rows[i].FindControl("SNHD_RECID");
                            LinkButton LinkDelete = (LinkButton)gvNew.Rows[i].FindControl("LinkDelete");
                            gvNew.Rows[i].Cells[0].Text = dr["S_NO"].ToString();
                            ddlEmp.ClearSelection();
                            ddlEmp.Items.FindByValue(dr["EMP_CODE"].ToString()).Selected = true;
                            ddlM.ClearSelection();
                            ddlM.Items.FindByValue(dr["SKIPPED"].ToString()).Selected = true;
                            ddlRole.ClearSelection();
                            ddlRole.Items.FindByValue(dr["ROLE"].ToString()).Selected = true;
                            SNHD_RECID.Text = dr["SNSA_RECID"].ToString();
                            if (SNHD_RECID.Text != "")
                                LinkDelete.Visible = false;
                        }
                    }
                }
                string qry = "select SNSAT_RECID,FILE_NAME from SN_SANCTION_ATTACHMENTS where PARENT_RECID= '" + lblpid.Text + "'";
                da = new OracleDataAdapter(qry, ocon);
                ds = new DataSet();
                da.Fill(ds);
                gvFiles.DataSource = ds;
                gvFiles.DataBind();

                }
            }
            catch(Exception ex)
            {
                CommonFunc.ShowAlert("Error: " + ex.Message);
            }
                
            
        }
        if (lblSancNo.Text.ToUpper() != "NEW")
        {
            //btnPrew.Visible = true;
        }
        //if (Session["dt"] != null) VERSION_NO,,,,,
        //{
        //    DataTable dt = (DataTable)Session["dt"];
        //    GridView2.DataSource = dt;
        //    GridView2.DataBind();

        //}

    }
    protected void ddlEntity_SelectedIndexChanged(object sender, EventArgs e)
    {
       
        if (ddlEntity.SelectedIndex > 0)
        {
            ddlSBU.Items.Clear(); ddlSBU.Items.Add(new ListItem("--Select--", "0"));
            ds = CommonFunc.GetSBU1(ddlEntity.SelectedValue,userid);
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                ddlSBU.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["SBU_CODE"].ToString()));
            }

            ds = CommonFunc.GetUNIT(ddlEntity.SelectedValue, ddlSBU.SelectedValue); //DataSet ds1 = CommonFunc.GetbudRefNo(ddlEntity.SelectedValue, lblFyear.Text);
            for (int i = 0; i < Gridview1.Rows.Count ; i++)
            {
                DropDownList ddlUnit = (DropDownList)Gridview1.Rows[i].FindControl("ddlunit");
                //ListBox ListBox1 = (ListBox)Gridview1.Rows[i].FindControl("ListBox1");
                DropDownList ddlBudRefNo = (DropDownList)Gridview1.Rows[i].FindControl("ddlBudRefNo");
                ddlUnit.Items.Clear(); ddlUnit.Items.Add(new ListItem("--Select--", "0"));
                for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                {
                    ddlUnit.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["OU_CODE"].ToString()));
                    //ListBox1.Items.Add(new ListItem(  ds.Tables[0].Rows[k]["OU_CODE"].ToString() + " " + ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["OU_CODE"].ToString()));
                }

                //ddlBudRefNo.Items.Clear(); ddlBudRefNo.Items.Add("--Select--");
                //for (int k = 0; k < ds1.Tables[0].Rows.Count; k++)
                //{
                //    ddlBudRefNo.Items.Add(new ListItem(ds1.Tables[0].Rows[k]["BUDGET_REF_NO"].ToString(), ds1.Tables[0].Rows[k]["BUDGET_REF_NO"].ToString()));
                //}
            }
        }
    }
    protected void ddlDept_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlDept.SelectedIndex > 0)
        {
            //ddlExpCode.Items.Clear();
            //ds = CommonFunc.GetExpCode(ddlDept.SelectedValue);ddlDept_SelectedIndexChanged
            //for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            //{
            //    ddlExpCode.Items.Add(new ListItem(ds.Tables[0].Rows[k]["head_description"].ToString(), ds.Tables[0].Rows[k]["expense_code"].ToString()));
            //}

            ddlProject.Items.Clear(); ddlProject.Items.Add(new ListItem("--Select--", "0"));
            ds = CommonFunc.GetFunc(ddlDept.SelectedValue);
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                ddlProject.Items.Add(new ListItem(ds.Tables[0].Rows[k]["code"].ToString(), ds.Tables[0].Rows[k]["PROJECT"].ToString()));
            }

            ds = CommonFunc.GetExpCodeSbu(ddlDept.SelectedValue, lblFyear.Text,ddlSBU.SelectedValue);
            for (int i = 0; i < Gridview1.Rows.Count; i++)
            {
                DropDownList ddlExpCode = (DropDownList)Gridview1.Rows[i].FindControl("ddlExpCode");
                ddlExpCode.Items.Clear(); ddlExpCode.Items.Add(new ListItem("--Select--", "0"));
                for (int k = 0; k < ds.Tables[0].Rows.Count; k++)//
                {
                    ddlExpCode.Items.Add(new ListItem(ds.Tables[0].Rows[k]["head_description"].ToString(), ds.Tables[0].Rows[k]["EXPENSE_CODE_BUDGET"].ToString()));
                }
            }
        }
    }

    protected void ddlBudApp_SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList ddlBudApp = (DropDownList)sender;
        GridViewRow row = (GridViewRow)ddlBudApp.NamingContainer;
        DropDownList ddlBudRefNo = (DropDownList)row.FindControl("ddlBudRefNo");
        if (ddlBudApp.SelectedValue == "N")
        {
            ddlBudRefNo.Enabled = false;
            ddlBudRefNo.ClearSelection();
        }

        else
            ddlBudRefNo.Enabled = true;
    }
    protected void getddlDept()
    {
        if (ddlDept.SelectedIndex > 0)
        {
            //ddlExpCode.Items.Clear();
            //ds = CommonFunc.GetExpCode(ddlDept.SelectedValue);ddlDept_SelectedIndexChanged
            //for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            //{
            //    ddlExpCode.Items.Add(new ListItem(ds.Tables[0].Rows[k]["head_description"].ToString(), ds.Tables[0].Rows[k]["expense_code"].ToString()));
            //}

            ddlProject.Items.Clear(); ddlProject.Items.Add(new ListItem("--Select--", "0")); 
            ds = CommonFunc.GetFunc(ddlDept.SelectedValue);
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                ddlProject.Items.Add(new ListItem(ds.Tables[0].Rows[k]["code"].ToString(), ds.Tables[0].Rows[k]["PROJECT"].ToString()));
            }

            
        }
    }
    //txtParticular txtDetail ddlunit  ddlCategory ddlBrand ddlProduct ddlExpCode txtAmount ddlBudRefNo ListBox1_SelectedIndexChanged

    protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
        //DropDownList ddlunit = (DropDownList)sender;
        ListBox lstunit = (ListBox)sender;
        GridViewRow row = (GridViewRow)lstunit.NamingContainer;
        DropDownList ddlunit = (DropDownList)row.FindControl("ddlunit");
        DropDownList ddlCategory = (DropDownList)row.FindControl("ddlCategory");
        ddlunit.ClearSelection();
        ddlunit.Items.FindByValue(lstunit.SelectedValue).Selected = true;
        lstunit.Visible = false;
        //ddlCategory.Items.Clear(); ddlCategory.Items.Add("--Select--");
        //ds = CommonFunc.GetCategory(ddlSBU.SelectedValue, ddlunit.SelectedValue);
        //for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
        //{
        //    ddlCategory.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["SBU_CATEGORY_CODE"].ToString()));
        //}
    }

    protected void ddlunit_SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList ddlunit = (DropDownList)sender;
        GridViewRow row = (GridViewRow)ddlunit.NamingContainer;
        DropDownList ddlCategory = (DropDownList)row.FindControl("ddlCategory");
        DropDownList ddlBrand = (DropDownList)row.FindControl("ddlBrand");
        DropDownList ddlProduct = (DropDownList)row.FindControl("ddlProduct");
        DropDownList ddlBudRefNo = (DropDownList)row.FindControl("ddlBudRefNo");

        ddlCategory.Items.Clear(); ddlCategory.Items.Add(new ListItem("--Select--", "0"));
        ds = CommonFunc.GetCategory(ddlSBU.SelectedValue, ddlunit.SelectedValue, ddlEntity.SelectedValue, userid);
        for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
        {
            ddlCategory.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["SBU_CATEGORY_CODE"].ToString()));
        }

        ddlBrand.Items.Clear(); ddlBrand.Items.Add(new ListItem("--Select--", "0"));
        ddlProduct.Items.Clear(); ddlProduct.Items.Add(new ListItem("--Select--", "0"));
        ddlBudRefNo.Items.Clear(); ddlBudRefNo.Items.Add(new ListItem("--Select--", "NA"));

        btnSave.Visible=true;
        //ds = CommonFunc.GetUNITWarning(ddlEntity.SelectedValue, ddlSBU.SelectedValue, ddlunit.SelectedValue);
        //    if( ds.Tables[0].Rows[0][0].ToString()=="E")
        //    {
        //        CommonFunc.ShowAlert("Not allowed. Sanction Amount exceed Error.");
        //        btnSave.Visible=false;
        //    }
        //    else if( ds.Tables[0].Rows[0][0].ToString()=="W")
        //    {
        //        CommonFunc.ShowAlert("Sanction Amount exceed Warning");
        //    }
        //        Session["dept"] = ddlDept.ClientID;
        //        Page.ClientScript.RegisterStartupScript(
        //this.GetType(), "OpenWindow", "window.open('About.aspx','_newtab');", true);
    }

    protected void ddlBrand_SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList ddlBrand = (DropDownList)sender; //ddlunit
        GridViewRow row = (GridViewRow)ddlBrand.NamingContainer;
        DropDownList ddlProduct = (DropDownList)row.FindControl("ddlProduct");
        DropDownList ddlCategory = (DropDownList)row.FindControl("ddlCategory");
         DropDownList ddlunit = (DropDownList)row.FindControl("ddlunit");
         DropDownList ddlBudRefNo = (DropDownList)row.FindControl("ddlBudRefNo");
         DropDownList ddlExpCode = (DropDownList)row.FindControl("ddlExpCode");

         ddlProduct.Items.Clear(); ddlProduct.Items.Add(new ListItem("--Select--", "0"));
         ds = CommonFunc.Getproduct(ddlBrand.SelectedValue, ddlCategory.SelectedValue, ddlunit.SelectedValue, ddlSBU.SelectedValue, ddlEntity.SelectedValue);
        for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
        {
            ddlProduct.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["PRODUCT_ID"].ToString()));
        }

        ddlExpCode.ClearSelection();
        ddlBudRefNo.Items.Clear(); ddlBudRefNo.Items.Add(new ListItem("--Select--", "NA"));
    }

    protected void ddlCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList ddlCategory = (DropDownList)sender; //ddlunit
        GridViewRow row = (GridViewRow)ddlCategory.NamingContainer;
        DropDownList ddlBrand = (DropDownList)row.FindControl("ddlBrand");
        DropDownList ddlunit = (DropDownList)row.FindControl("ddlunit");
        DropDownList ddlProduct = (DropDownList)row.FindControl("ddlProduct");
        DropDownList ddlBudRefNo = (DropDownList)row.FindControl("ddlBudRefNo");
        DropDownList ddlExpCode = (DropDownList)row.FindControl("ddlExpCode");


        ddlBrand.Items.Clear(); ddlBrand.Items.Add(new ListItem("--Select--", "0"));
        ds = CommonFunc.GetBrand(ddlSBU.SelectedValue, ddlCategory.SelectedValue, ddlunit.SelectedValue, ddlEntity.SelectedValue);
        for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
        {
            ddlBrand.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["BRAND_CODE"].ToString()));
        }
        ddlProduct.Items.Clear(); ddlProduct.Items.Add(new ListItem("--Select--", "0"));
        ddlBudRefNo.Items.Clear(); ddlBudRefNo.Items.Add(new ListItem("--Select--", "NA"));
        ddlExpCode.ClearSelection();
    }
    protected void ddlProduct_SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList ddlProduct = (DropDownList)sender;
        GridViewRow row = (GridViewRow)ddlProduct.NamingContainer;
        DropDownList ddlBudRefNo = (DropDownList)row.FindControl("ddlBudRefNo");
        ddlBudRefNo.ClearSelection();
    }

    protected void ddlExpCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList ddlExpCode = (DropDownList)sender; //ddlunit
        GridViewRow row = (GridViewRow)ddlExpCode.NamingContainer;
        //Label ldlExpDesc = (Label)row.FindControl("ldlExpDesc");
        //ldlExpDesc.Text = ddlExpCode.SelectedValue;
        DropDownList ddlBudApp = (DropDownList)row.FindControl("ddlBudApp");

        DropDownList ddlProduct = (DropDownList)row.FindControl("ddlProduct");
        DropDownList ddlCategory = (DropDownList)row.FindControl("ddlCategory");
        DropDownList ddlunit = (DropDownList)row.FindControl("ddlunit");
        DropDownList ddlBrand = (DropDownList)row.FindControl("ddlBrand");
        DropDownList ddlBudRefNo = (DropDownList)row.FindControl("ddlBudRefNo");

        DataSet ds1 = CommonFunc.GetbudRefNo(ddlEntity.SelectedValue, ddlunit.SelectedValue, ddlSBU.SelectedValue, ddlCategory.SelectedValue, ddlBrand.SelectedValue, ddlProduct.SelectedValue, ddlDept.SelectedValue, ddlProject.SelectedValue, ddlExpCode.SelectedValue, lblFyear.Text,userid);
        ddlBudRefNo.Items.Clear(); ddlBudRefNo.Items.Add(new ListItem("--Select--", "NA"));
        for (int k = 0; k < ds1.Tables[0].Rows.Count; k++)
        {
            ddlBudRefNo.Items.Add(new ListItem(ds1.Tables[0].Rows[k]["BUDGET_REF_NO"].ToString(), ds1.Tables[0].Rows[k]["BUDGET_REF_NO"].ToString()));
            budgetEmpCode = ds1.Tables[0].Rows[k]["emp_code"].ToString();
        }
        ddlBudRefNo.ClearSelection();
        string flagROI = CommonFunc.ROIFlag(ddlExpCode.SelectedValue);
        if (flagROI == "Y")
        {
            pnlROI.Visible = true;
        }
        else
        {
            pnlROI.Visible = false;
        }
        //ddlBudRefNo.Items.FindByText(dt.Rows[i]["Column9"].ToString()).Selected = true;
    }

    protected void ddlBudRefNo_SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList ddlBudRefNo = (DropDownList)sender; //ddlunit
        GridViewRow row = (GridViewRow)ddlBudRefNo.NamingContainer;
        //Label ldlExpDesc = (Label)row.FindControl("ldlExpDesc");
        //ldlExpDesc.Text = ddlExpCode.SelectedValue;
        DropDownList ddlBudApp = (DropDownList)row.FindControl("ddlBudApp");
        DropDownList ddlProduct = (DropDownList)row.FindControl("ddlProduct");
        DropDownList ddlCategory = (DropDownList)row.FindControl("ddlCategory");
        DropDownList ddlunit = (DropDownList)row.FindControl("ddlunit");
        DropDownList ddlBrand = (DropDownList)row.FindControl("ddlBrand");
        DropDownList ddlExpCode = (DropDownList)row.FindControl("ddlExpCode");

        

        decimal amtupto = 0;

        if (ddlBudApp.SelectedValue == "Y")
        {
            DataSet ds1 = CommonFunc.GetbudAmountTotal(ddlEntity.SelectedValue, ddlunit.SelectedValue, ddlSBU.SelectedValue, ddlCategory.SelectedValue, ddlBrand.SelectedValue, ddlProduct.SelectedValue, ddlDept.SelectedValue, ddlProject.SelectedValue, ddlExpCode.SelectedValue, lblFyear.Text, ddlBudRefNo.SelectedValue, budgetEmpCode);
            if (ds1.Tables[0].Rows.Count > 0)
            {
                string aa = ds1.Tables[0].Rows[0][0].ToString() + " " + ds1.Tables[0].Rows[0][1].ToString() + " " + ds1.Tables[0].Rows[0][2].ToString() + " " + ds1.Tables[0].Rows[0][3].ToString() + " " + ds1.Tables[0].Rows[0][4].ToString();
                amtupto = Convert.ToDecimal(ds1.Tables[0].Rows[0]["AVAILABLE_AMT"].ToString());
                //CommonFunc.ShowAlert(aa);
            }
            ds = CommonFunc.GetUNITWarning(ddlEntity.SelectedValue, ddlSBU.SelectedValue, ddlunit.SelectedValue);
            if (ds.Tables[0].Rows[0][0].ToString() == "E")
            {
                if (txtTotal.Text != "")
                    if (amtupto < Convert.ToDecimal(txtTotal.Text))
                    {
                        CommonFunc.ShowAlert("Not allowed. Sanction Amount exceed Error.");

                    }
            }
            if (ds.Tables[0].Rows[0][0].ToString() == "W")
            {
                if (txtTotal.Text != "")
                    if (amtupto < Convert.ToDecimal(txtTotal.Text))
                    {
                        CommonFunc.ShowAlert("Warning. Sanction Amount exceed Error.");

                    }
            }
        }
        
    }

    private void SetInitialRow()
    {

        DataTable dt = new DataTable();
        DataRow dr = null;

        dt.Columns.Add(new DataColumn("RowNumber", typeof(string)));
        dt.Columns.Add(new DataColumn("Column1", typeof(string)));//for TextBox value 
        dt.Columns.Add(new DataColumn("Column2", typeof(string)));//for TextBox value 
        dt.Columns.Add(new DataColumn("Column3", typeof(string)));//for DropDownList selected item 
        dt.Columns.Add(new DataColumn("Column4", typeof(string)));//for DropDownList selected item 
        dt.Columns.Add(new DataColumn("Column5", typeof(string)));//for TextBox value 
        dt.Columns.Add(new DataColumn("Column6", typeof(string)));//for TextBox value 
        dt.Columns.Add(new DataColumn("Column7", typeof(string)));//for DropDownList selected item 
        dt.Columns.Add(new DataColumn("Column8", typeof(string)));//for DropDownList selected item
        dt.Columns.Add(new DataColumn("Column9", typeof(string)));//for TextBox value 
        dt.Columns.Add(new DataColumn("Column10", typeof(string)));
        dt.Columns.Add(new DataColumn("Column11", typeof(string)));//shikha
        dt.Columns.Add(new DataColumn("Column12", typeof(string)));

        dr = dt.NewRow();
        dr["RowNumber"] = 1;
        dr["Column1"] = string.Empty;
        dr["Column2"] = string.Empty;
        dr["Column8"] = string.Empty;
        dt.Rows.Add(dr);

        //Store the DataTable in ViewState for future reference 
        ViewState["CurrentTable"] = dt;

        //Bind the Gridview 
        Gridview1.DataSource = dt;
        Gridview1.DataBind();

        //After binding the gridview, we can then extract and fill the DropDownList with Data 
        //DropDownList ddlEmp = (DropDownList)Gridview1.Rows[0].Cells[1].FindControl("ddlEmp");
        //DropDownList ddl2 = (DropDownList)Gridview1.Rows[0].Cells[4].FindControl("DropDownList2");
        //FillDropDownList(ddlEmp);

    }

    private void AddNewRowToGrid()
    {

        if (ViewState["CurrentTable"] != null)
        {

            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
            DataRow drCurrentRow = null;

            if (dtCurrentTable.Rows.Count > 0)
            {
                drCurrentRow = dtCurrentTable.NewRow();
                drCurrentRow["RowNumber"] = dtCurrentTable.Rows.Count + 1;

                //add new row to DataTable 
                dtCurrentTable.Rows.Add(drCurrentRow);


                for (int i = 0; i < dtCurrentTable.Rows.Count - 1; i++)
                {
                    TextBox txtParticular = (TextBox)Gridview1.Rows[i].Cells[1].FindControl("txtParticular");
                    TextBox txtDetail = (TextBox)Gridview1.Rows[i].Cells[2].FindControl("txtDetail");
                    DropDownList ddlunit = (DropDownList)Gridview1.Rows[i].Cells[3].FindControl("ddlunit");
                    DropDownList ddlCategory = (DropDownList)Gridview1.Rows[i].Cells[4].FindControl("ddlCategory");
                    DropDownList ddlBrand = (DropDownList)Gridview1.Rows[i].Cells[5].FindControl("ddlBrand");

                    DropDownList ddlProduct = (DropDownList)Gridview1.Rows[i].Cells[6].FindControl("ddlProduct");
                    DropDownList ddlExpCode = (DropDownList)Gridview1.Rows[i].Cells[7].FindControl("ddlExpCode");
                    TextBox txtAmount = (TextBox)Gridview1.Rows[i].Cells[8].FindControl("txtAmount");
                    DropDownList ddlBudApp = (DropDownList)Gridview1.Rows[i].FindControl("ddlBudApp");
                    DropDownList ddlBudRefNo = (DropDownList)Gridview1.Rows[i].FindControl("ddlBudRefNo");
                    Label lblid = (Label)Gridview1.Rows[i].FindControl("lblid");//shikha
                    TextBox txtAmountGST = (TextBox)Gridview1.Rows[i].FindControl("txtAmountGST");

                    // Update the DataRow with the DDL Selected Items 
                    //txtParticular txtDetail ddlunit  ddlCategory ddlBrand ddlProduct ddlExpCode txtAmount ddlBudApp ddlBudRefNo
                    dtCurrentTable.Rows[i]["Column1"] = txtParticular.Text;
                    dtCurrentTable.Rows[i]["Column2"] = txtDetail.Text;
                    dtCurrentTable.Rows[i]["Column3"] = ddlunit.SelectedItem.Text;
                    dtCurrentTable.Rows[i]["Column4"] = ddlCategory.SelectedItem.Text;
                    dtCurrentTable.Rows[i]["Column5"] = ddlBrand.SelectedItem.Text;

                    dtCurrentTable.Rows[i]["Column6"] = ddlProduct.SelectedItem.Text;
                    dtCurrentTable.Rows[i]["Column7"] = ddlExpCode.SelectedItem.Text;
                    dtCurrentTable.Rows[i]["Column8"] = txtAmount.Text;
                    dtCurrentTable.Rows[i]["Column9"] = txtAmountGST.Text;
                    dtCurrentTable.Rows[i]["Column10"] = ddlBudApp.SelectedItem.Text;
                    dtCurrentTable.Rows[i]["Column11"] = ddlBudRefNo.SelectedItem.Text;
                    dtCurrentTable.Rows[i]["Column12"] = lblid.Text;//shikha

                }

                //Store the current data to ViewState for future reference 
                ViewState["CurrentTable"] = dtCurrentTable;


                //Rebind the Grid with the current data to reflect changes 
                Gridview1.DataSource = dtCurrentTable;
                Gridview1.DataBind();
            }
        }
        else
        {
            Response.Write("ViewState is null");

        }
        //Set Previous Data on Postbacks 
        SetPreviousData();
    }

    private void SetPreviousData()
    {

        
        int rowIndex = 0;
        if (ViewState["CurrentTable"] != null)
        {

            DataTable dt = (DataTable)ViewState["CurrentTable"];
            if (dt.Rows.Count > 0)
            {

                for (int i = 0; i < dt.Rows.Count; i++)
                {

                    //TextBox box1 = (TextBox)Gridview1.Rows[i].Cells[1].FindControl("TextBox1");
                    //TextBox box2 = (TextBox)Gridview1.Rows[i].Cells[2].FindControl("TextBox2");

                    TextBox txtParticular = (TextBox)Gridview1.Rows[i].Cells[1].FindControl("txtParticular");
                    TextBox txtDetail = (TextBox)Gridview1.Rows[i].Cells[2].FindControl("txtDetail");
                    DropDownList ddlunit = (DropDownList)Gridview1.Rows[i].Cells[3].FindControl("ddlunit");
                    DropDownList ddlCategory = (DropDownList)Gridview1.Rows[i].Cells[4].FindControl("ddlCategory");
                    DropDownList ddlBrand = (DropDownList)Gridview1.Rows[i].Cells[5].FindControl("ddlBrand");

                    DropDownList ddlProduct = (DropDownList)Gridview1.Rows[i].Cells[6].FindControl("ddlProduct");
                    DropDownList ddlExpCode = (DropDownList)Gridview1.Rows[i].Cells[7].FindControl("ddlExpCode");
                    TextBox txtAmount = (TextBox)Gridview1.Rows[i].Cells[8].FindControl("txtAmount");
                    TextBox txtAmountGST = (TextBox)Gridview1.Rows[i].FindControl("txtAmountGST");
                    DropDownList ddlBudApp = (DropDownList)Gridview1.Rows[i].FindControl("ddlBudApp");
                    DropDownList ddlBudRefNo = (DropDownList)Gridview1.Rows[i].Cells[7].FindControl("ddlBudRefNo");

                    Label lblid = (Label)Gridview1.Rows[i].Cells[7].FindControl("lblid");//shikha

                    ds = CommonFunc.GetUNIT(ddlEntity.SelectedValue, ddlSBU.SelectedValue);


                    ddlunit.Items.Clear(); ddlunit.Items.Add(new ListItem("--Select--", "0"));
                    for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                    {
                        ddlunit.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["OU_CODE"].ToString()));
                    }



                    //ddlProject.Items.Clear(); ddlProject.Items.Add(new ListItem( "--Select--","0"));
                    //ds = CommonFunc.GetFunc(ddlDept.SelectedValue);
                    //for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                    //{
                    //    ddlProject.Items.Add(new ListItem(ds.Tables[0].Rows[k]["code"].ToString(), ds.Tables[0].Rows[k]["PROJECT"].ToString()));
                    //}

                    ddlExpCode.Items.Clear(); ddlExpCode.Items.Add(new ListItem("--Select--", "0"));
                    ds = CommonFunc.GetExpCodeSbu(ddlDept.SelectedValue, lblFyear.Text,ddlSBU.SelectedValue);
                    for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                    {
                        ddlExpCode.Items.Add(new ListItem(ds.Tables[0].Rows[k]["head_description"].ToString(), ds.Tables[0].Rows[k]["EXPENSE_CODE_BUDGET"].ToString()));
                    }

                    DataSet ds1 = CommonFunc.GetbudRefNo(ddlEntity.SelectedValue, ddlunit.SelectedValue, ddlSBU.SelectedValue, ddlCategory.SelectedValue, ddlBrand.SelectedValue, ddlProduct.SelectedValue, ddlDept.SelectedValue, ddlProject.SelectedValue, ddlExpCode.SelectedValue, lblFyear.Text,userid);
                    ddlBudRefNo.Items.Clear(); ddlBudRefNo.Items.Add(new ListItem("--Select--", "NA"));
                    for (int k = 0; k < ds1.Tables[0].Rows.Count; k++)
                    {
                        ddlBudRefNo.Items.Add(new ListItem(ds1.Tables[0].Rows[k]["BUDGET_REF_NO"].ToString(), ds1.Tables[0].Rows[k]["BUDGET_REF_NO"].ToString()));
                    }
                    //ddlBudRefNo.ClearSelection();
                    //ddlBudRefNo.Items.FindByText(dt.Rows[i]["Column9"].ToString()).Selected = true;
                   


                    //Fill the DropDownList with Data 
                    //FillDropDownList(ddlEmp);
                    //FillDropDownList(ddl2);

                    if (i < dt.Rows.Count)
                    {

                        //Set the Previous Selected Items on Each DropDownList  on Postbacks 
                        if (dt.Rows[i]["Column1"].ToString() != "")
                        {//txtParticular txtDetail ddlunit  ddlCategory ddlBrand ddlProduct ddlExpCode txtAmount ddlBudRefNo
                            txtParticular.Text = Server.HtmlDecode(dt.Rows[i]["Column1"].ToString());
                            txtDetail.Text = Server.HtmlDecode(dt.Rows[i]["Column2"].ToString());
                            txtAmount.Text = dt.Rows[i]["Column8"].ToString();
                            txtAmountGST.Text = dt.Rows[i]["Column9"].ToString();
                            lblid.Text = dt.Rows[i]["Column11"].ToString();//shikha

                            ddlunit.ClearSelection();
                            string a = dt.Rows[i]["Column3"].ToString();
                            ddlunit.Items.FindByText(dt.Rows[i]["Column3"].ToString()).Selected = true;
                            ddlCategory.Items.Clear(); ddlCategory.Items.Add(new ListItem("--Select--", "0"));
                            ds = CommonFunc.GetCategory(ddlSBU.SelectedValue, ddlunit.SelectedValue, ddlEntity.SelectedValue, userid);
                            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                            {
                                ddlCategory.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["SBU_CATEGORY_CODE"].ToString()));
                            }
                            
                            ddlCategory.ClearSelection();
                            ddlCategory.Items.FindByText(dt.Rows[i]["Column4"].ToString()).Selected = true;

                            ddlBrand.Items.Clear(); ddlBrand.Items.Add(new ListItem("--Select--", "0"));
                            ds = CommonFunc.GetBrand(ddlSBU.SelectedValue, ddlCategory.SelectedValue, ddlunit.SelectedValue, ddlEntity.SelectedValue);
                            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                            {
                                ddlBrand.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["BRAND_CODE"].ToString()));
                            }

                            ddlBrand.ClearSelection();
                            ddlBrand.Items.FindByText(dt.Rows[i]["Column5"].ToString()).Selected = true;

                            ddlProduct.Items.Clear(); ddlProduct.Items.Add(new ListItem("--Select--", "0"));
                            ds = CommonFunc.Getproduct(ddlBrand.SelectedValue, ddlCategory.SelectedValue, ddlunit.SelectedValue, ddlSBU.SelectedValue, ddlEntity.SelectedValue);
                            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                            {
                                ddlProduct.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["PRODUCT_ID"].ToString()));
                            }
                            

                            ddlProduct.ClearSelection();
                            ddlProduct.Items.FindByText(dt.Rows[i]["Column6"].ToString()).Selected = true;


                            ddlExpCode.ClearSelection();
                            ddlExpCode.Items.FindByText(dt.Rows[i]["Column7"].ToString()).Selected = true;
                            ddlBudApp.Items.FindByText(dt.Rows[i]["Column10"].ToString()).Selected = true;

                            ds1 = CommonFunc.GetbudRefNo(ddlEntity.SelectedValue, ddlunit.SelectedValue, ddlSBU.SelectedValue, ddlCategory.SelectedValue, ddlBrand.SelectedValue, ddlProduct.SelectedValue, ddlDept.SelectedValue, ddlProject.SelectedValue, ddlExpCode.SelectedValue, lblFyear.Text,userid);
                            ddlBudRefNo.Items.Clear(); ddlBudRefNo.Items.Add(new ListItem("--Select--", "NA"));
                            for (int k = 0; k < ds1.Tables[0].Rows.Count; k++)
                            {
                                ddlBudRefNo.Items.Add(new ListItem(ds1.Tables[0].Rows[k]["BUDGET_REF_NO"].ToString(), ds1.Tables[0].Rows[k]["BUDGET_REF_NO"].ToString()));
                            }
                            ddlBudRefNo.ClearSelection();
                            ddlBudRefNo.Items.FindByText(dt.Rows[i]["Column11"].ToString()).Selected = true;
                            
                        }
                    }
                    else
                    {
                        //fill dropbox here

                        
                        
                    }

                    rowIndex++;
                }
            }
        }
    }

   

    protected void ButtonAdd_Click(object sender, EventArgs e)
    {
        AddNewRowToGrid();
    }

    protected void Gridview1_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable"];
            LinkButton lb = (LinkButton)e.Row.FindControl("LinkButton1");
            if (lb != null)
            {
                if (dt.Rows.Count > 1)
                {
                    if (e.Row.RowIndex == dt.Rows.Count - 1)
                    {
                        lb.Visible = false;
                    }
                }
                else
                {
                    lb.Visible = false;
                }
            }
        }
    }
    protected double getTotalAmount()
    {
        double total = 0;
        for (int i = 0; i < Gridview1.Rows.Count; i++)
        {
            TextBox lblamt = (TextBox)Gridview1.Rows[i].FindControl("txtAmount");
            total = total + Convert.ToDouble(lblamt.Text);
        }
        return total;
    }

    protected void LinkDelete_Click(object sender, EventArgs e)
    {
        LinkButton lb = (LinkButton)sender;
        GridViewRow gvRow = (GridViewRow)lb.NamingContainer;
        int rowID = gvRow.RowIndex;
        DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
        //DataRow drCurrentRow = null;
        Label SNHD_RECID = (Label)Gridview1.Rows[rowID].FindControl("lblid");
        TextBox txtAmount1 = (TextBox)Gridview1.Rows[rowID].FindControl("txtAmount");
        if (SNHD_RECID.Text != "")
        {
            ocon = CommonFunc.con();
            ocon.Open(); OracleTransaction trns = ocon.BeginTransaction();
            string qry = "";
            try
            {
                qry = " update SN_SANCTIONS_DETAILS set status='I'   where  SNSD_RECID= '" + SNHD_RECID.Text + "'  and  SANCTION_NO='" + lblSancNo.Text + "'";

                OracleCommand cmd = new OracleCommand(qry, ocon, trns);
                cmd.ExecuteNonQuery();

                //for (int i = 0; i < gvDetail.Rows.Count; i++)
                //{
                //    TextBox lblamt = (TextBox)gvDetail.Rows[i].FindControl("lblamt");
                //    Label lblsid = (Label)gvDetail.Rows[i].FindControl("lblsid");
                //    qry = " update SN_SANCTIONS_DETAILS set SANCTION_AMOUNT='" + lblamt.Text + "', LAST_UPD_BY='" + userid + "'  ,LAST_UPD_ON = to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + "', 'dd/mm/yyyy hh:mi:ss AM')   where  SNSD_RECID= '" + lblsid.Text + "'  and  SANCTION_NO='" + lblSancNo.Text + "'";

                //    cmd = new OracleCommand(qry, ocon, trns);
                //    cmd.ExecuteNonQuery();
                //}
                
                
                double total_amt = getTotalAmount();
                total_amt = total_amt - Convert.ToDouble(txtAmount1.Text);
                qry = " update SN_SANCTIONS set TOTAL_AMOUNT=  " + total_amt + "   where  SNS_RECID= '" + lblpid.Text + "'  and  SANCTION_NO='" + lblSancNo.Text + "'";
                
                cmd = new OracleCommand(qry, ocon,trns);
                cmd.ExecuteNonQuery();
                trns.Commit();
                txtTotal.Text = total_amt.ToString();
                //Server.Transfer("SanctionDetails.aspx?sid=" + recid);

            }
            catch (Exception ex)
            { trns.Rollback(); }
            finally { ocon.Close(); }
        }


        for (int i = 0; i < dtCurrentTable.Rows.Count; i++)
        {

            TextBox txtParticular = (TextBox)Gridview1.Rows[i].Cells[1].FindControl("txtParticular");
            TextBox txtDetail = (TextBox)Gridview1.Rows[i].Cells[2].FindControl("txtDetail");
            DropDownList ddlunit = (DropDownList)Gridview1.Rows[i].Cells[3].FindControl("ddlunit");
            DropDownList ddlCategory = (DropDownList)Gridview1.Rows[i].Cells[4].FindControl("ddlCategory");
            DropDownList ddlBrand = (DropDownList)Gridview1.Rows[i].Cells[5].FindControl("ddlBrand");

            DropDownList ddlProduct = (DropDownList)Gridview1.Rows[i].Cells[6].FindControl("ddlProduct");
            DropDownList ddlExpCode = (DropDownList)Gridview1.Rows[i].Cells[7].FindControl("ddlExpCode");
            TextBox txtAmount = (TextBox)Gridview1.Rows[i].Cells[8].FindControl("txtAmount");
            TextBox txtAmountGST = (TextBox)Gridview1.Rows[i].FindControl("txtAmountGST");
            DropDownList ddlBudRefNo = (DropDownList)Gridview1.Rows[i].Cells[7].FindControl("ddlBudRefNo");
            DropDownList ddlBudApp = (DropDownList)Gridview1.Rows[i].FindControl("ddlBudApp");

            // Update the DataRow with the DDL Selected Items 

            dtCurrentTable.Rows[i]["Column1"] = txtParticular.Text;
            dtCurrentTable.Rows[i]["Column2"] = txtDetail.Text;
            dtCurrentTable.Rows[i]["Column3"] = ddlunit.SelectedItem.Text;
            dtCurrentTable.Rows[i]["Column4"] = ddlCategory.SelectedItem.Text;
            dtCurrentTable.Rows[i]["Column5"] = ddlBrand.SelectedItem.Text;

            dtCurrentTable.Rows[i]["Column6"] = ddlProduct.SelectedItem.Text;
            dtCurrentTable.Rows[i]["Column7"] = ddlExpCode.SelectedItem.Text;
            dtCurrentTable.Rows[i]["Column8"] = txtAmount.Text;
            dtCurrentTable.Rows[i]["Column9"] = txtAmountGST.Text;
            dtCurrentTable.Rows[i]["Column10"] = ddlBudApp.SelectedItem.Text;
            dtCurrentTable.Rows[i]["Column11"] = ddlBudRefNo.SelectedItem.Text;
           // dtCurrentTable.Rows[i]["Column12"] = lblid.Text;

        }

        //Store the current data to ViewState for future reference 
        ViewState["CurrentTable"] = dtCurrentTable;


        if (ViewState["CurrentTable"] != null)
        {

            DataTable dt = (DataTable)ViewState["CurrentTable"];
            if (dt.Rows.Count > 1)
            {
                if (gvRow.RowIndex <= dt.Rows.Count - 1)
                {
                    //Remove the Selected Row data and reset row number
                    dt.Rows.Remove(dt.Rows[rowID]);
                    ResetRowID(dt);
                }
            }

            //Store the current data in ViewState for future reference
            ViewState["CurrentTable"] = dt;

            //Re bind the GridView for the updated data
            Gridview1.DataSource = dt;
            Gridview1.DataBind();
        }

        //Set Previous Data on Postbacks
        SetPreviousData();
    }

    private void ResetRowID(DataTable dt)
    {
        int rowNumber = 1;
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow row in dt.Rows)
            {
                row[0] = rowNumber;
                rowNumber++;
            }
        }
    }

    protected void TextChangedEvent(object sender, EventArgs e)
    {
        try
        {
            TextBox lb = (TextBox)sender;
            decimal total = 0;
            GridView Gridview1 = (GridView)(sender as TextBox).Parent.Parent.Parent.Parent;
            DataTable dt = (DataTable)ViewState["CurrentTable"];
            for (int i = 0; i < Gridview1.Rows.Count; i++)
            {
                TextBox txtWeightage = (TextBox)Gridview1.Rows[i].FindControl("txtAmount");
                if (txtWeightage.Text != "")
                    total += Convert.ToDecimal(txtWeightage.Text);
            }
            
            txtTotal.Text = total.ToString();
        }
        catch (Exception ex)
        {
            CommonFunc.ShowAlert("Some error found. err msg :" + ex.Message);
        }
    }
    protected void lnkMaster_Click(object sender, EventArgs e)
    {
        if (ddlDept.SelectedIndex > 0 && ddlEntity.SelectedIndex > 0)
        {

            getData(ddlDept.SelectedValue);
            //pnlDetail.Visible = true;
            pnlCustom.Visible = false;
            pnlMain.Visible = false;
            pnlgrid.Visible = false;
            //         Session["dept"] = ddlDept.SelectedValue;
            //         Page.ClientScript.RegisterStartupScript(
            //this.GetType(), "OpenWindow", "window.open('ShowSN_HIERARCHY.aspx','_newtab');", true);
        }
        else
        {
            CommonFunc.ShowAlert("Select Department & Entity");
        }
    }
    protected void getData(string deptcode)
    {
        ocon = CommonFunc.con();
        string qry = "select SNH_RECID, (select LEGAL_NAME from OC_ENTITY where ENTITY_CODE= s.ENTITY_CODE) ENTITY_CODE1,ENTITY_CODE || ',' || HIERARCHY_CODE ENTITY_CODE,(SELECT department_desc FROM ALL_DEPARTMENTS  where DEPARTMENT_CODE =   s.DEPT_CODE and company='DS') DEPT_CODE1, upper(HIERARCHY_CODE) HIERARCHY_CODE,upper(DESCRIPTION) DESCRIPTION from  SN_HIERARCHY s where DEPT_CODE = '" + deptcode + "' and  ENTITY_CODE='"+ddlEntity.SelectedValue+"'";
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvData.DataSource = ds;
            gvData.DataBind();
        }
    }
    protected void gvData_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "show")
        {
            string id = e.CommandArgument.ToString();
            int k = id.IndexOf(',');
            string ecode = id.Substring(0, k);
            string hcode = id.Substring(k + 1);

            ocon = CommonFunc.con();
            string qry = "select SNHD_RECID, (select LEGAL_NAME from OC_ENTITY where ENTITY_CODE= s.ENTITY_CODE) ENTITY_CODE1,ENTITY_CODE,HIERARCHY_CODE,S_NO, (select employee_name from hrm_employee where EMP_CODE= s.EMP_CODE) EMP_CODE, ";
            qry += " case when  MANDATORY= 'Y' then 'Yes' else 'No' end MANDATORY, case when  ROLE= 'I' then 'Initiator' when  ROLE= 'R' then 'Reviewer' else 'Approver' end ROLE  from SN_HIERARCHY_DETAIL s where ENTITY_CODE= '" + ecode + "' and HIERARCHY_CODE='" + hcode + "'";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvDetail.DataSource = ds;
                gvDetail.DataBind();
                gvDetail.Visible = true;
            }
            else
                gvDetail.Visible = false;
        }
        if (e.CommandName == "select")
        {
            string id = e.CommandArgument.ToString();
            lblHierarcode.Text = id;
            GridViewRow row = (GridViewRow)((LinkButton)e.CommandSource).NamingContainer;
            row.BackColor = System.Drawing.Color.Yellow;
            lblHCode.Text = "Selected Hierarchy code " + row.Cells[3].Text;
            CommonFunc.ShowAlert("Hierarchy Selected.");
            ViewState["CurrentTable1"] = null;
        }
    }

    protected void GetSelectedRecord(object sender, EventArgs e)
    {

        for (int i = 0; i < gvData.Rows.Count; i++)
        {

            RadioButton rb = (RadioButton)gvData.Rows[i].FindControl("RadioButton2");

            if (rb != null)
            {
                if (rb.Checked)
                {
                    HiddenField hf = (HiddenField)gvData.Rows[i].Cells[0].FindControl("HiddenField1");
                    if (hf != null)
                    {
                        ViewState["SelectedContact"] = hf.Value;
                        lblHCode.Text = "Selected Hierarchy code " + hf.Value;
                        lblHierarcode.Text = hf.Value;
                        ViewState["CurrentTable1"] = null;
                        CommonFunc.ShowAlert("Hierarchy Selected.");
                    }
                    btnSave.Enabled = true;
                    break;
                }
            }
        }
    }

    protected void lnkClose2_Click(object sender, EventArgs e)
    {
        pnlDetail.Visible = false;
        pnlgrid.Visible = true;
        pnlMain.Visible = true;
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (ddlEntity.SelectedIndex < 0)
        {
            CommonFunc.ShowAlert("kindly select Entity.");
        }
        if (ddlSBU.SelectedIndex < 0)
        {
            CommonFunc.ShowAlert("kindly select SBU.");
        }
        if (ddlDept.SelectedIndex < 0)
        {
            CommonFunc.ShowAlert("kindly select Department.");
        }
        if (ddlProject.SelectedIndex < 0)
        {
            CommonFunc.ShowAlert("kindly select Project.");
        }
        lblmsg.Text = "";

        //btnSave.Enabled = false; 
        string hcode = "NA";
        ocon = CommonFunc.con(); ocon.Open(); OracleTransaction trns = ocon.BeginTransaction(); ; OracleCommand cmd; string qry = "";
        try
        {
            if (lblHCode.Text != "NA")
            {
                if (lblHCode.Text.ToUpper().Contains("CUSTOM"))
                {
                    hcode = "CUSTOM";
                }
                else
                {
                    hcode = lblHCode.Text;
                }
            }
            else
            {
                CommonFunc.ShowAlert("Select H Code"); 
            }

            string q = "";
            q = "SELECT DEPARTMENT_CODE   FROM ALL_DEPARTMENTS A    WHERE HRIS_DEPT_CODE = '" + ddlDept.SelectedValue + "'     AND COMPANY = 'DS'     AND STATUS = 'A'    AND ROWNUM <= 1 ";
            OracleCommand cmd1 = new OracleCommand(q, ocon, trns);
            string dept_code = cmd1.ExecuteScalar().ToString();

            q = "SELECT distinct(a.hris_FUNCtion_CODE)   FROM PROJECTS A, HRM_FUNCTION B, HRM_MAPPING_DEPT_FUNCTIONS C WHERE A.COMPANY = 'DS' AND A.HRIS_FUNCTION_CODE = B.FUNC_CODE AND A.STATUS  =  'A' AND A.HRIS_FUNCTION_CODE = C.FUNC_CODE  and C.DEPT_CODE= '" + ddlDept.SelectedValue + "'  and a.PROJECT='" + ddlProject.SelectedItem.Value + "'";
            cmd1 = new OracleCommand(q, ocon, trns);
            string hris_func_code = cmd1.ExecuteScalar().ToString();
            
            ///////correction
            
            //qry= "insert into SN_SANCTIONS (SNS_RECID,ENTITY_CODE,SANCTION_NO,SANCTION_DATE,FISCAL_YEAR,SBU_CODE,DEPT_CODE,HRIS_DEPT_CODE,PROJECT,HRIS_FUNCTION_CODE,VERSION_NO,HIERARCHY_CODE,SANCTION_SOUGHT_FOR,TOTAL_AMOUNT,BACKGROUD_INFO,CRITICAL_ISSUES_DETAIL,STATUS,CREATED_BY,CREATED_ON) ";
            //qry += " values ('" + pid + "','" + ddlEntity.SelectedValue + "','" + sancNo + "',to_date('" + DateTime.Now.ToString("dd/MM/yyyy") + "', 'dd/mm/yyyy'),'" + lblFyear.Text + "','" + ddlSBU.SelectedValue + "','" + ddlDept.SelectedValue + "','HR_DC' ,'" + ddlProject.SelectedValue + "','HR_FC','" + lblVersion.Text + "','" + lblHierarcode.Text + "','" + Server.HtmlEncode(txtSoughtFor.Text) + "','" + txtTotal.Text + "','" + Server.HtmlEncode(txtBack.Text) + "','" + Server.HtmlEncode(txtIssue.Text) + "','A','" + userid + "',to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + "', 'dd/mm/yyyy hh:mi:ss AM'))";

            qry = "update SN_SANCTIONS set ENTITY_CODE='" + ddlEntity.SelectedValue + "',SBU_CODE='" + ddlSBU.SelectedValue + "',DEPT_CODE='" + dept_code + "',HRIS_DEPT_CODE='" + ddlDept.SelectedValue + "',PROJECT='" + ddlProject.SelectedValue + "',HRIS_FUNCTION_CODE='" + hris_func_code + "',VERSION_NO='" + lblVersion.Text + "',HIERARCHY_CODE='" + lblHierarcode.Text + "',SANCTION_SOUGHT_FOR='" + Server.HtmlEncode(txtSoughtFor.Text) + "',TOTAL_AMOUNT='" + txtTotal.Text + "',BACKGROUD_INFO='" + Server.HtmlEncode(txtBack.Text) + "',CRITICAL_ISSUES_DETAIL='" + Server.HtmlEncode(txtIssue.Text) + "' ,LAST_UPD_BY ='" + userid + "', LAST_UPD_ON=to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + "', 'dd/mm/yyyy hh:mi:ss AM')   where SNS_RECID= '" + lblpid.Text + "'";
            cmd = new OracleCommand(qry, ocon, trns);
            cmd.ExecuteNonQuery(); string unit = ""; string sbu_cat_code = ""; string isNonBud = "Y";
            
            for (int a = 0; a < Gridview1.Rows.Count; a++)
            {
                TextBox txtParticular = (TextBox)Gridview1.Rows[a].FindControl("txtParticular");
                TextBox txtDetail = (TextBox)Gridview1.Rows[a].FindControl("txtDetail");
                DropDownList ddlunit = (DropDownList)Gridview1.Rows[a].FindControl("ddlunit");
                DropDownList ddlCategory = (DropDownList)Gridview1.Rows[a].FindControl("ddlCategory");
                DropDownList ddlBrand = (DropDownList)Gridview1.Rows[a].FindControl("ddlBrand");
                DropDownList ddlProduct = (DropDownList)Gridview1.Rows[a].FindControl("ddlProduct");
                DropDownList ddlExpCode = (DropDownList)Gridview1.Rows[a].FindControl("ddlExpCode");
                TextBox txtAmount = (TextBox)Gridview1.Rows[a].FindControl("txtAmount");
                TextBox txtAmountGST = (TextBox)Gridview1.Rows[a].FindControl("txtAmountGST");
                DropDownList ddlBudRefNo = (DropDownList)Gridview1.Rows[a].FindControl("ddlBudRefNo");
                DropDownList ddlBudApp = (DropDownList)Gridview1.Rows[a].FindControl("ddlBudApp");
                Label lblid = (Label)Gridview1.Rows[a].FindControl("lblid");
                string bamount="0" ,camount="0";
                string seqno = Gridview1.Rows[a].Cells[0].Text.ToString();

                DataSet ds1 = CommonFunc.GetbudRefNo(ddlEntity.SelectedValue, ddlunit.SelectedValue, ddlSBU.SelectedValue, ddlCategory.SelectedValue, ddlBrand.SelectedValue, ddlProduct.SelectedValue, ddlDept.SelectedValue, ddlProject.SelectedValue, ddlExpCode.SelectedValue, lblFyear.Text,userid);
                if (ds1.Tables[0].Rows.Count > 0)
                {
                     bamount = ds1.Tables[0].Rows[0]["BUDGET_AMOUNT"].ToString();
                     //camount = ds1.Tables[0].Rows[0]["CONSUMED_AMOUNT"].ToString();
                     budgetEmpCode = ds1.Tables[0].Rows[0]["emp_code"].ToString();
                }

                if (unit != "" && !unit.Contains(ddlunit.SelectedValue))
                        unit += "," + ddlunit.SelectedValue;
                    else if (unit == "")
                        unit = ddlunit.SelectedValue;
                if(a==0)
                    sbu_cat_code = ddlCategory.SelectedValue;

                    
                decimal amtupto = 0;


                if (ddlBudApp.SelectedValue == "Y")
                {
                    if (ddlBudRefNo.SelectedIndex <= 0)
                    {
                        CommonFunc.ShowAlert("Select Ref No Row No: " + (a + 1).ToString());
                        trns.Rollback(); return;
                    }
                    DataSet ds11 = CommonFunc.GetbudAmountTotal(ddlEntity.SelectedValue, ddlunit.SelectedValue, ddlSBU.SelectedValue, ddlCategory.SelectedValue, ddlBrand.SelectedValue, ddlProduct.SelectedValue, ddlDept.SelectedValue, ddlProject.SelectedValue, ddlExpCode.SelectedValue, lblFyear.Text, ddlBudRefNo.SelectedValue, budgetEmpCode);
                    if (ds11.Tables[0].Rows.Count > 0)
                    {
                        //string aa = ds11.Tables[0].Rows[0][0].ToString() + " " + ds1.Tables[0].Rows[0][1].ToString() + " " + ds1.Tables[0].Rows[0][2].ToString() + " " + ds1.Tables[0].Rows[0][3].ToString() + " " + ds1.Tables[0].Rows[0][4].ToString();
                        amtupto = Convert.ToDecimal(ds11.Tables[0].Rows[0]["AVAILABLE_AMT"].ToString());
                        //CommonFunc.ShowAlert(aa);
                    }
                    ds = CommonFunc.GetUNITWarning(ddlEntity.SelectedValue, ddlSBU.SelectedValue, ddlunit.SelectedValue);
                    //if (ds.Tables[0].Rows[0][0].ToString() == "E")
                    //{
                    if (txtAmount.Text != "")
                        {
                            if (amtupto < Convert.ToDecimal(txtAmount.Text))
                            {
                                CommonFunc.ShowAlert("Amount requested for in this sanction note is more than balance available in budget. Hence get the budget revised OR create sanction note for unbudgeted amount for " + ddlExpCode.SelectedValue + " at S.No. " + (a + 1).ToString());
                                trns.Rollback(); return;
                            }
                        }
                    if (ds.Tables[0].Rows[0][0].ToString() == "W")
                    {
                        if (txtTotal.Text != "")
                            if (amtupto < Convert.ToDecimal(txtTotal.Text))
                            {
                                CommonFunc.ShowAlert("Warning: Sanction Amount exceeding.");
                            }
                    }
                }
                else
                {
                    isNonBud = "N";
                }
                

                //qry = "insert into SN_SANCTIONS_DETAILS (SNSD_RECID,PARENT_RECID,ENTITY_CODE,SANCTION_NO,SANCTION_DATE,SBU_CATEGORY_CODE,BRAND_CODE,PRODUCT_ID,SEQ_NO,PARTICULARS,SPECIFICATIONS,BUDGET_APPROVED,BUDGET_REF_NO,SANCTION_AMOUNT,BUDGET_AMOUNT,CONSUMED_AMOUNT,BALANCE_AMOUNT,CREATED_BY,CREATED_ON) ";
                //qry += " values (imis_reci.nextval,'" + pid + "','" + ddlEntity.SelectedValue + "','" + sancNo + "',to_date('" + DateTime.Now.ToString("dd/MM/yyyy") + "', 'dd/mm/yyyy'),'" + ddlunit.SelectedValue + "','" + ddlBrand.SelectedValue + "','" + ddlProduct.SelectedValue + "','" + seqno + "','" + Server.HtmlEncode(txtParticular.Text) + "','" + Server.HtmlEncode(txtIssue.Text) + "','" + ddlBudApp.SelectedValue + "','" + ddlBudRefNo.SelectedValue + "','" + txtAmount.Text + "','" + bamount + "','" + camount + "','0','" + userid + "',to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + "', 'dd/mm/yyyy hh:mi:ss AM'))";
                qry = "select count(SEQ_NO) from SN_SANCTIONS_DETAILS where SEQ_NO= '" + seqno + "' and PARENT_RECID = '" + lblpid.Text + "'";
                cmd = new OracleCommand(qry, ocon, trns);
                int k=  Convert.ToInt32(cmd.ExecuteScalar());
                if (k > 0)
                {
                    qry = "update SN_SANCTIONS_DETAILS set OU_CODE= '" + ddlunit.SelectedValue + "',  SBU_CATEGORY_CODE ='" + ddlCategory.SelectedValue + "',BRAND_CODE = '" + ddlBrand.SelectedValue + "',PRODUCT_ID ='" + ddlProduct.SelectedValue + "',SEQ_NO='" + seqno + "',PARTICULARS= '" + Server.HtmlEncode(txtParticular.Text) + "',SPECIFICATIONS='" + Server.HtmlEncode(txtDetail.Text) + "',BUDGET_APPROVED= '" + ddlBudApp.SelectedValue + "',BUDGET_REF_NO= '" + ddlBudRefNo.SelectedValue + "',SANCTION_AMOUNT ='" + txtAmount.Text + "',SANCTION_AMOUNT_GST= '"+txtAmountGST.Text+"' , EXPENSE_CODE_BUDGET= '" + ddlExpCode.SelectedValue + "',LAST_UPD_BY ='" + userid + "', LAST_UPD_ON=to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + "', 'dd/mm/yyyy hh:mi:ss AM'),STATUS='A',SBU_CODE ='" + ddlSBU.SelectedValue + "',HRIS_DEPT_CODE='" + ddlDept.SelectedValue + "' ,HRIS_FUNCTION_CODE='" + ddlProject.SelectedValue + "'  where SEQ_NO= '" + seqno + "' and PARENT_RECID = '" + lblpid.Text + "'";
                    cmd = new OracleCommand(qry, ocon, trns);
                    cmd.ExecuteNonQuery();
                }
                else
                {
                    //qry = "insert into SN_SANCTIONS_DETAILS (SNSD_RECID,PARENT_RECID,ENTITY_CODE,SANCTION_NO,SANCTION_DATE,SBU_CATEGORY_CODE,BRAND_CODE,PRODUCT_ID,SEQ_NO,PARTICULARS,SPECIFICATIONS,BUDGET_APPROVED,BUDGET_REF_NO,SANCTION_AMOUNT,BUDGET_AMOUNT,CONSUMED_AMOUNT,BALANCE_AMOUNT,CREATED_BY,CREATED_ON,OU_CODE,EXPENSE_CODE_BUDGET,SANCTION_AMOUNT_GST) ";
                    //qry += " values (portal_RECID.nextval,'" + lblpid.Text + "','" + ddlEntity.SelectedValue + "','" + lblSancNo.Text + "',to_date('" + DateTime.Now.ToString("dd/MM/yyyy") + "', 'dd/mm/yyyy'),'" + ddlCategory.SelectedValue + "','" + ddlBrand.SelectedValue + "','" + ddlProduct.SelectedValue + "','" + seqno + "','" + Server.HtmlEncode(txtParticular.Text) + "','" + Server.HtmlEncode(txtDetail.Text) + "','" + ddlBudApp.SelectedValue + "','" + ddlBudRefNo.SelectedValue + "','" + txtAmount.Text + "','" + bamount + "','" + camount + "','0','" + userid + "',to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + "', 'dd/mm/yyyy hh:mi:ss AM'),'" + ddlunit.SelectedValue + "','" + ddlExpCode.SelectedValue + "','" + txtAmountGST.Text + "')";
                    //cmd = new OracleCommand(qry, ocon, trns);
                    //cmd.ExecuteNonQuery();
                    qry = "insert into SN_SANCTIONS_DETAILS (SNSD_RECID,PARENT_RECID,ENTITY_CODE,SANCTION_NO,SANCTION_DATE,SBU_CATEGORY_CODE,BRAND_CODE,PRODUCT_ID,SEQ_NO,PARTICULARS,SPECIFICATIONS,BUDGET_APPROVED,BUDGET_REF_NO,SANCTION_AMOUNT,BUDGET_AMOUNT,CONSUMED_AMOUNT,BALANCE_AMOUNT,CREATED_BY,CREATED_ON,OU_CODE,EXPENSE_CODE_BUDGET,STATUS,SBU_CODE ,HRIS_DEPT_CODE ,HRIS_FUNCTION_CODE,emp_code,SANCTION_AMOUNT_GST) ";
                    qry += " values (portal_RECID.nextval,'" + lblpid.Text + "','" + ddlEntity.SelectedValue + "','" + lblSancNo.Text + "',to_date('" + DateTime.Now.ToString("dd/MM/yyyy") + "', 'dd/mm/yyyy'),'" + ddlCategory.SelectedValue + "','" + ddlBrand.SelectedValue + "','" + ddlProduct.SelectedValue + "','" + seqno + "','" + Server.HtmlEncode(txtParticular.Text) + "','" + Server.HtmlEncode(txtDetail.Text) + "','" + ddlBudApp.SelectedValue + "','" + ddlBudRefNo.SelectedValue + "','" + txtAmount.Text + "','" + bamount + "','" + camount + "','0','" + userid + "',to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + "', 'dd/mm/yyyy hh:mi:ss AM'),'" + ddlunit.SelectedValue + "','" + ddlExpCode.SelectedValue + "','A','" + ddlSBU.SelectedValue + "','" + ddlDept.SelectedValue + "', '" + ddlProject.SelectedValue + "','" + budgetEmpCode + "','" + txtAmountGST.Text + "')";
                    cmd = new OracleCommand(qry, ocon, trns);
                    cmd.ExecuteNonQuery();
                }
                
            }

            if (lblStatus.Text == "E" || lblStatus.Text == "N")
            {
                qry = "delete from SN_SANCTION_APPROVALS where PARENT_RECID = '" + lblpid.Text + "' and SANCTION_NO = '" + lblSancNo.Text + "' and APPROVED_BY  is null and s_no<>0";
                cmd = new OracleCommand(qry, ocon, trns);
                cmd.ExecuteNonQuery();
                string[] arr = unit.Split(',');
                if (arr.Length == 1)
                {
                    qry = "select PARENT_RECID,S_NO, EMP_CODE,MANDATORY,ROLE  from SN_HIERARCHY_DETAIL where PARENT_RECID in (select PARENT_RECID  from SN_HIERARCHY_DETAIL where   EMP_CODE='" + userid + "' and ROLE='I' ) and role<>'I' and PARENT_RECID in ";
                    qry += " (select SNH_RECID from SN_HIERARCHY where OU_CODE ='" + arr[0] + "' and SBU_CODE ='" + ddlSBU.SelectedValue + "' and SBU_CATEGORY_CODE ='" + sbu_cat_code + "' and DEPT_CODE='" + ddlDept.SelectedValue + "' and STATUS='A'  and    FROM_LIMIT_AMT<='" + txtTotal.Text + "' and nvl(TO_LIMIT_AMT,'10000000000000000') >='" + txtTotal.Text + "')  ";
                }
                else
                {
                    qry = "select PARENT_RECID,S_NO, EMP_CODE,MANDATORY,ROLE  from SN_HIERARCHY_DETAIL where PARENT_RECID in (select PARENT_RECID  from SN_HIERARCHY_DETAIL where   EMP_CODE='" + userid + "' and ROLE='I' ) and role<>'I' and PARENT_RECID in ";
                    qry += " (select SNH_RECID from SN_HIERARCHY where OU_CODE ='" + arr[0] + "' and SBU_CODE ='" + ddlSBU.SelectedValue + "' and SBU_CATEGORY_CODE ='" + sbu_cat_code + "' and DEPT_CODE='" + ddlDept.SelectedValue + "' and STATUS='A'  and    FROM_LIMIT_AMT<='" + txtTotal.Text + "' and nvl(TO_LIMIT_AMT,'10000000000000000') >='" + txtTotal.Text + "')  ";
                
                    //qry = "select PARENT_RECID,S_NO, EMP_CODE,MANDATORY,ROLE  from SN_HIERARCHY_DETAIL where PARENT_RECID in (select PARENT_RECID  from SN_HIERARCHY_DETAIL where   EMP_CODE='" + userid + "' and ROLE='I' ) and role<>'I' and PARENT_RECID in ";
                    //qry += " (select SNH_RECID from SN_HIERARCHY where OU_CODE ='" + arr[0] + "' and SBU_CODE ='" + ddlSBU.SelectedValue + "'  and SBU_CATEGORY_CODE ='" + sbu_cat_code + "' and DEPT_CODE='" + ddlDept.SelectedValue + "' and STATUS='A'  and    FROM_LIMIT_AMT<='" + txtTotal.Text + "' and and nvl(TO_LIMIT_AMT,'10000000000000000') >'" + txtTotal.Text + "')  ";
                }
                if (isNonBud == "N")
                {
                    qry = "select PARENT_RECID,S_NO, EMP_CODE,MANDATORY,ROLE  from SN_HIERARCHY_DETAIL where PARENT_RECID in (select PARENT_RECID  from SN_HIERARCHY_DETAIL where   EMP_CODE='" + userid + "' and ROLE='I' ) and role<>'I' and PARENT_RECID in ";
                    qry += " (select SNH_RECID from SN_HIERARCHY where OU_CODE ='" + arr[0] + "' and SBU_CODE ='" + ddlSBU.SelectedValue + "' and SBU_CATEGORY_CODE ='" + sbu_cat_code + "' and DEPT_CODE='" + ddlDept.SelectedValue + "' and STATUS='A'  and    FROM_LIMIT_AMT is null and TO_LIMIT_AMT is null )  ";
                }
                cmd = new OracleCommand(qry, ocon, trns);
                //cmd.ExecuteNonQuery();
                da = new OracleDataAdapter(cmd);
                ds = new DataSet();
                da.Fill(ds);
                //ds = CommonFunc.GetHierarchy_Detail(lblHierarcode.Text, ddlEntity.SelectedValue);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    qry = "update SN_SANCTIONS set HIERARCHY_CODE= '" + ds.Tables[0].Rows[0]["PARENT_RECID"].ToString() + "' where SNS_RECID= '" + lblpid.Text + "'";
                    cmd = new OracleCommand(qry, ocon, trns);
                    cmd.ExecuteNonQuery();
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        DataRow dr = ds.Tables[0].Rows[i];
                        qry = "insert into   SN_SANCTION_APPROVALS (SNSA_RECID,ENTITY_CODE,SANCTION_NO,PARENT_RECID,HIERARCHY_CODE,S_NO,EMP_CODE,SKIPPED,ROLE) ";
                        qry += " values (portal_RECID.nextval,'" + ddlEntity.SelectedValue + "','" + lblSancNo.Text + "','" + lblpid.Text + "','" + dr["PARENT_RECID"].ToString() + "','" + dr["S_NO"].ToString() + "','" + dr["EMP_CODE"].ToString() + "','" + dr["MANDATORY"].ToString() + "','" + dr["ROLE"].ToString() + "')";
                        cmd = new OracleCommand(qry, ocon, trns);
                        cmd.ExecuteNonQuery();
                    }
                }
                else
                {
                    CommonFunc.ShowAlert("Approval process not exists for this selection.");
                    trns.Rollback(); return;
                }

            }
            else if (lblStatus.Text == "P")
            {
                // approval
            }
            
            trns.Commit();
            CommonFunc.ShowAlert("Data saved sucessfully. kindly attached file(s) if any.");
            lnkAttach.Visible = true;
            Session["flag"] = lblpid.Text;
        }
        catch (Exception ex)
        {
            trns.Rollback();
            lblmsg.Text = ex.Message;
            CommonFunc.ShowAlert("Error : " + ex.Message);
        }
        finally { ocon.Close(); }
    }
    protected void lnkCustom_Click(object sender, EventArgs e)
    {
        if (ddlDept.SelectedIndex > 0 && ddlEntity.SelectedIndex > 0)
        {
            if (ViewState["CurrentTable1"] != null)
            {
                //DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable1"];
            }
            else
            {
                if (lblHierarcode.Text != "")
                {
                    DataSet myds = new DataSet();
                    myds = CommonFunc.GetHierarchy_Detail(lblHierarcode.Text, ddlEntity.SelectedValue);
                    SetInitialRow1();
                    if (myds.Tables[0].Rows.Count > 0)
                    {
                        for (int i = 0; i < myds.Tables[0].Rows.Count - 1; i++)
                        {
                            AddNewRowToGrid1();
                        }
                        for (int i = 0; i < myds.Tables[0].Rows.Count; i++)
                        {
                            //ddlEmp ddlM ddlRole  S_NO,EMP_CODE,MANDATORY,  SNHD_RECID SNHD_RECID
                            DataRow dr = myds.Tables[0].Rows[i];
                            DropDownList ddlEmp = (DropDownList)gvNew.Rows[i].FindControl("ddlEmp");
                            DropDownList ddlM = (DropDownList)gvNew.Rows[i].FindControl("ddlM");
                            DropDownList ddlRole = (DropDownList)gvNew.Rows[i].FindControl("ddlRole");
                            Label SNHD_RECID = (Label)gvNew.Rows[i].FindControl("SNHD_RECID");
                            LinkButton LinkDelete = (LinkButton)gvNew.Rows[i].FindControl("LinkDelete");
                            gvNew.Rows[i].Cells[0].Text = dr["S_NO"].ToString();
                            ddlEmp.ClearSelection();
                            ddlEmp.Items.FindByValue(dr["EMP_CODE"].ToString()).Selected = true;
                            ddlM.ClearSelection();
                            ddlM.Items.FindByValue(dr["MANDATORY"].ToString()).Selected = true;
                            ddlRole.ClearSelection();
                            ddlRole.Items.FindByValue(dr["ROLE"].ToString()).Selected = true;
                            SNHD_RECID.Text = dr["SNHD_RECID"].ToString();
                            if (SNHD_RECID.Text != "")
                                LinkDelete.Visible = false;
                        }
                    }
                    pnlCustom.Visible = true;
                    pnlDetail.Visible = false;
                    pnlMain.Visible = false;
                    pnlgrid.Visible = false;
                }
                else
                {
                    CommonFunc.ShowAlert("Select Hierarchy to edit");
                }
            }
            //else SetInitialRow1();
            //pnlCustom.Visible = true;
            //pnlDetail.Visible = false;
            //pnlMain.Visible = false;
            //pnlgrid.Visible = false;
            //lblHCode.Text = ""
            //Session["dept"] = ddlDept.SelectedValue;
            //Session["entity"] = ddlEntity.SelectedValue;
            //        Page.ClientScript.RegisterStartupScript(
            //this.GetType(), "OpenWindow", "window.open('Custom_HIERARCHY.aspx','_newtab');", true);
            lblHCode.Text = "Custom HIERARCHY";
        }
        else
        {
            CommonFunc.ShowAlert("select Department & Entity.");
        }
    }

    protected void Linkshow_Click(object sender, EventArgs e)
    {
        pnlCustom.Visible = true;
    }


    /******************************************/
    private void FillDropDownList1(DropDownList ddl)
    {
        // ArrayList arr = GetDummyData();
        if (ddlDept.SelectedIndex > 0)
        {
            ds = CommonFunc.GetEmpList(ddlDept.SelectedValue);
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                ddl.Items.Add(new ListItem(ds.Tables[0].Rows[k]["employee_name"].ToString(), ds.Tables[0].Rows[k]["emp_code"].ToString()));
            }
        }
        else
        {
            CommonFunc.ShowAlert("select Department ");
        }
    }

    private void SetInitialRow1()
    {

        DataTable dt = new DataTable();
        DataRow dr = null;

        dt.Columns.Add(new DataColumn("RowNumber", typeof(string)));
        dt.Columns.Add(new DataColumn("Column1", typeof(string)));//for TextBox value 
        dt.Columns.Add(new DataColumn("Column2", typeof(string)));//for TextBox value 
        dt.Columns.Add(new DataColumn("Column3", typeof(string)));//for DropDownList selected item 
        dt.Columns.Add(new DataColumn("Column4", typeof(string)));//for DropDownList selected item 
        dt.Columns.Add(new DataColumn("Column5", typeof(string)));
        dt.Columns.Add(new DataColumn("Column6", typeof(string)));

        dr = dt.NewRow();
        dr["RowNumber"] = 1;
        dr["Column1"] = string.Empty;
        dr["Column2"] = string.Empty;
        dt.Rows.Add(dr);

        //Store the DataTable in ViewState for future reference 
        ViewState["CurrentTable1"] = dt;

        //Bind the Gridview 
        gvNew.DataSource = dt;
        gvNew.DataBind();

        //After binding the gridview, we can then extract and fill the DropDownList with Data 
        DropDownList ddlEmp = (DropDownList)gvNew.Rows[0].Cells[1].FindControl("ddlEmp");
        //DropDownList ddl2 = (DropDownList)Gridview1.Rows[0].Cells[4].FindControl("DropDownList2");
        FillDropDownList1(ddlEmp);

    }

    private void AddNewRowToGrid1()
    {

        if (ViewState["CurrentTable1"] != null)
        {

            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable1"];
            DataRow drCurrentRow = null;

            if (dtCurrentTable.Rows.Count > 0)
            {
                drCurrentRow = dtCurrentTable.NewRow();
                drCurrentRow["RowNumber"] = dtCurrentTable.Rows.Count + 1;

                //add new row to DataTable 
                dtCurrentTable.Rows.Add(drCurrentRow);


                for (int i = 0; i < dtCurrentTable.Rows.Count - 1; i++)
                {

                    DropDownList ddlEmp = (DropDownList)gvNew.Rows[i].Cells[3].FindControl("ddlEmp");
                    DropDownList ddlM = (DropDownList)gvNew.Rows[i].Cells[4].FindControl("ddlM");
                    DropDownList ddlRole = (DropDownList)gvNew.Rows[i].Cells[4].FindControl("ddlRole");
                    LinkButton LinkDelete = (LinkButton)gvNew.Rows[i].FindControl("LinkDelete");
                    Label SNHD_RECID = (Label)gvNew.Rows[i].FindControl("SNHD_RECID");

                    // Update the DataRow with the DDL Selected Items 

                    dtCurrentTable.Rows[i]["Column1"] = ddlEmp.SelectedItem.Text;
                    dtCurrentTable.Rows[i]["Column2"] = ddlM.SelectedItem.Text;
                    dtCurrentTable.Rows[i]["Column3"] = ddlRole.SelectedItem.Text;
                    dtCurrentTable.Rows[i]["Column4"] = LinkDelete.Text;
                    dtCurrentTable.Rows[i]["Column5"] = SNHD_RECID.Text;

                }

                //Store the current data to ViewState for future reference 
                ViewState["CurrentTable1"] = dtCurrentTable;


                //Rebind the Grid with the current data to reflect changes 
                gvNew.DataSource = dtCurrentTable;
                gvNew.DataBind();
            }
        }
        else
        {
            Response.Write("ViewState is null");

        }
        //Set Previous Data on Postbacks 
        SetPreviousData1();
    }

    private void SetPreviousData1()
    {

        int rowIndex = 0;
        if (ViewState["CurrentTable1"] != null)
        {

            DataTable dt = (DataTable)ViewState["CurrentTable1"];
            if (dt.Rows.Count > 0)
            {

                for (int i = 0; i < dt.Rows.Count; i++)
                {

                    //TextBox box1 = (TextBox)Gridview1.Rows[i].Cells[1].FindControl("TextBox1");
                    //TextBox box2 = (TextBox)Gridview1.Rows[i].Cells[2].FindControl("TextBox2");

                    DropDownList ddlEmp = (DropDownList)gvNew.Rows[i].Cells[3].FindControl("ddlEmp");
                    DropDownList ddlM = (DropDownList)gvNew.Rows[i].Cells[4].FindControl("ddlM");
                    DropDownList ddlRole = (DropDownList)gvNew.Rows[i].Cells[4].FindControl("ddlRole");
                    LinkButton LinkDelete = (LinkButton)gvNew.Rows[i].FindControl("LinkDelete");
                    Label SNHD_RECID = (Label)gvNew.Rows[i].FindControl("SNHD_RECID");

                    //Fill the DropDownList with Data 
                    FillDropDownList1(ddlEmp);
                    //FillDropDownList(ddl2);

                    if (i < dt.Rows.Count)
                    {

                        //Assign the value from DataTable to the TextBox 
                        //box1.Text = dt.Rows[i]["Column1"].ToString();
                        //box2.Text = dt.Rows[i]["Column2"].ToString();

                        //Set the Previous Selected Items on Each DropDownList  on Postbacks 
                        if (dt.Rows[i]["Column1"].ToString() != "")
                        {
                            ddlEmp.ClearSelection();
                            ddlEmp.Items.FindByText(dt.Rows[i]["Column1"].ToString()).Selected = true;

                            ddlM.ClearSelection();
                            ddlM.Items.FindByText(dt.Rows[i]["Column2"].ToString()).Selected = true;

                            ddlRole.ClearSelection();
                            ddlRole.Items.FindByText(dt.Rows[i]["Column3"].ToString()).Selected = true;
                            SNHD_RECID.Text = dt.Rows[i]["Column5"].ToString();

                        }
                        if (SNHD_RECID.Text != "")
                            LinkDelete.Visible = false;
                        else
                            LinkDelete.Visible = true;
                    }

                    rowIndex++;
                }
            }
        }
    }

    protected void gvNew_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable1"];
            LinkButton lb = (LinkButton)e.Row.FindControl("LinkButton1");
            if (lb != null)
            {
                if (dt.Rows.Count > 1)
                {
                    if (e.Row.RowIndex == dt.Rows.Count - 1)
                    {
                        lb.Visible = false;
                    }
                }
                else
                {
                    lb.Visible = false;
                }
            }
        }
    }

    protected void LinkDelete_Click1(object sender, EventArgs e)
    {
        LinkButton lb = (LinkButton)sender;
        GridViewRow gvRow = (GridViewRow)lb.NamingContainer;
        int rowID = gvRow.RowIndex;
        DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable1"];
        //DataRow drCurrentRow = null;

        for (int i = 0; i < dtCurrentTable.Rows.Count; i++)
        {

            DropDownList ddlEmp = (DropDownList)gvNew.Rows[i].Cells[3].FindControl("ddlEmp");
            DropDownList ddlM = (DropDownList)gvNew.Rows[i].Cells[4].FindControl("ddlM");
            DropDownList ddlRole = (DropDownList)gvNew.Rows[i].Cells[4].FindControl("ddlRole");
            LinkButton LinkDelete = (LinkButton)gvNew.Rows[i].FindControl("LinkDelete");
            Label SNHD_RECID = (Label)gvNew.Rows[i].FindControl("SNHD_RECID");

            // Update the DataRow with the DDL Selected Items 

            dtCurrentTable.Rows[i]["Column1"] = ddlEmp.SelectedItem.Text;
            dtCurrentTable.Rows[i]["Column2"] = ddlM.SelectedItem.Text;
            dtCurrentTable.Rows[i]["Column3"] = ddlRole.SelectedItem.Text;
            dtCurrentTable.Rows[i]["Column4"] = LinkDelete.Text;
            dtCurrentTable.Rows[i]["Column5"] = SNHD_RECID.Text;

        }

        //Store the current data to ViewState for future reference 
        ViewState["CurrentTable1"] = dtCurrentTable;


        if (ViewState["CurrentTable1"] != null)
        {

            DataTable dt = (DataTable)ViewState["CurrentTable1"];
            if (dt.Rows.Count > 1)
            {
                if (gvRow.RowIndex <= dt.Rows.Count - 1)
                {
                    //Remove the Selected Row data and reset row number
                    dt.Rows.Remove(dt.Rows[rowID]);
                    ResetRowID1(dt);
                }
            }

            //Store the current data in ViewState for future reference
            ViewState["CurrentTable1"] = dt;

            //Re bind the GridView for the updated data
            gvNew.DataSource = dt;
            gvNew.DataBind();
        }

        //Set Previous Data on Postbacks
        SetPreviousData1();
    }

    protected void LinkAdd_Click1(object sender, EventArgs e)
    {
        LinkButton lb = (LinkButton)sender;
        GridViewRow gvRow = (GridViewRow)lb.NamingContainer;
        int rowID = gvRow.RowIndex;
        DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable1"];
        DataRow drCurrentRow = null;
        drCurrentRow = dtCurrentTable.NewRow();
        drCurrentRow["RowNumber"] = dtCurrentTable.Rows.Count + 1;
        for (int i = 0; i < dtCurrentTable.Rows.Count; i++)
        {

            DropDownList ddlEmp = (DropDownList)gvNew.Rows[i].Cells[3].FindControl("ddlEmp");
            DropDownList ddlM = (DropDownList)gvNew.Rows[i].Cells[4].FindControl("ddlM");
            DropDownList ddlRole = (DropDownList)gvNew.Rows[i].Cells[4].FindControl("ddlRole");
            LinkButton LinkDelete = (LinkButton)gvNew.Rows[i].FindControl("LinkDelete");
            Label SNHD_RECID = (Label)gvNew.Rows[i].FindControl("SNHD_RECID");
            // Update the DataRow with the DDL Selected Items  LinkDelete

            dtCurrentTable.Rows[i]["Column1"] = ddlEmp.SelectedItem.Text;
            dtCurrentTable.Rows[i]["Column2"] = ddlM.SelectedItem.Text;
            dtCurrentTable.Rows[i]["Column3"] = ddlRole.SelectedItem.Text;
            dtCurrentTable.Rows[i]["Column4"] = LinkDelete.Text;
            dtCurrentTable.Rows[i]["Column5"] = SNHD_RECID.Text;
            if (SNHD_RECID.Text != "")
                LinkDelete.Visible = false;
            else
                LinkDelete.Visible = true;
        }

        //Store the current data to ViewState for future reference 
        ViewState["CurrentTable1"] = dtCurrentTable;


        if (ViewState["CurrentTable1"] != null)
        {

            DataTable dt = (DataTable)ViewState["CurrentTable1"];
            if (dt.Rows.Count > 1)
            {
                if (gvRow.RowIndex <= dt.Rows.Count - 1)
                {
                    //Remove the Selected Row data and reset row number
                    dt.Rows.InsertAt(drCurrentRow, rowID);

                    ResetRowID1(dt);
                }
            }

            //Store the current data in ViewState for future reference
            ViewState["CurrentTable1"] = dt;

            //Re bind the GridView for the updated data
            gvNew.DataSource = dt;
            gvNew.DataBind();
            
        }

        //Set Previous Data on Postbacks
        SetPreviousData1();
    }

    private void ResetRowID1(DataTable dt)
    {
        int rowNumber = 1;
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow row in dt.Rows)
            {
                row[0] = rowNumber;
                rowNumber++;
            }
        }
    }
    protected void ButtonAdd_Click1(object sender, EventArgs e)
    {
        AddNewRowToGrid1();
    }

    protected void btnCclose_Click(object sender, EventArgs e)
    {
        pnlCustom.Visible = false;
        pnlgrid.Visible = true;
        pnlMain.Visible = true;
    }
    protected void btnSave0_Click(object sender, EventArgs e)
    {
        try
        {
            if (ddlEntity.SelectedIndex > 0)
            {
                if (flupd1.HasFile)
                {
                    ocon = CommonFunc.con();
                    lblFileSanc.Text = lblpid.Text + "_" + userid + "_" + System.IO.Path.GetFileName(flupd1.FileName);
                    string uploadPath = Server.MapPath(string.Format("~/SancDocs/{0}", lblFileSanc.Text));
                    if (!System.IO.File.Exists(uploadPath))
                    {
                        flupd1.SaveAs(Server.MapPath("~/SancDocs/") + lblFileSanc.Text);
                        string qry = "insert into SN_SANCTION_ATTACHMENTS (SNSAT_RECID,ENTITY_CODE,SANCTION_NO,PARENT_RECID,FILE_NAME,FILE_PATH,CREATED_BY,CREATED_ON) ";
                        qry += "values (portal_RECID.nextval,'" + ddlEntity.SelectedValue + "','" + lblSancNo.Text + "','" + lblpid.Text + "','" + lblFileSanc.Text + "','','" + userid + "',to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + "', 'dd/mm/yyyy hh:mi:ss AM'))";
                        ocon.Open();
                        OracleCommand cmd = new OracleCommand(qry, ocon);
                        cmd.ExecuteNonQuery();
                        CommonFunc.ShowAlert("File Uplodaed");
                        qry = "select SNSAT_RECID,FILE_NAME from SN_SANCTION_ATTACHMENTS where PARENT_RECID= '" + lblpid.Text + "'";
                        da = new OracleDataAdapter(qry, ocon);
                        ds = new DataSet();
                        da.Fill(ds);
                        gvFiles.DataSource = ds;
                        gvFiles.DataBind();
                    }
                    else
                    {
                        CommonFunc.ShowAlert("File already exists.");
                    }
                }
                else
                {
                    CommonFunc.ShowAlert("Choose a File");
                }
            }
            else
            {
                CommonFunc.ShowAlert("Select Entity");
            }
        }
        catch (Exception ex)
        {
            CommonFunc.ShowAlert("Error: " + ex.Message);
        }
        finally { ocon.Close(); }
    }
    protected void gvFiles_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "del")
        {
            try
            {
                ocon = CommonFunc.con();
                string id = e.CommandArgument.ToString();
                string qry = "delete from SN_SANCTION_ATTACHMENTS where SNSAT_RECID= '" + id + "'";
                ocon.Open();
                OracleCommand cmd = new OracleCommand(qry, ocon);
                cmd.ExecuteNonQuery();
                CommonFunc.ShowAlert("Removed");
            }
            catch (Exception ex)
            {
                CommonFunc.ShowAlert("Error: " + ex.Message);
            }
            finally { ocon.Close(); }
        }
    }
    protected void lnkAttach_Click(object sender, EventArgs e)
    {
        pnlAttachment.Visible = true;
        pnlCustom.Visible = false;
        pnlMain.Visible = false;
        pnlDetail.Visible = false;
        pnlgrid.Visible = false;
        pnlgrid1.Visible = false;
        ocon = CommonFunc.con();
        string qry = "select SNSAT_RECID,FILE_NAME from SN_SANCTION_ATTACHMENTS where PARENT_RECID= '0'";
        da = new OracleDataAdapter(qry, ocon);
        ds = new DataSet();
        da.Fill(ds);
        gvFiles.DataSource = ds;
        gvFiles.DataBind();
    }
    protected void ddlSBU_SelectedIndexChanged(object sender, EventArgs e)
    {


        //ds = CommonFunc.GetUNIT(ddlEntity.SelectedValue, ddlSBU.SelectedValue); //DataSet ds1 = CommonFunc.GetbudRefNo(ddlEntity.SelectedValue, lblFyear.Text);
        ds = CommonFunc.GetUNITbyEmp(ddlEntity.SelectedValue, ddlSBU.SelectedValue, userid); 
        for (int i = 0; i < Gridview1.Rows.Count; i++)
        {
            DropDownList ddlUnit = (DropDownList)Gridview1.Rows[i].FindControl("ddlunit");
            ddlUnit.Items.Clear(); ddlUnit.Items.Add(new ListItem("--Select--", "0"));
            //ListBox ListBox1 = (ListBox)Gridview1.Rows[i].FindControl("ListBox1");
            DropDownList ddlBudRefNo = (DropDownList)Gridview1.Rows[i].FindControl("ddlBudRefNo");
            //ddlUnit.Items.Clear(); ddlUnit.Items.Add(new ListItem("--Select--", "0"));
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                ddlUnit.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["OU_CODE"].ToString()));
                //ListBox1.Items.Add(new ListItem(  ds.Tables[0].Rows[k]["OU_CODE"].ToString() + " " + ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["OU_CODE"].ToString()));
            }
        }


    }
   
    protected void btnPrew_Click(object sender, EventArgs e)
    {
        Response.Redirect("PrevieSanction.aspx?sid=" + lblpid.Text);
    }
    protected void Gridview1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ddlFYear_SelectedIndexChanged(object sender, EventArgs e)
    {

        lblFyear.Text = ddlFYear.SelectedValue;
        ds = CommonFunc.GetExpCodeSbu(ddlDept.SelectedValue, ddlFYear.SelectedValue,ddlSBU.SelectedValue);
        for (int i = 0; i < Gridview1.Rows.Count; i++)
        {
            DropDownList ddlExpCode = (DropDownList)Gridview1.Rows[i].FindControl("ddlExpCode");
            ddlExpCode.Items.Clear(); ddlExpCode.Items.Add(new ListItem("--Select--", "0"));
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)//
            {
                ddlExpCode.Items.Add(new ListItem(ds.Tables[0].Rows[k]["head_description"].ToString(), ds.Tables[0].Rows[k]["EXPENSE_CODE_BUDGET"].ToString()));
            }
        }
    }
    protected void btnROI_Click(object sender, EventArgs e)
    {
        try
        {
            if (ddlEntity.SelectedIndex > 0)
            {
                if (flROI.HasFile)
                {
                    ocon = CommonFunc.con();
                    lblFileSanc.Text = lblpid.Text + "_" + userid + "_" + System.IO.Path.GetFileName(flROI.FileName);
                    string uploadPath = Server.MapPath(string.Format("~/SancDocs/{0}", lblFileSanc.Text));
                    flROI.SaveAs(Server.MapPath("~/SancDocs/") + lblFileSanc.Text);
                    string qry = "insert into SN_SANCTION_ATTACHMENTS (SNSAT_RECID,ENTITY_CODE,SANCTION_NO,PARENT_RECID,FILE_NAME,FILE_PATH,CREATED_BY,CREATED_ON,FILE_TYPE) ";
                    qry += "values (portal_RECID.nextval,'" + ddlEntity.SelectedValue + "','" + lblSancNo.Text + "','" + lblpid.Text + "','" + lblFileSanc.Text + "','','" + userid + "',to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + "', 'dd/mm/yyyy hh:mi:ss AM'),'ROI')";
                    ocon.Open();
                    OracleCommand cmd = new OracleCommand(qry, ocon);
                    cmd.ExecuteNonQuery();
                    CommonFunc.ShowAlert("File Uplodaed");
                    qry = "select SNSAT_RECID,FILE_NAME,FILE_TYPE from SN_SANCTION_ATTACHMENTS where PARENT_RECID= '" + lblpid.Text + "'";
                    da = new OracleDataAdapter(qry, ocon);
                    ds = new DataSet();
                    da.Fill(ds);
                    gvFiles.DataSource = ds;
                    gvFiles.DataBind();
                }
                else
                {
                    CommonFunc.ShowAlert("Choose a File");
                }
            }
            else
            {
                CommonFunc.ShowAlert("Select Entity");
            }
        }
        catch (Exception ex)
        {
            CommonFunc.ShowAlert("Error: " + ex.Message);
        }
        finally { ocon.Close(); }
    }
}