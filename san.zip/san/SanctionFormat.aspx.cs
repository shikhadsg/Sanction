﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MyClass;
using System.Data;
using System.Data.OracleClient;
using System.Globalization;
using System.Threading;

public partial class SanctionFormat : System.Web.UI.Page
{
    OracleConnection ocon = new OracleConnection(); string qry = "", map_userid="";
    OracleDataAdapter da; DataSet ds; string userid = "",cby=""; string recid = "";
    CultureInfo hindi = new CultureInfo("hi-IN");
    protected void Page_Load(object sender, EventArgs e)
    {
        if(Session["recid"] !=null && Session["recid"].ToString()!="")
        {
            recid = Session["recid"].ToString();
        }
        if (Request.QueryString["sid"] != null && Request.QueryString["sid"].ToString() != "")
        {
            recid = Request.QueryString["sid"].ToString();
        }
        if (Session["emp_code"] != null && Session["emp_code"].ToString() != "")
        {
            userid = Session["emp_code"].ToString();
            //email = Session["email"].ToString();
        }

        if (Session["emp_code_map"] != null && Session["emp_code_map"].ToString() != "")
        {
            map_userid = Session["emp_code_map"].ToString();
        }
        if (map_userid != "")
        {
            Button3.Visible = true;
        }
        
        if (!IsPostBack)
        {
            ds = CommonFunc.getMasterDetail(recid,"");
            //   FISCAL_YEAR     VERSION_NO HIERARCHY_CODE  TOTAL_AMOUNT           }
            if(ds.Tables[0].Rows.Count>0)
            {
                DataRow dr =ds.Tables[0].Rows[0];
                lblSancDate.Text = dr["SANCTION_DATE"].ToString();
                lblSancNo.Text = dr["SANCTION_NO"].ToString();
                lblEntity.Text = dr["ENTITY_CODE_d"].ToString();
                lblEnt.Text = dr["ENTITY_CODE"].ToString();
                lblVersion.Text = dr["VERSION_NO"].ToString();
                lblTotal.Text = dr["TOTAL_AMOUNT"].ToString();
                lblSBU.Text = dr["SBU_CODE_d"].ToString();
                lblsb.Text = dr["SBU_CODE"].ToString();
                lblDepartment.Text = dr["DEPT_CODE_d"].ToString();
                lblDept.Text = dr["DEPT_CODE"].ToString();
                lblFunction.Text = dr["PROJECT"].ToString();
                lblFyear.Text = dr["FISCAL_YEAR"].ToString();
                lblSoughtFor.Text = dr["SANCTION_SOUGHT_FOR"].ToString();
                txtback.Text = dr["BACKGROUD_INFO"].ToString();
                txtIssues.Text = dr["CRITICAL_ISSUES_DETAIL"].ToString();
                lblIntBy.Text = dr["CREATED_BY"].ToString();
                cby = dr["CREATED_BY1"].ToString();
                lblInton.Text = dr["CREATED_ON"].ToString();
                if(dr["statusF"].ToString() !="")
                lblStatus.Text = "(Status " + dr["statusF"].ToString() +")";
                if (dr["STATUS"].ToString() != "")
                    lblStatusCode.Text = dr["STATUS"].ToString();
                getDetailData(); getAttach();//CREATED_BY1 STATUS
            }
        }
        if (cby == userid)
        {
            dvAttach.Visible = true;
        }
        dvAttach.Visible = true;
    }


    protected override void InitializeCulture()
    {
        //CultureInfo ci = new CultureInfo("en-IN");
        hindi.NumberFormat.CurrencySymbol = "₹";
        Thread.CurrentThread.CurrentCulture = hindi;

        base.InitializeCulture();
    }  
    protected void getDetailData()
    {
                        //BUDGET_AMOUNT CONSUMED_AMOUNT BALANCE_AMOUNT  

         qry=" select  SNSD_RECID,  (SELECT LEGAL_NAME FROM OC_ENTITY B WHERE status='A' and ENTITY_CODE= s.ENTITY_CODE) ENTITY_CODE, s.SANCTION_NO,to_char(s.SANCTION_DATE,'dd/mm/yyyy') SANCTION_DATE, ";
         qry += " (select DESCRIPTION || '(' || OU_CODE || ')' from OC_OPERATING_UNIT o where o.ENTITY_CODE = s.ENTITY_CODE and o.OU_CODE = s.OU_CODE  ) OU_CODE, ";
        qry += "  (SELECT  B.DESCRIPTION FROM  OC_SBU_CATEGORY B WHERE  b.SBU_CODE = m.SBU_CODE and B.SBU_CATEGORY_CODE =s.SBU_CATEGORY_CODE  )SBU_CATEGORY_CODE, ";
        //--(SELECT   C.DESCRIPTION FROM  OC_BRANDS  C WHERE C.SBU_CATEGORY_CODE =  s.SBU_CATEGORY_CODE AND C.STATUS = 'A' AND EXISTS (SELECT '1' FROM OC_SBU_MAPPING D WHERE D.OU_CODE = s.OU_CODE AND D.SBU_CATEGORY_CODE = s.SBU_CATEGORY_CODE AND D.BRAND_CODE = C.BRAND_CODE AND D.STATUS = 'A'))
        qry += " (SELECT  C.DESCRIPTION FROM  OC_BRANDS C WHERE  c.SBU_CODE = m.SBU_CODE and C.BRAND_CODE = s.BRAND_CODE AND c.SBU_CATEGORY_CODE = s.SBU_CATEGORY_CODE )  BRAND_CODE, ";
        qry += " (SELECT  C.DESCRIPTION FROM  OC_PRODUCTS C WHERE  c.SBU_CODE = m.SBU_CODE and C.BRAND_CODE = s.BRAND_CODE AND c.SBU_CATEGORY_CODE = s.SBU_CATEGORY_CODE and c.PRODUCT_ID = s.PRODUCT_ID) PRODUCT_ID, ";
        qry += " EXPENSE_CODE_BUDGET ||'-' || (select head_description from OC_EXPENSE_MASTER where status='A' and record_type='I' and EXPENSE_CODE_BUDGET=s.EXPENSE_CODE_BUDGET  and HRIS_DEPT_CODE ='" + lblDept.Text + "' ) EXPENSE_CODE_BUDGET, ";

        qry += " SEQ_NO,  PARTICULARS,SPECIFICATIONS,case when BUDGET_APPROVED='Y' then 'Yes' else 'No' end BUDGET_APPROVED, BUDGET_REF_NO,SANCTION_AMOUNT,BUDGET_AMOUNT ,CONSUMED_AMOUNT,BALANCE_AMOUNT ,SANCTION_AMOUNT_GST, ";
        qry += "BUDGET_AMOUNT, BUDGET_AMOUNT_UPTO, SANCTION_AMOUNT, BALANCE_AMOUNT, BALANCE_AMOUNT_UPTO,  BUDGET_CONSUMED_AMOUNT ";
        //qry += " ( select IMIS.SANCTIONS_PKG.TOTAL_BUDGET_AMOUNT(s.ENTITY_CODE , s.OU_CODE ,m.SBU_CODE,s.SBU_CATEGORY_CODE,s.BRAND_CODE,s.PRODUCT_ID ,m.HRIS_DEPT_CODE,m.HRIS_FUNCTION_CODE ,m.FISCAL_YEAR  ,s.EXPENSE_CODE_BUDGET,s.BUDGET_REF_NO)   from dual) TOTAL_BUDGET_AMOUNT, ";  //TOTAL_BUDGET_AMOUNT BUDGET_AMOUNT_UPTO  BUDGET_CONSUMED_AMOUNT  TOT_AVAILABLE_BUDGET_AMOUNT  TOT_AVAILABLE_BUDGET_AMT_UPTO
        //qry += " (select IMIS.SANCTIONS_PKG.BUDGET_AMOUNT_UPTO(s.ENTITY_CODE , s.OU_CODE ,m.SBU_CODE,s.SBU_CATEGORY_CODE,s.BRAND_CODE,s.PRODUCT_ID ,m.HRIS_DEPT_CODE,m.HRIS_FUNCTION_CODE ,m.FISCAL_YEAR  ,s.EXPENSE_CODE_BUDGET,'28/05/2018', BUDGET_REF_NO) BUDGET_AMOUNT_UPTO from dual) BUDGET_AMOUNT_UPTO  ,";
        //qry += " (select IMIS.SANCTIONS_PKG.BUDGET_CONSUMED_AMOUNT(s.ENTITY_CODE , s.OU_CODE ,m.SBU_CODE,s.SBU_CATEGORY_CODE,s.BRAND_CODE,s.PRODUCT_ID ,m.HRIS_DEPT_CODE,m.HRIS_FUNCTION_CODE ,m.FISCAL_YEAR  ,s.EXPENSE_CODE_BUDGET,s.BUDGET_REF_NO )  from dual) BUDGET_CONSUMED_AMOUNT,";
        //qry += " (select IMIS.SANCTIONS_PKG.TOT_AVAILABLE_BUDGET_AMOUNT(s.ENTITY_CODE , s.OU_CODE ,m.SBU_CODE,s.SBU_CATEGORY_CODE,s.BRAND_CODE,s.PRODUCT_ID ,m.HRIS_DEPT_CODE,m.HRIS_FUNCTION_CODE ,m.FISCAL_YEAR  ,s.EXPENSE_CODE_BUDGET,s.BUDGET_REF_NO) TOT_AVAILABLE_BUDGET_AMOUNT from dual) TOT_AVAILABLE_BUDGET_AMOUNT ,";
        //qry += " (select IMIS.SANCTIONS_PKG.TOT_AVAILABLE_BUDGET_AMT_UPTO(s.ENTITY_CODE , s.OU_CODE ,m.SBU_CODE,s.SBU_CATEGORY_CODE,s.BRAND_CODE,s.PRODUCT_ID ,m.HRIS_DEPT_CODE,m.HRIS_FUNCTION_CODE ,m.FISCAL_YEAR  ,s.EXPENSE_CODE_BUDGET,'28/05/2018', BUDGET_REF_NO) TOT_AVAILABLE_BUDGET_AMT_UPTO from dual ) TOT_AVAILABLE_BUDGET_AMT_UPTO ";    

        qry += " from SN_SANCTIONS_DETAILS  s,SN_SANCTIONS m where PARENT_RECID = '" + recid + "' and s. PARENT_RECID =  m.SNS_RECID  and nvl(s.status,'A')<>'I' order by s.SEQ_NO ";
            ocon = CommonFunc.con(); 
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvDetail.DataSource = ds;
                gvDetail.DataBind();
                gvBudget.DataSource = ds;
                gvBudget.DataBind();
            }
            try
            {
                Label l = (Label)gvDetail.FooterRow.FindControl("lblTotal");
                if (l != null)
                {
                    l.Text = lblTotal.Text;
                    decimal parsed = decimal.Parse(l.Text, CultureInfo.InvariantCulture);
                    string text = string.Format(hindi, "{0:c0}", parsed);
                    l.Text = text;
                }
            }
            catch (Exception ex11) { }
            for (int i = 0; i < gvDetail.Rows.Count; i++)
            {
                Label lblamt = (Label)gvDetail.Rows[i].FindControl("lblamt");
                Label lblamt11 = (Label)gvDetail.Rows[i].FindControl("lblamt11");
                if (lblamt.Text != "")
                {
                    decimal parsed = decimal.Parse(lblamt.Text, CultureInfo.InvariantCulture);
                    string text = string.Format(hindi, "{0:c0}", parsed);
                    lblamt.Text = text;//lblamt

                    if (lblamt11.Text != "")
                    {
                        parsed = decimal.Parse(lblamt11.Text, CultureInfo.InvariantCulture);
                        text = string.Format(hindi, "{0:c0}", parsed);
                        lblamt11.Text = text;
                    }
                }
            }
        /***************** budget detail ***************************/
               
            
            getapp();
    }
    protected void btnEdit_Click(object sender, EventArgs e)
    {
        Response.Redirect("editSanction.aspx?sid=" + recid);
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        ocon = CommonFunc.con(); ocon.Open();
        OracleTransaction trns = ocon.BeginTransaction(); ; OracleCommand cmd; string qry = "";
        try
        {
            

            qry = "select nvl( max( SANCTION_NO) ,0)   from   SN_SANCTIONS where SANCTION_NO not like '%Temp%'";
            cmd = new OracleCommand(qry, ocon,trns);
            string sno = cmd.ExecuteScalar().ToString();
            string[] arr = sno.Split('/');
            int n = Convert.ToInt32(arr[arr.Length - 1]);
            n = n + 1;
            string sancNo = lblEnt.Text + "/" + lblFyear.Text + "/" + lblsb.Text + "/" + lblDept.Text + "/" + n;

            qry = "update  SN_SANCTIONS set SANCTION_NO='" + sancNo  + "', status='P', LAST_UPD_BY='" + userid + "'  ,LAST_UPD_ON = to_date('" + DateTime.Now.ToString("dd/MM/yyyy") + "', 'dd/mm/yyyy') where SNS_RECID='" + recid + "' ";
            // (SNS_RECID,ENTITY_CODE,SANCTION_NO,SANCTION_DATE,FISCAL_YEAR,SBU_CODE,DEPT_CODE,HRIS_DEPT_CODE,PROJECT,HRIS_FUNCTION_CODE,VERSION_NO,HIERARCHY_CODE,SANCTION_SOUGHT_FOR,TOTAL_AMOUNT,BACKGROUD_INFO,CRITICAL_ISSUES_DETAIL,STATUS,CREATED_BY,CREATED_ON) ";
            if(ocon.State== ConnectionState.Closed)
                ocon.Open();
            cmd = new OracleCommand(qry, ocon,trns);
            cmd.ExecuteNonQuery();
            qry = "update SN_SANCTIONS_DETAILS set  SANCTION_NO='" + sancNo + "' where  PARENT_RECID ='" + recid + "'";
            cmd = new OracleCommand(qry, ocon,trns);
            cmd.ExecuteNonQuery();
            qry = "update SN_SANCTION_APPROVALS set  SANCTION_NO='" + sancNo + "' where  PARENT_RECID ='" + recid + "'";
            cmd = new OracleCommand(qry, ocon, trns);
            cmd.ExecuteNonQuery();
            qry = "update SN_SANCTION_ATTACHMENTS set  SANCTION_NO='" + sancNo + "' where  PARENT_RECID ='" + recid + "'";
            cmd = new OracleCommand(qry, ocon, trns);
            cmd.ExecuteNonQuery();
            trns.Commit();


            ocon.Close();
            CommonFunc.ShowAlertMessage("Record Saved.", "ShowSavedSanctionList.aspx");
        }
        catch (Exception ex)
        {
            trns.Rollback();
            CommonFunc.ShowAlert("Error " + ex.Message);
        }
    }
    protected void getapp()
    {
        qry = " select  S_NO SNO, (select employee_name from hrm_employee where EMP_CODE= s.EMP_CODE) EmployeeName, to_char(APPROVED_ON,'dd/mm/yyyy') Dated, case ACTION_TAKEN when 'P' then 'Recommended' when 'A' then 'Approved' when 'E' then 'Reinitated' when 'C' then 'Reject' when 'D' then 'Sent for discussion' end Action_Taken, Remarks  from SN_SANCTION_APPROVALS s where sanction_no= '" + lblSancNo.Text + "' and emp_code not like 'A%' and S_NO<>0  order by approved_on,s_no";
        ocon = CommonFunc.con();
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvApproval.DataSource = ds;
            gvApproval.DataBind();
        }

        string semp_code = "";
        qry = " select (select employee_name from hrm_employee where EMP_CODE= s.EMP_CODE) EmployeeName, to_char(APPROVED_ON,'dd/mm/yyyy') dt from SN_SANCTION_APPROVALS s where sanction_no= '" + lblSancNo.Text + "' and role ='A' and emp_code not like 'A%'  and APPROVED_ON is not null and SNSA_RECID in (select max(SNSA_RECID) from SN_SANCTION_APPROVALS  where sanction_no= s.sanction_no  and EMP_CODE= s.EMP_CODE) order by approved_on,s_no";
        ocon = CommonFunc.con();
        da = new OracleDataAdapter(qry, ocon);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvAppBy.DataSource = ds;
            gvAppBy.DataBind();
        }
        else
        {
            qry = "select(select employee_name from hrm_employee where EMP_CODE= s.EMP_CODE) EmployeeName,EMP_CODE, to_char(APPROVED_ON,'dd/mm/yyyy') dt from  SN_SANCTION_APPROVALS s where sanction_no = '" + lblSancNo.Text + "' ";
            qry += " and s_no in (select max(s_no) from SN_SANCTION_APPROVALS  where sanction_no =s.sanction_no and emp_code not like 'A%' ) and APPROVED_ON is not null ";
            ocon = CommonFunc.con();
            da = new OracleDataAdapter(qry, ocon);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvAppBy.DataSource = ds;
                gvAppBy.DataBind();
                 qry = " select (select employee_name from hrm_employee where EMP_CODE= s.EMP_CODE) EmployeeName, to_char(APPROVED_ON,'dd/mm/yyyy') dt from SN_SANCTION_APPROVALS s where sanction_no= '" + lblSancNo.Text + "' and role ='A' and emp_code like 'A%'  ";
                ocon = CommonFunc.con();
                da = new OracleDataAdapter(qry, ocon);
                DataSet ds1 = new DataSet();
                da.Fill(ds1);
                if (ds1.Tables[0].Rows.Count > 0)
                {
                    semp_code = ds.Tables[0].Rows[ds.Tables[0].Rows.Count - 1]["EMP_CODE"].ToString();
                }
            }
        }
        if (lblStatusCode.Text == "A" || lblStatusCode.Text == "I")
        {
            gvAppBy.Visible = true;

            
        }
        else { gvAppBy.Visible = false;

        //qry = " select  S_NO SNO, (select employee_name from hrm_employee where EMP_CODE= s.EMP_CODE) EmployeeName, to_char(APPROVED_ON,'dd/mm/yyyy') Dated, case ACTION_TAKEN when 'P' then 'Recommended' when 'A' then 'Approved' when 'E' then 'Reinitated' when 'C' then 'Reject' when 'D' then 'Sent for discussion' end Action_Taken, Remarks  from SN_SANCTION_APPROVALS s where sanction_no= '" + lblSancNo.Text + "' and emp_code not like 'A%' and S_NO<>0 and nvl(ACTION_TAKEN,'N')<>'A' order by S_NO";

        qry = "select * from( select  S_NO SNO,approved_on, (select employee_name from hrm_employee where EMP_CODE= s.EMP_CODE) EmployeeName, to_char(APPROVED_ON,'dd/mm/yyyy') Dated, case ACTION_TAKEN when 'P' then 'Recommended' when 'A' then 'Approved' when 'E' then 'Reinitated' when 'C' then 'Reject' when 'D' then 'Sent for discussion' end Action_Taken, Remarks  from SN_SANCTION_APPROVALS s where sanction_no= '" + lblSancNo.Text + "' and emp_code not like 'A%' and S_NO<>0 and emp_code not in('" + semp_code + "') ";
        qry += " union all   select   S_NO SNO,approved_on,  (select employee_name from hrm_employee where EMP_CODE= s.EMP_CODE) EmployeeName, ";
        qry += " '' Dated,  '' Action_Taken, '' Remarks from SN_SANCTION_APPROVALS s where sanction_no = '" + lblSancNo.Text + "' and   emp_code not like 'A%' and   S_NO<>0 and   emp_code='" + semp_code + "' ";
        qry += "   )a  order by approved_on,SNO";
        ocon = CommonFunc.con();
         da = new OracleDataAdapter(qry, ocon);
         ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvApproval.DataSource = ds;
            gvApproval.DataBind();
        }
        }


        qry = " select (select employee_name from hrm_employee where EMP_CODE= s.EMP_CODE) EmployeeName, to_char(APPROVED_ON,'dd/mm/yyyy') dt from SN_SANCTION_APPROVALS s where sanction_no= '" + lblSancNo.Text + "' and role ='R' and emp_code not like 'A%'   and APPROVED_ON is not null and SNSA_RECID in (select max(SNSA_RECID) from SN_SANCTION_APPROVALS  where sanction_no= s.sanction_no  and EMP_CODE= s.EMP_CODE) order by approved_on,s_no";
        if (semp_code != "")
        {
            //
            qry = " select (select employee_name from hrm_employee where EMP_CODE= s.EMP_CODE) EmployeeName, to_char(APPROVED_ON,'dd/mm/yyyy') dt from SN_SANCTION_APPROVALS s where sanction_no= '" + lblSancNo.Text + "' and role ='R' and emp_code not like 'A%'   and APPROVED_ON is not null and SNSA_RECID in (select max(SNSA_RECID) from SN_SANCTION_APPROVALS  where sanction_no= s.sanction_no  and EMP_CODE= s.EMP_CODE) and s.EMP_CODE not in ('" + semp_code + "') order by approved_on,s_no";
        }
        ocon = CommonFunc.con();
        da = new OracleDataAdapter(qry, ocon);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvRevBy.DataSource = ds;
            gvRevBy.DataBind();
        }

    }
    protected void getAttach()
    {
        qry = " select SUBSTR(FILE_NAME,INSTR(FILE_NAME, '_',1,2 )+1 ) FILE_NAME_disp, FILE_NAME from SN_SANCTION_ATTACHMENTS where SANCTION_NO = '" + lblSancNo.Text + "'";
        ocon = CommonFunc.con();
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvAttachment.DataSource = ds;
            gvAttachment.DataBind();
        }
    }
   
    protected void gvApproval_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        
    }
    protected void gvAttachment_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string path = e.CommandArgument.ToString();
        string fpath = Server.MapPath("~/SancDocs/") + e.CommandArgument.ToString(); // @"c:/abc/doc/abc1.doc";
        System.IO.FileInfo myDoc = new System.IO.FileInfo(fpath);

        Response.Clear();
        Response.ContentType = "Application/msword";
        Response.AddHeader("content-disposition", "attachment;filename=" + myDoc.Name);
        Response.AddHeader("Content-Length", myDoc.Length.ToString());
        Response.ContentType = "application/octet-stream";

        Response.WriteFile(myDoc.FullName);

        Response.End();
    }

    protected void btnSave0_Click(object sender, EventArgs e)
    {
        try
        {

            if (flupd1.HasFile)
            {
                ocon = CommonFunc.con();
                lblFileSanc.Text = recid + "_" + userid + "_" + System.IO.Path.GetFileName(flupd1.FileName);
                string uploadPath = Server.MapPath(string.Format("~/SancDocs/{0}", lblFileSanc.Text));
                if (!System.IO.File.Exists(uploadPath))
                {
                    
                    string qry = "insert into SN_SANCTION_ATTACHMENTS (SNSAT_RECID,ENTITY_CODE,SANCTION_NO,PARENT_RECID,FILE_NAME,FILE_PATH,CREATED_BY,CREATED_ON) ";
                    qry += "values (portal_RECID.nextval,'" + lblEnt.Text + "','" + lblSancNo.Text + "','" + recid + "','" + lblFileSanc.Text + "','','" + userid + "',to_date('" + DateTime.Now.ToString("dd/MM/yyyy") + "', 'dd/mm/yyyy'))";
                    ocon.Open();
                    OracleCommand cmd = new OracleCommand(qry, ocon);
                    cmd.ExecuteNonQuery();
                    flupd1.SaveAs(Server.MapPath("~/SancDocs/") + lblFileSanc.Text);
                    getAttach();
                    CommonFunc.ShowAlert("File Uplodaed");
                    //qry = "select SNSAT_RECID,FILE_NAME from SN_SANCTION_ATTACHMENTS where PARENT_RECID= '" + lblrecid.Text + "'";
                    //da = new OracleDataAdapter(qry, ocon);
                    //ds = new DataSet();
                    //da.Fill(ds);
                    //gvAttachment.DataSource = ds;
                    //gvAttachment.DataBind();
                }
                else
                {
                    CommonFunc.ShowAlert("File already exists.");
                }
            }
            else
            {
                CommonFunc.ShowAlert("Choose a File");
            }


        }
        catch (Exception ex)
        {
            CommonFunc.ShowAlert("Error: " + ex.Message);
        }
        finally { ocon.Close(); }
    }

    protected void gvApproval_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (gvApproval.Rows.Count > 0)
        {
            for (int i = 1; i < gvApproval.Rows.Count; i++)
            {
                string val = gvApproval.Rows[i].Cells[0].Text;
                string val1 = gvApproval.Rows[i - 1].Cells[0].Text;

                int sno = Convert.ToInt32(gvApproval.Rows[i].Cells[0].Text);
                int prevno = Convert.ToInt32(gvApproval.Rows[i - 1].Cells[0].Text);
                if (sno > prevno + 1)
                {
                    gvApproval.Rows[i].Cells[0].Text = Convert.ToString(prevno + 1);
                }
            }
        }
    }



    protected void Button2_Click(object sender, EventArgs e)
    {
        //if (Session["view"] != null)
        //{
        //    Response.Redirect("ShowViewSanctionList.aspx");
        //}
        //else
        //{
            Response.Redirect("ShowSanctionApproved.aspx");
       // }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("ShowViewSanctionList.aspx");
    }
}