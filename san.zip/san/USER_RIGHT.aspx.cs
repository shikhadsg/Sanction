﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MyClass;
using System.Data;
using System.Data.OracleClient;

public partial class USER_RIGHT : System.Web.UI.Page
{
    OracleConnection ocon = new OracleConnection();
    OracleDataAdapter da; DataSet ds; string userid = "skatiyar";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["emp_code"] != null && Session["emp_code"].ToString() != "")
        {
            userid = Session["emp_code"].ToString();
            //email = Session["email"].ToString();
        }
        if (!IsPostBack)
        {
            ds = CommonFunc.GetEmpList("");
            ddlEmp.Items.Add(new ListItem("--Select--", "0")); ddlEmpC.Items.Add(new ListItem("--Select--", "0"));
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                ddlEmp.Items.Add(new ListItem(ds.Tables[0].Rows[k]["employee_name"].ToString(), ds.Tables[0].Rows[k]["emp_code"].ToString()));
                ddlEmpC.Items.Add(new ListItem(ds.Tables[0].Rows[k]["employee_name"].ToString(), ds.Tables[0].Rows[k]["emp_code"].ToString()));
            }
            ddlEntity.Items.Add(new ListItem("--Select--", "0")); ddlEntityC.Items.Add(new ListItem("--Select--", "0"));
            ds = CommonFunc.GetEntity();
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                ddlEntity.Items.Add(new ListItem(ds.Tables[0].Rows[k]["LEGAL_NAME"].ToString(), ds.Tables[0].Rows[k]["ENTITY_CODE"].ToString()));
                ddlEntityC.Items.Add(new ListItem(ds.Tables[0].Rows[k]["LEGAL_NAME"].ToString(), ds.Tables[0].Rows[k]["ENTITY_CODE"].ToString()));
            }

            
        }
    }
    protected void ddlEntity_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlSBU.Items.Clear(); ddlUnit.Items.Clear(); ddlCategory.Items.Clear();
        ddlSBU.Items.Add(new ListItem("--Select--", "0"));
        ds = CommonFunc.GetSBU(ddlEntity.SelectedValue);
        for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
        {
            ddlSBU.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["SBU_CODE"].ToString()));
        }
        ddlUnit.Items.Clear();
        if (ddlEntity.SelectedIndex > 0 && ddlSBU.SelectedIndex > 0)
        {
            
            ds = CommonFunc.GetUNIT(ddlEntity.SelectedValue,ddlSBU.SelectedValue);
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                ddlUnit.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["SBU_CODE"].ToString()));
            }
        }
    }
    protected void ddlSBU_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlUnit.Items.Clear(); ddlUnit.Items.Add(new ListItem("--Select--", "0"));
        if (ddlEntity.SelectedIndex > 0 && ddlSBU.SelectedIndex > 0)
        {
            ds = CommonFunc.GetUNIT(ddlEntity.SelectedValue, ddlSBU.SelectedValue);
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                ddlUnit.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["OU_CODE"].ToString()));
            }
        }
        ddlCategory.Items.Clear();
        if (ddlUnit.SelectedIndex > 0 && ddlSBU.SelectedIndex > 0)
        {
            ds = CommonFunc.GetCategory(ddlSBU.SelectedValue, ddlUnit.SelectedValue, ddlEntity.SelectedValue, userid);
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                ddlCategory.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["SBU_CODE"].ToString()));
            }
        }
    }
    protected void ddlUnit_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlCategory.Items.Clear(); ddlCategory.Items.Add(new ListItem("--Select--", "0"));
        if (ddlUnit.SelectedIndex > 0 && ddlSBU.SelectedIndex > 0)
        {
            ds = CommonFunc.GetCategory(ddlSBU.SelectedValue, ddlUnit.SelectedValue, ddlEntity.SelectedValue, userid);
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                ddlCategory.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["SBU_CATEGORY_CODE"].ToString()));
            }
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        string qry = "select  ONUR_RECID, (select employee_name from hrm_employee where EMP_CODE= s.EMP_CODE) EmployeeName, (select LEGAL_NAME from OC_ENTITY where ENTITY_CODE= s.ENTITY_CODE) ENTITY  ,OU_CODE,SBU_CODE,SBU_CATEGORY_CODE from SN_USER_RIGHTS s where STATUS='A' order by EmployeeName,ENTITY,SBU_CODE,OU_CODE,SBU_CATEGORY_CODE"; //,CREATED_BY,CREATED_ON,LAST_UPD_BY,LAST_UPD_ON ONUR_RECID ,BRAND_CODE,STATUS
        if (ddlEmp.SelectedIndex > 0)
            qry += " and EMP_CODE = '" + ddlEmp.SelectedValue + "'";
        if (ddlEntity.SelectedIndex > 0)
            qry += " and ENTITY_CODE = '" + ddlEntity.SelectedValue + "'";
        if (ddlSBU.SelectedIndex > 0)
            qry += " and SBU_CODE = '" + ddlSBU.SelectedValue + "'";
        if (ddlCategory.SelectedIndex > 0)
            qry += " and SBU_CATEGORY_CODE = '" + ddlCategory.SelectedValue + "'";
        ocon = CommonFunc.con();
        da = new OracleDataAdapter(qry, ocon);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvRights.DataSource = ds;
            gvRights.DataBind(); gvRights.Visible = true;
        }
        else
        { CommonFunc.ShowAlert("No data Found"); gvRights.Visible = false; }
    }
    protected void ddlEntityC_SelectedIndexChanged(object sender, EventArgs e)
    {
        listSBU.Items.Clear(); listOUCODE.Items.Clear(); listCategory.Items.Clear();
        ds = CommonFunc.GetSBU(ddlEntityC.SelectedValue);
        for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
        {
            listSBU.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["SBU_CODE"].ToString()));
        }
        
    }
    protected void listSBU_SelectedIndexChanged(object sender, EventArgs e)
    {
        listOUCODE.Items.Clear(); listCategory.Items.Clear();
        if (ddlEntityC.SelectedIndex > 0 )
        {
            for (int i = 0; i < listSBU.Items.Count; i++)
            {
                if (listSBU.Items[i].Selected == true)
                {
                    ds = CommonFunc.GetUNITList(ddlEntityC.SelectedValue, listSBU.Items[i].Value);
                    for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                    {
                        listOUCODE.Items.Add(new ListItem(ds.Tables[0].Rows[k]["OU_CODE"].ToString(), ds.Tables[0].Rows[k]["OU_CODE"].ToString()));
                    }
                }
            }
        }
    }
    protected void listOUCODE_SelectedIndexChanged(object sender, EventArgs e)
    {
        listCategory.Items.Clear();
        if (ddlEntityC.SelectedIndex > 0)
        {
            for (int i = 0; i < listOUCODE.Items.Count; i++)
            {
                if (listOUCODE.Items[i].Selected == true)
                {
                    ds = CommonFunc.GetCategoryList(listOUCODE.Items[i].Value, ddlEntityC.SelectedValue);
                    for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                    {
                        listCategory.Items.Add(new ListItem(ds.Tables[0].Rows[k]["SBU_CATEGORY_CODE"].ToString(), ds.Tables[0].Rows[k]["SBU_CATEGORY_CODE"].ToString()));
                    }
                }
            }
        }
    }
    protected void lnkNew_Click(object sender, EventArgs e)
    {
        pnlCreate.Visible = true;
        pnlSearch.Visible = false;
    }
    protected void lnkNew0_Click(object sender, EventArgs e)
    {
        pnlCreate.Visible = false;
        pnlSearch.Visible = true;
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        if (ddlEmpC.SelectedIndex <=0)
        {
            CommonFunc.ShowAlert("Select Employee"); return;
        }
        if (ddlEntityC.SelectedIndex <= 0)
        {
            CommonFunc.ShowAlert("Select Employee"); return;
        }
        int count = 0;
        ocon = CommonFunc.con(); ocon.Open(); OracleTransaction trns = ocon.BeginTransaction(); ; OracleCommand cmd; string qry = "";
        try
        {
            for (int i = 0; i < listCategory.Items.Count; i++)
            {
                if (listCategory.Items[i].Selected == true)
                {
                    string[] arr = listCategory.Items[i].Value.Split('-');
                    string sbucode = arr[0].ToString();
                    string oucode = arr[1].ToString();
                    string catcode = arr[2].ToString();                   
                    qry = "insert into SN_USER_RIGHTS (ONUR_RECID,EMP_CODE,ENTITY_CODE,OU_CODE,SBU_CODE,SBU_CATEGORY_CODE,BRAND_CODE,STATUS,CREATED_BY,CREATED_ON) ";
                    qry += "values ( portal_RECID.nextval,'" + ddlEmpC.SelectedValue + "','" + ddlEntityC.SelectedValue + "','" + oucode + "','" + sbucode + "','" + catcode + "','0','A','" + userid + "',to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + "', 'dd/mm/yyyy hh:mi:ss AM')) ";                    
                    cmd = new OracleCommand(qry, ocon, trns);
                    cmd.ExecuteNonQuery(); count++;
                }
            }
            if (count > 0)
            {
                trns.Commit();
                CommonFunc.ShowAlertMessage("Data Saved : ", "USER_RIGHT.aspx");
            }
            else
            {
                CommonFunc.ShowAlert("Select Category ");
            }
        }
        catch (Exception ex)
        {
            trns.Rollback();
            CommonFunc.ShowAlert("Error : " + ex.Message);
        }
    }
    protected void gvRights_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        //inactive
        ocon = CommonFunc.con(); ocon.Open(); OracleTransaction trns = ocon.BeginTransaction(); ; OracleCommand cmd; string qry = "";
        try
        {
            if (e.CommandName == "inactive")
            {
                string ar = e.CommandArgument.ToString();
                qry = "update SN_USER_RIGHTS set status='I' , LAST_UPD_BY='" + userid + "',LAST_UPD_ON=to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + "', 'dd/mm/yyyy hh:mi:ss AM') where ONUR_RECID= '"+ar+"' ";
                
                cmd = new OracleCommand(qry, ocon, trns);
                cmd.ExecuteNonQuery();
            }
            
            trns.Commit();
            qry = "select  ONUR_RECID, (select employee_name from hrm_employee where EMP_CODE= s.EMP_CODE) EmployeeName, (select LEGAL_NAME from OC_ENTITY where ENTITY_CODE= s.ENTITY_CODE) ENTITY  ,OU_CODE,SBU_CODE,SBU_CATEGORY_CODE from SN_USER_RIGHTS s where STATUS='A' "; //,CREATED_BY,CREATED_ON,LAST_UPD_BY,LAST_UPD_ON ONUR_RECID ,BRAND_CODE,STATUS
            if (ddlEmp.SelectedIndex > 0)
                qry += " and EMP_CODE = '" + ddlEmp.SelectedValue + "'";
            if (ddlEntity.SelectedIndex > 0)
                qry += " and ENTITY_CODE = '" + ddlEntity.SelectedValue + "'";
            if (ddlSBU.SelectedIndex > 0)
                qry += " and SBU_CODE = '" + ddlSBU.SelectedValue + "'";
            if (ddlCategory.SelectedIndex > 0)
                qry += " and SBU_CATEGORY_CODE = '" + ddlCategory.SelectedValue + "'";
            ocon = CommonFunc.con();
            da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvRights.DataSource = ds;
                gvRights.DataBind(); gvRights.Visible = true;
            }
            else { gvRights.Visible = false; CommonFunc.ShowAlert("NO Data Found"); }
            CommonFunc.ShowAlert("Data Saved ");
        }
        catch (Exception ex)
        {
            trns.Rollback();
            CommonFunc.ShowAlert("Error : " + ex.Message);
        }
    }
}