﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MyClass;
using System.Data;
using System.Data.OracleClient;
using System.Globalization;
using System.Threading;

public partial class ShowSanctionApproved : System.Web.UI.Page
{
    OracleConnection ocon = new OracleConnection(); string myQ = "";
    OracleDataAdapter da; DataSet ds; string userid = "";
    CultureInfo hindi = new CultureInfo("hi-IN");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["emp_code"] != null && Session["emp_code"].ToString() != "")
        {
            userid = Session["emp_code"].ToString();
            //email = Session["email"].ToString();
        }
        if (!IsPostBack)
        {
            getdata();
        }
    }
    protected override void InitializeCulture()
    {
        //CultureInfo ci = new CultureInfo("en-IN");
        hindi.NumberFormat.CurrencySymbol = "₹";
        Thread.CurrentThread.CurrentCulture = hindi;

        base.InitializeCulture();
    }

    protected void getdata()
    {
        ocon = CommonFunc.con();
        string qry = "select SNS_RECID, (SELECT LEGAL_NAME FROM OC_ENTITY B where b.ENTITY_CODE = m.ENTITY_CODE)  ENTITY_CODE,  ";
        // qry += " sANCTION_NO, ";
        // qry += " to_char(SANCTION_DATE,'dd/MM/yyyy')SANCTION_DATE, current_status, 'Yet To be Approve by ' ||(select (select title|| ' ' || employee_name from hrm_employee where emp_code=a.emp_code) emp_code from SN_SANCTION_APPROVALS a  where  m.current_status =  a.S_NO and a.PARENT_RECID= m.SNS_RECID) curr_status, ";
        // qry += " FISCAL_YEAR,  (select DESCRIPTION from OC_SBU  where status='A' and SBU_CODE= m.SBU_CODE) SBU_CODE, ";
        // qry += " (SELECT DEPARTMENT_DESC FROM ALL_DEPARTMENTS where DEPARTMENT_CODE = DEPT_CODE AND COMPANY = 'DS') DEPT_CODE, ";
        // qry += " (SELECT  B.FUNC_DESC    FROM PROJECTS A, HRM_FUNCTION B, HRM_MAPPING_DEPT_FUNCTIONS C WHERE A.COMPANY = 'DS' AND A.HRIS_FUNCTION_CODE = B.FUNC_CODE AND A.STATUS  =  'A' AND A.HRIS_FUNCTION_CODE = C.FUNC_CODE  and C.DEPT_CODE= m.DEPT_CODE and A.PROJECT  = m.PROJECT) PROJECT, ";
        // qry += " VERSION_NO,HIERARCHY_CODE,SANCTION_SOUGHT_FOR,TOTAL_AMOUNT,BACKGROUD_INFO,CRITICAL_ISSUES_DETAIL,STATUS,CREATED_BY,CREATED_ON ";
        // qry += " From SN_SANCTIONS  m where  created_by='"+userid+"' and status='P'";

       qry = " select distinct SNS_RECID, (SELECT LEGAL_NAME FROM OC_ENTITY B where b.ENTITY_CODE = m.ENTITY_CODE)  ENTITY_CODE,  m.sANCTION_NO, ";
         qry += " to_char(SANCTION_DATE,'dd/MM/yyyy')SANCTION_DATE, current_status,   FISCAL_YEAR, ";
         qry += " (select DESCRIPTION from OC_SBU  where status='A' and SBU_CODE= m.SBU_CODE) SBU_CODE, ";
         qry += " (SELECT DEPARTMENT_DESC FROM ALL_DEPARTMENTS where DEPARTMENT_CODE = DEPT_CODE AND COMPANY = 'DS') DEPT_CODE, ";
         qry += " (SELECT  B.FUNC_DESC    FROM PROJECTS A, HRM_FUNCTION B, HRM_MAPPING_DEPT_FUNCTIONS C WHERE A.COMPANY = 'DS' AND A.HRIS_FUNCTION_CODE = B.FUNC_CODE AND A.STATUS  =  'A' AND A.HRIS_FUNCTION_CODE = C.FUNC_CODE  and C.DEPT_CODE= m.DEPT_CODE and A.PROJECT  = m.PROJECT) PROJECT, ";
         qry += " VERSION_NO,m.HIERARCHY_CODE,m.SANCTION_SOUGHT_FOR,m.TOTAL_AMOUNT,m.BACKGROUD_INFO,m.CRITICAL_ISSUES_DETAIL,m.STATUS ";
         qry += " From SN_SANCTIONS  m, SN_SANCTION_APPROVALS a ";
         qry += " where  (m.created_by='" + userid + "' or a.EMP_CODE= '" + userid + "' ) and status='A' and  a.PARENT_RECID= m.SNS_RECID ";
        DataSet ds = new DataSet();
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
        da.Fill(ds);//SNS_RECID  ENTITY_CODE sANCTION_NO SANCTION_DATE SBU_CODE PROJECT TOTAL_AMOUNT
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvData.DataSource = ds;
            gvData.DataBind();
        }
    }
    protected void gvData_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "view")
        {
            Response.Redirect("SanctionFormat.aspx?sid=" + e.CommandArgument.ToString());
        }
    }
}