﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class imisSite : System.Web.UI.MasterPage
{
    string userid = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (userid == "5502624" || userid == "5503394" || userid == "5504105" || userid == "4S00005" || userid == "4S00273" || userid == "4R00131" || userid == "4R00130" || userid == "5501185")
        {
            
        }
        else NavigationMenu.Items.Remove(NavigationMenu.FindItem("Reports"));
        
    }
}
