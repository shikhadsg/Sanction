﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MyClass;
using System.Data;
using System.Data.OracleClient;
using System.Globalization;
using System.Threading;

public partial class ShowSanctionByEntity : System.Web.UI.Page
{
    OracleConnection ocon = new OracleConnection(); string myQ = "";
    OracleDataAdapter da; DataSet ds; string userid = "";
    CultureInfo hindi = new CultureInfo("hi-IN");
    protected void Page_Load(object sender, EventArgs e)
    {
        //Session["emp_code"] = "5502624"; Session["name"] = "";
        if (Session["emp_code"] != null && Session["emp_code"].ToString() != "")
        {
            userid = Session["emp_code"].ToString();
        }
        if (!IsPostBack)
        {
            
           
               
                //email = Session["email"].ToString();
                DataSet ds = new DataSet();
                //userid = "5502624"; if (userid == "5502624" || userid == "5503394" || userid == "5504105"  || userid == "4S00005" || userid == "4S00273" ||  userid == "4R00131" || userid == "4R00130" || userid == "5501189")
                if (userid == "5502624" || userid == "5503394" || userid == "5504105" || userid == "5504477" || userid == "5501189" || userid == "5500994")
                {
                    ds = CommonFunc.GetSBU("DSL");
                    ddlSBU.Items.Clear(); ddlSBU.Items.Add(new ListItem("--Select--", "0"));
                    for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                    {
                        ddlSBU.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["SBU_CODE"].ToString()));
                    }
                    ds = CommonFunc.GetSBU("CON");                    
                    for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                    {
                        ddlSBU.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["SBU_CODE"].ToString()));
                    }
                    ds = CommonFunc.GetDept();
                    ddlDept.Items.Clear(); ddlDept.Items.Add(new ListItem("--Select--", "0"));
                    for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                    {
                        ddlDept.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["DEPARTMENT_CODE"].ToString()));
                    }

                }
                else if (userid == "4S00005" || userid == "4S00273" || userid == "5501189")
                {
                    //qry += "  and m.ENTITY_CODE='FDS'   ";
                    ds = CommonFunc.GetSBU("FDS");
                    ddlSBU.Items.Clear(); ddlSBU.Items.Add(new ListItem("--Select--", "0"));
                    for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                    {
                        ddlSBU.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["SBU_CODE"].ToString()));
                    }
                    ddlDept.Items.Clear(); ddlDept.Items.Add(new ListItem("--Select--", "0"));
                    ds = CommonFunc.GetDept();
                    for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                    {
                        ddlDept.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["DEPARTMENT_CODE"].ToString()));
                    }
                }
                else if (userid == "4R00131" || userid == "4R00130" || userid == "5501189")
                {
                    ddlSBU.Items.Add(new ListItem("DMP", "DMP"));
                    ds = CommonFunc.GetDept();
                    ddlDept.Items.Clear(); ddlDept.Items.Add(new ListItem("--Select--", "0"));
                    for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                    {
                        ddlDept.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["DEPARTMENT_CODE"].ToString()));
                    }
                }
            
        }
        
    }
    protected override void InitializeCulture()
    {
        //CultureInfo ci = new CultureInfo("en-IN");
        hindi.NumberFormat.CurrencySymbol = "₹";
        Thread.CurrentThread.CurrentCulture = hindi;

        base.InitializeCulture();
    }

    protected void getdata()
    {
        ocon = CommonFunc.con();
        string qry = "select SNS_RECID, (SELECT LEGAL_NAME FROM OC_ENTITY B where b.ENTITY_CODE = m.ENTITY_CODE)  ENTITY_CODE,  ";
        
       qry = " select distinct SNS_RECID, (SELECT LEGAL_NAME FROM OC_ENTITY B where b.ENTITY_CODE = m.ENTITY_CODE)  ENTITY_CODE,  m.sANCTION_NO, ";
       qry += " to_char(SANCTION_DATE,'dd/MM/yyyy')SANCTION_DATE, current_status,m.status,   FISCAL_YEAR, ";
         qry += " (select DESCRIPTION from OC_SBU  where status='A' and SBU_CODE= m.SBU_CODE) SBU_CODE, ";
         qry += " (SELECT DEPARTMENT_DESC FROM ALL_DEPARTMENTS where DEPARTMENT_CODE = DEPT_CODE AND COMPANY = 'DS') DEPT_CODE, ";
         qry += " (SELECT  B.FUNC_DESC    FROM PROJECTS A, HRM_FUNCTION B, HRM_MAPPING_DEPT_FUNCTIONS C WHERE A.COMPANY = 'DS' AND A.HRIS_FUNCTION_CODE = B.FUNC_CODE AND A.STATUS  =  'A' AND A.HRIS_FUNCTION_CODE = C.FUNC_CODE  and C.DEPT_CODE= m.DEPT_CODE and A.PROJECT  = m.PROJECT) PROJECT, ";
         qry += " VERSION_NO,m.HIERARCHY_CODE,m.SANCTION_SOUGHT_FOR,m.TOTAL_AMOUNT,m.BACKGROUD_INFO,m.CRITICAL_ISSUES_DETAIL,m.STATUS ";
         qry += " From SN_SANCTIONS  m, SN_SANCTION_APPROVALS a ";
         qry += " where  a.PARENT_RECID= m.SNS_RECID ";
         if (userid == "5502624" || userid == "5503394" || userid == "5504105" || userid == "5501189" || userid == "5500994")
         {
             qry += "  and m.ENTITY_CODE in ('DSL' ,'CON')  ";
         }
         else if (userid == "4S00005" || userid == "4S00273" || userid == "5501189")
         {
             qry += "  and m.ENTITY_CODE='FDS'   ";
         }
         else if (userid == "4R00131" || userid == "4R00130" || userid == "5501189")
         {
             qry += "  and m.ENTITY_CODE='DSL' and m.SBU_CODE='DMP'  ";
         }
         qry += "  and m.status in ('A','I')  order by DEPT_CODE,to_date(SANCTION_DATE,'dd/MM/yyyy') ";
        DataSet ds = new DataSet();
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
        da.Fill(ds);//SNS_RECID  ENTITY_CODE sANCTION_NO SANCTION_DATE SBU_CODE PROJECT TOTAL_AMOUNT 5504105
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvData.DataSource = ds;
            gvData.DataBind();
        }
    }
    protected void gvData_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "view")
        {
            Response.Redirect("SanctionFormat.aspx?sid=" + e.CommandArgument.ToString());
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        ocon = CommonFunc.con();
        string qry = "select SNS_RECID, (SELECT LEGAL_NAME FROM OC_ENTITY B where b.ENTITY_CODE = m.ENTITY_CODE)  ENTITY_CODE,  ";

        qry = " select distinct SNS_RECID, (SELECT LEGAL_NAME FROM OC_ENTITY B where b.ENTITY_CODE = m.ENTITY_CODE)  ENTITY_CODE,  m.sANCTION_NO, ";
        qry += " to_char(SANCTION_DATE,'dd/MM/yyyy')SANCTION_DATE, current_status,status,   FISCAL_YEAR, ";
        qry += " (select DESCRIPTION from OC_SBU  where status='A' and SBU_CODE= m.SBU_CODE) SBU_CODE, ";
        qry += " (SELECT DEPARTMENT_DESC FROM ALL_DEPARTMENTS where DEPARTMENT_CODE = DEPT_CODE AND COMPANY = 'DS') DEPT_CODE, ";
        qry += " (SELECT  B.FUNC_DESC    FROM PROJECTS A, HRM_FUNCTION B, HRM_MAPPING_DEPT_FUNCTIONS C WHERE A.COMPANY = 'DS' AND A.HRIS_FUNCTION_CODE = B.FUNC_CODE AND A.STATUS  =  'A' AND A.HRIS_FUNCTION_CODE = C.FUNC_CODE  and C.DEPT_CODE= m.DEPT_CODE and A.PROJECT  = m.PROJECT) PROJECT, ";
        qry += " VERSION_NO,m.HIERARCHY_CODE,m.SANCTION_SOUGHT_FOR,m.TOTAL_AMOUNT,m.BACKGROUD_INFO,m.CRITICAL_ISSUES_DETAIL,m.STATUS ";
        qry += " From SN_SANCTIONS  m, SN_SANCTION_APPROVALS a ";
        qry += " where  a.PARENT_RECID= m.SNS_RECID ";
        if (userid == "5502624" || userid == "5503394" || userid == "5504477" || userid == "5504105" || userid == "5501189" || userid == "5500994")
        {
            qry += "  and m.ENTITY_CODE in ('DSL','CON')   ";
        }
        else if (userid == "4S00005" || userid == "4S00273" || userid == "5501189")
        {
            qry += "  and m.ENTITY_CODE='FDS'   ";
        }
        else if (userid == "4R00131" || userid == "4R00130" || userid == "5501189")
        {
            qry += "  and m.ENTITY_CODE='DSL' and m.SBU_CODE='DMP'  ";
        }
        else{
            qry += " and rownum<0 ";
        }
        if(ddlSBU.SelectedIndex >0)
        {
            qry += " and m.SBU_CODE='"+ddlSBU.SelectedValue+"' ";
        }
        if (ddlDept.SelectedIndex > 0)
        {
            qry += " and m.DEPT_CODE='" + ddlDept.SelectedValue + "' ";
        }
        if (txtSanc.Text !="")
        {
            qry += " and m.sANCTION_NO like '%" + txtSanc.Text+ "%' ";
        }
        if (txtAmtFrom.Text != "")
        {
            qry += " and m.TOTAL_AMOUNT >= '" + txtAmtFrom.Text + "' ";
        }
        if (txtAmtTo.Text != "")
        {
            qry += " and m.TOTAL_AMOUNT <= '" + txtAmtTo.Text + "' ";
        }

        qry += "  and status in ('A','I') order by DEPT_CODE,to_date(SANCTION_DATE,'dd/MM/yyyy')  ";
        DataSet ds = new DataSet();
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
        da.Fill(ds);//SNS_RECID  ENTITY_CODE sANCTION_NO SANCTION_DATE SBU_CODE PROJECT TOTAL_AMOUNT 5504105
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvData.DataSource = ds;
            gvData.DataBind();
            gvData.Visible = true;
        }
        else
        {
            gvData.Visible = false;
            CommonFunc.ShowAlert("No Record Found.");
        }
    }
}