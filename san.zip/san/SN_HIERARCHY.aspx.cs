﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MyClass;
using System.Data;
using System.Data.OracleClient;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class SN_HIERARCHY : System.Web.UI.Page
{
    //protected void Page_Load(object sender, EventArgs e)
    //{

    //}
    OracleConnection ocon = new OracleConnection();
    OracleDataAdapter da; DataSet ds; string userid = "USERPORTAL";
    private void FillDropDownList(DropDownList ddl) {
           // ArrayList arr = GetDummyData();
        ds = CommonFunc.GetEmpList("");
        for (int k = 0; k < ds.Tables[0].Rows.Count; k++ )
        {
            ddl.Items.Add(new ListItem(ds.Tables[0].Rows[k]["employee_name"].ToString(),ds.Tables[0].Rows[k]["emp_code"].ToString()));
        }
        }

        private void SetInitialRow() {

            DataTable dt = new DataTable();
            DataRow dr = null;

            dt.Columns.Add(new DataColumn("RowNumber", typeof(string)));
            dt.Columns.Add(new DataColumn("Column1", typeof(string)));//for TextBox value 
            dt.Columns.Add(new DataColumn("Column2", typeof(string)));//for TextBox value 
            dt.Columns.Add(new DataColumn("Column3", typeof(string)));//for DropDownList selected item 
            dt.Columns.Add(new DataColumn("Column4", typeof(string)));//for DropDownList selected item 

            dr = dt.NewRow();
            dr["RowNumber"] = 1;
            dr["Column1"] = string.Empty;
            dr["Column2"] = string.Empty;
            dt.Rows.Add(dr);

            //Store the DataTable in ViewState for future reference 
            ViewState["CurrentTable"] = dt;

            //Bind the Gridview 
            Gridview1.DataSource = dt;
            Gridview1.DataBind();

            //After binding the gridview, we can then extract and fill the DropDownList with Data 
            DropDownList ddlEmp = (DropDownList)Gridview1.Rows[0].Cells[1].FindControl("ddlEmp");
            //DropDownList ddl2 = (DropDownList)Gridview1.Rows[0].Cells[4].FindControl("DropDownList2");
            FillDropDownList(ddlEmp);
            
        }

        private void AddNewRowToGrid() {

            if (ViewState["CurrentTable"] != null) {

                DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
                DataRow drCurrentRow = null;

                if (dtCurrentTable.Rows.Count > 0) {
                    drCurrentRow = dtCurrentTable.NewRow();
                    drCurrentRow["RowNumber"] = dtCurrentTable.Rows.Count + 1;

                    //add new row to DataTable 
                    dtCurrentTable.Rows.Add(drCurrentRow);
                   

                    for (int i = 0; i < dtCurrentTable.Rows.Count -1; i++) {

                        DropDownList ddlEmp = (DropDownList)Gridview1.Rows[i].Cells[3].FindControl("ddlEmp");
                        DropDownList ddlM = (DropDownList)Gridview1.Rows[i].Cells[4].FindControl("ddlM");
                        DropDownList ddlRole = (DropDownList)Gridview1.Rows[i].Cells[4].FindControl("ddlRole");

                        // Update the DataRow with the DDL Selected Items 

                        dtCurrentTable.Rows[i]["Column1"] = ddlEmp.SelectedItem.Text;
                        dtCurrentTable.Rows[i]["Column2"] = ddlM.SelectedItem.Text;
                        dtCurrentTable.Rows[i]["Column3"] = ddlRole.SelectedItem.Text;

                    }

                    //Store the current data to ViewState for future reference 
                    ViewState["CurrentTable"] = dtCurrentTable;


                    //Rebind the Grid with the current data to reflect changes 
                    Gridview1.DataSource = dtCurrentTable;
                    Gridview1.DataBind();
                }
            }
            else {
                Response.Write("ViewState is null");

            }
            //Set Previous Data on Postbacks 
            SetPreviousData();
        }

        private void SetPreviousData() {

            int rowIndex = 0;
            if (ViewState["CurrentTable"] != null) {

                DataTable dt = (DataTable)ViewState["CurrentTable"];
                if (dt.Rows.Count > 0) {

                    for (int i = 0; i < dt.Rows.Count; i++) {

                        //TextBox box1 = (TextBox)Gridview1.Rows[i].Cells[1].FindControl("TextBox1");
                        //TextBox box2 = (TextBox)Gridview1.Rows[i].Cells[2].FindControl("TextBox2");

                        DropDownList ddlEmp = (DropDownList)Gridview1.Rows[i].Cells[3].FindControl("ddlEmp");
                        DropDownList ddlM = (DropDownList)Gridview1.Rows[i].Cells[4].FindControl("ddlM");
                        DropDownList ddlRole = (DropDownList)Gridview1.Rows[i].Cells[4].FindControl("ddlRole");

                        //Fill the DropDownList with Data 
                        FillDropDownList(ddlEmp);
                        //FillDropDownList(ddl2);

                        if (i < dt.Rows.Count  ) {

                            //Assign the value from DataTable to the TextBox 
                            //box1.Text = dt.Rows[i]["Column1"].ToString();
                            //box2.Text = dt.Rows[i]["Column2"].ToString();

                            //Set the Previous Selected Items on Each DropDownList  on Postbacks 
                            if(dt.Rows[i]["Column1"].ToString() !="")
                            {
                            ddlEmp.ClearSelection();
                            ddlEmp.Items.FindByText(dt.Rows[i]["Column1"].ToString()).Selected = true;

                            ddlM.ClearSelection();
                            ddlM.Items.FindByText(dt.Rows[i]["Column2"].ToString()).Selected = true;

                            ddlRole.ClearSelection();
                            ddlRole.Items.FindByText(dt.Rows[i]["Column3"].ToString()).Selected = true;

                            }
                        }

                        rowIndex++;
                    }
                }
            }
        }

        protected void Page_Load(object sender, EventArgs e) {
            if (!Page.IsPostBack) {
                //SetInitialRow();
                //DEPT_CODE,DESCRIPTION
                ds = CommonFunc.GetDept();
                ddlDept.Items.Clear(); ddlDept.Items.Add("--Select--");
                ddlEntity.Items.Clear(); ddlEntity.Items.Add("--Select--");
                for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                {
                    ddlDept.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["DEPARTMENT_CODE"].ToString()));
                }
                ds = CommonFunc.GetEntity();
                for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                {
                    ddlEntity.Items.Add(new ListItem(ds.Tables[0].Rows[k]["LEGAL_NAME"].ToString(), ds.Tables[0].Rows[k]["ENTITY_CODE"].ToString()));
                }
                
            }
        }

        protected void ButtonAdd_Click(object sender, EventArgs e) {
            AddNewRowToGrid();
        }

        protected void Gridview1_RowCreated(object sender, GridViewRowEventArgs e) {
            if (e.Row.RowType == DataControlRowType.DataRow) {
                DataTable dt = (DataTable)ViewState["CurrentTable"];
                LinkButton lb = (LinkButton)e.Row.FindControl("LinkButton1");
                if (lb != null) {
                    if (dt.Rows.Count > 1) {
                        if (e.Row.RowIndex == dt.Rows.Count - 1) {
                            lb.Visible = false;
                        }
                    }
                    else {
                        lb.Visible = false;
                    }
                }
            }
        }

        protected void LinkDelete_Click(object sender, EventArgs e) {
            LinkButton lb = (LinkButton)sender;
            GridViewRow gvRow = (GridViewRow)lb.NamingContainer;
            int rowID = gvRow.RowIndex;
            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
            //DataRow drCurrentRow = null;

            for (int i = 0; i < dtCurrentTable.Rows.Count ; i++)
            {

                DropDownList ddlEmp = (DropDownList)Gridview1.Rows[i].Cells[3].FindControl("ddlEmp");
                DropDownList ddlM = (DropDownList)Gridview1.Rows[i].Cells[4].FindControl("ddlM");
                DropDownList ddlRole = (DropDownList)Gridview1.Rows[i].Cells[4].FindControl("ddlRole");

                // Update the DataRow with the DDL Selected Items 

                dtCurrentTable.Rows[i]["Column1"] = ddlEmp.SelectedItem.Text;
                dtCurrentTable.Rows[i]["Column2"] = ddlM.SelectedItem.Text;
                dtCurrentTable.Rows[i]["Column3"] = ddlRole.SelectedItem.Text;

            }

            //Store the current data to ViewState for future reference 
            ViewState["CurrentTable"] = dtCurrentTable;


            if (ViewState["CurrentTable"] != null) {

                DataTable dt = (DataTable)ViewState["CurrentTable"];
                if (dt.Rows.Count > 1) {
                    if (gvRow.RowIndex <= dt.Rows.Count - 1) {
                        //Remove the Selected Row data and reset row number
                        dt.Rows.Remove(dt.Rows[rowID]);
                        ResetRowID(dt);
                    }
                }

                //Store the current data in ViewState for future reference
                ViewState["CurrentTable"] = dt;

                //Re bind the GridView for the updated data
                Gridview1.DataSource = dt;
                Gridview1.DataBind();
            }

            //Set Previous Data on Postbacks
            SetPreviousData();
        }

        private void ResetRowID(DataTable dt) {
            int rowNumber = 1;
            if (dt.Rows.Count > 0) {
                foreach (DataRow row in dt.Rows) {
                    row[0] = rowNumber;
                    rowNumber++;
                }
            }
        }
        protected void ddlDept_SelectedIndexChanged(object sender, EventArgs e)
        {
            //FillDropDownList(ddlEmp);
        }
        protected void btnCreate_Click(object sender, EventArgs e)
        {
            if (ddlDept.SelectedIndex > 0 && ddlEntity.SelectedIndex > 0 && txtHcode.Text != "" && txtDesc.Text != "")
            {
                ddlDept.Enabled = false;
                btnCreate.Enabled = false;
                SetInitialRow();
                btnSave.Visible = true;
            }
            else
            {
                CommonFunc.ShowAlert("All fields are mandatory!!");
            }
        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            //btnSave.Enabled = false;
            OracleCommand cmd; string qry = "";
            ocon = CommonFunc.con(); ocon.Open();
            qry = "select portal_RECID.nextval from dual ";
            cmd = new OracleCommand(qry, ocon);
            string pid = cmd.ExecuteScalar().ToString();
            OracleTransaction trns = ocon.BeginTransaction(); ; 
            try
            {
                qry = " insert into SN_HIERARCHY (SNH_RECID,ENTITY_CODE,DEPT_CODE,HIERARCHY_CODE,DESCRIPTION,STATUS,CREATED_BY,CREATED_ON,SBU_CODE , SBU_CATEGORY_CODE ,OU_CODE)  ";
                qry += " values ('" + pid + "','" + ddlEntity.SelectedValue + "','" + ddlDept.SelectedValue + "','" + Server.HtmlEncode(txtHcode.Text.Trim()) + "','" + Server.HtmlEncode(txtDesc.Text.Trim()) + "','A','" + userid + "',to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh.mm.ss") + "','dd/MM/YYYY HH24.MI.SS') ,'" + ddlSBU.SelectedValue + "' , '" + ddlSBUCAT.SelectedValue + "' ,'" + ddlUnit.SelectedValue + "' )";

                cmd = new OracleCommand(qry, ocon, trns);
                cmd.ExecuteNonQuery();
                //DataTable dt = (DataTable)ViewState["CurrentTable"]; //(DataTable)Gridview1.DataSource;
                for (int a = 0; a < Gridview1.Rows.Count; a++)
                {
                    string id = a.ToString();//Gridview1.Rows[a].Cells[0].Text.ToString();
                    DropDownList ddlecode = (DropDownList)Gridview1.Rows[a].FindControl("ddlEmp");
                    DropDownList ddlM = (DropDownList)Gridview1.Rows[a].FindControl("ddlM");
                    DropDownList ddlRole = (DropDownList)Gridview1.Rows[a].FindControl("ddlRole");

                    qry = "insert into   SN_HIERARCHY_DETAIL (SNHD_RECID,ENTITY_CODE,HIERARCHY_CODE,S_NO,EMP_CODE,MANDATORY,ROLE,STATUS,CREATED_BY,CREATED_ON,PARENT_RECID) ";
                    qry += " values (portal_RECID.nextval,'" + ddlEntity.SelectedValue + "','" + Server.HtmlEncode(txtHcode.Text.Trim()) + "','" + a + "','" + ddlecode.SelectedValue + "','" + ddlM.SelectedValue + "','" + ddlRole.SelectedValue + "','A','" + userid + "',to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh.mm.ss") + "','dd/MM/YYYY HH24.MI.SS'),'" + pid + "')";
                    cmd = new OracleCommand(qry, ocon, trns);
                    cmd.ExecuteNonQuery();
                }
                trns.Commit();
                CommonFunc.ShowAlert("Data saved sucessfully");
            }
            catch (Exception ex)
            {
                trns.Rollback();
                CommonFunc.ShowAlert("Error : " + ex.Message);
            }
            finally { ocon.Close(); }
        }
        protected void ddlEntity_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlSBU.Items.Clear(); ddlSBU.Items.Add("---");
            ds = CommonFunc.GetSBU(ddlEntity.SelectedValue);
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                ddlSBU.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["SBU_CODE"].ToString()));
            }

            
        }
        protected void ddlUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlSBUCAT.Items.Clear(); ddlSBUCAT.Items.Add("---");
            ds = CommonFunc.GetCategoryAll(ddlSBU.SelectedValue, ddlUnit.SelectedValue, ddlEntity.SelectedValue);
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                ddlSBUCAT.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["SBU_CATEGORY_CODE"].ToString()));
            }
        }
        protected void ddlSBU_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlUnit.Items.Clear(); ddlUnit.Items.Add("---");
            ds = CommonFunc.GetUNIT(ddlEntity.SelectedValue,ddlSBU.SelectedValue);
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                ddlUnit.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["OU_CODE"].ToString()));
            }
        }
}
