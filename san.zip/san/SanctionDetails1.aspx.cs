﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MyClass;
using System.Data;
using System.Data.OracleClient;

public partial class SanctionDetails1 : System.Web.UI.Page
{
    OracleConnection ocon = new OracleConnection(); string qry = ""; string email = "",role="";
    OracleDataAdapter da; DataSet ds; string userid = "", imisid = "", map_userid=""; string recid = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if(Session["recid"] !=null && Session["recid"].ToString()!="")
        {
            recid = Session["recid"].ToString();
            lblrecid.Text = recid;
        }
        if (Session["emp_code"] != null && Session["emp_code"].ToString() != "")
        {
            userid = Session["emp_code"].ToString();
            email = Session["email"].ToString();
            imisid = Session["imisid"].ToString();
        }
           
        else { Server.Transfer("login.aspx"); }

        if (Session["emp_code_map"] != null && Session["emp_code_map"].ToString() != "")
        {
            map_userid = Session["emp_code_map"].ToString();
        }
        if (Request.QueryString["sid"] != null && Request.QueryString["sid"].ToString() != "")
        {
            recid = Request.QueryString["sid"].ToString(); lblrecid.Text = recid;
        }
        if (!IsPostBack)
        {
            ds = CommonFunc.getMasterDetail(recid, "");
            //   FISCAL_YEAR     VERSION_NO HIERARCHY_CODE  TOTAL_AMOUNT current_status          }
            if(ds.Tables[0].Rows.Count>0)
            {
                DataRow dr =ds.Tables[0].Rows[0];
                lblSancDate.Text = dr["SANCTION_DATE"].ToString();
                lblSancNo.Text = dr["SANCTION_NO"].ToString();
                lblEntity.Text = dr["ENTITY_CODE_d"].ToString();
                lblEnt.Text = dr["ENTITY_CODE"].ToString();
                lblVersion.Text = dr["VERSION_NO"].ToString();
                lblTotal.Text = dr["TOTAL_AMOUNT"].ToString();
                lblSBU.Text = dr["SBU_CODE_d"].ToString();
                lblsb.Text = dr["SBU_CODE"].ToString();
                lblDepartment.Text = dr["DEPT_CODE_d"].ToString();
                lblDept.Text = dr["DEPT_CODE"].ToString();
                lblFunction.Text = dr["PROJECT"].ToString();
                lblFyear.Text = dr["FISCAL_YEAR"].ToString();
                lblSoughtFor.Text = dr["SANCTION_SOUGHT_FOR"].ToString();
                txtback.Text = dr["BACKGROUD_INFO"].ToString();
                txtIssues.Text = dr["CRITICAL_ISSUES_DETAIL"].ToString();
                lblstatus.Text = dr["current_status"].ToString();
                lblIntBy.Text = dr["CREATED_BY"].ToString();
                lblInton.Text = dr["CREATED_ON"].ToString();
                lblHcode.Text = dr["HIERARCHY_CODE"].ToString();
                getDetailData(); getisApprover(); getloginempcode();
                if (lblRole.Text == "A")
                {                    
                   // btnEdit.Visible = true;//getApprovalLimit();
                    pnlApproval.Visible = true;
                    btnSubmit.Text = "Approve";
                }
                if (map_userid.Equals("A1") || map_userid.Equals("A2") || map_userid.Equals("A3") || map_userid.Equals("A4"))
                {
                    btnSubmit.Text = "Clear for Approval";
                }
            }
        }
    }


    protected void getloginempcode()
    {
        int st = Convert.ToInt32(lblstatus.Text);
        
        qry = "select   emp_code  from SN_SANCTION_APPROVALS s where PARENT_RECID= '" + recid + "'  and S_NO= " + st;
        ocon = CommonFunc.con();
        string toid = "";// Convert.ToString(cmd.ExecuteScalar());
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
        DataSet ds = new DataSet();
        da.Fill(ds); string flag = "N";
        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        {
            if (userid == ds.Tables[0].Rows[i]["emp_code"].ToString() || map_userid == ds.Tables[0].Rows[i]["emp_code"].ToString() )
            {
                flag = "Y";
            }
            else
            {
                //CommonFunc.ShowAlertMessage("Invaild Id","ShowPendingSanctionList.aspx");                
            }
            
        }
        if(flag=="N")
        {
            Response.Redirect("ShowPendingSanctionList.aspx");
        }
        
    }


    protected string getApprovalLimit()
    {

        qry = "SELECT nvl(SANCTION_APPROVAL_LIMIT,0) FROM  PO_APPROVAL_LIMIT B WHERE B.USER_ID='" + imisid + "' ";

        ocon = CommonFunc.con();
        if (ocon.State == ConnectionState.Closed)
            ocon.Open();
        OracleCommand cmd = new OracleCommand(qry, ocon);
        string amount = Convert.ToString(cmd.ExecuteScalar());

        if (ocon.State == ConnectionState.Open)
            ocon.Close();
        double amt = 0, sancamt = 0;
        if (amount != "")
            amt = Convert.ToDouble(amount);
        if (lblTotal.Text != "")
        {
            sancamt = Convert.ToDouble(lblTotal.Text);
        }
        if (sancamt > amt)
        {
            CommonFunc.ShowAlert("Sanction amount is exceeding from Approval Limit.");
            btnSubmit.Visible = false; btnReinitiate.Visible = false; btncan.Visible = false; btnSaveApp.Visible = false; lnkeedit.Visible = false;
        }

        return amount;
    }

    protected string gettoMailId()
    {
        int st = Convert.ToInt32(lblstatus.Text);
        st = st + 1;
        qry = "select   (select email_id from hrm_employee where  emp_code = s.emp_code) mailid from SN_SANCTION_APPROVALS s where PARENT_RECID= '" + recid + "'  and S_NO= " + st;
        qry = "select distinct case  when s.emp_code like 'A%' then  (select email_id from hrm_employee v, EMP_MAPPING_APPROVAL m where v.emp_code = m.emp_code and m.MAPPING_CODE= s.emp_code ) ";
        qry += " else (select email_id from hrm_employee vhe where  vhe.emp_code = s.emp_code) end enail_id  from SN_SANCTION_APPROVALS s where PARENT_RECID= '" + recid + "'  and S_NO= " + st;
        ocon = CommonFunc.con();
        if (ocon.State == ConnectionState.Closed)
            ocon.Open();
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
        DataSet ds = new DataSet();
        da.Fill(ds); string toid = "";
        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        {
            if(toid =="")
                toid = ds.Tables[0].Rows[i][0].ToString() ;
            else
                toid = toid + "," + ds.Tables[0].Rows[i][0].ToString();
        }
        return toid;
    }
    protected string getisApprover()
    {
        int st = Convert.ToInt32(lblstatus.Text);
        //st = st + 1;
        qry = "select role from SN_SANCTION_APPROVALS s where PARENT_RECID= '" + recid + "'  and S_NO= " + st;
        ocon = CommonFunc.con();
        if (ocon.State == ConnectionState.Closed)
            ocon.Open();
        OracleCommand cmd = new OracleCommand(qry, ocon);
        string toid = Convert.ToString(cmd.ExecuteScalar());
        lblRole.Text = toid;
        if (lblRole.Text == "A")
        {
            
                for (int i = 0; i < gvDetail.Rows.Count; i++)
                {
                    
                        TextBox lblamt = (TextBox)gvDetail.Rows[i].FindControl("lblamt");

                        if (gvDetail.Rows.Count > 1)
                        {
                            ImageButton imgDel = (ImageButton)gvDetail.Rows[i].FindControl("imgDel"); imgDel.Visible = true;
                        }
                    lblamt.Enabled = true; 
                }
            
        }

        return toid;
    }

    protected string getcancleMailId()
    {
        int st = Convert.ToInt32(lblstatus.Text);
        st = st + 1;
        qry = "select (select email_id from hrm_employee where  emp_code = s.emp_code) mailid from SN_SANCTION_APPROVALS s where PARENT_RECID= '" + recid + "' ";
        ocon = CommonFunc.con();
       
        string toid = "";// Convert.ToString(cmd.ExecuteScalar());
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
        DataSet ds = new DataSet();
        da.Fill(ds);
        for(int i=0;i<ds.Tables[0].Rows.Count; i++)
        {
            if (toid == "")
                toid = ds.Tables[0].Rows[i][0].ToString();
            else
                toid = toid + "," + ds.Tables[0].Rows[i][0].ToString();
        }

        return toid;
    }

    protected string getCreatedMailId()
    {
        int st = Convert.ToInt32(lblstatus.Text);
        st = st + 1;
        qry = "select (select email_id from hrm_employee where  emp_code = s.created_by) mailid from SN_SANCTIONS s where SNS_RECID= '" + recid + "'  and status= 'P'";
        ocon = CommonFunc.con();
        if (ocon.State == ConnectionState.Closed)
            ocon.Open();
        OracleCommand cmd = new OracleCommand(qry, ocon);
        string toid =  Convert.ToString(cmd.ExecuteScalar());
        return toid;
    }

    protected string gettoempcode()
    {
        int st = Convert.ToInt32(lblstatus.Text);
        st = st + 1;
        qry = "select distinct  emp_code  from SN_SANCTION_APPROVALS s where PARENT_RECID= '" + recid + "'  and S_NO= " + st;
        ocon = CommonFunc.con();
        string toid = "";// Convert.ToString(cmd.ExecuteScalar());
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
        DataSet ds = new DataSet();
        da.Fill(ds);
        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        {
            toid = toid + "," + ds.Tables[0].Rows[i][0].ToString();
        }
        return toid;
    }

    protected void getDetailData()
    {
                        //BUDGET_AMOUNT CONSUMED_AMOUNT BALANCE_AMOUNT  

        qry = " select  SNSD_RECID,  (SELECT LEGAL_NAME FROM OC_ENTITY B WHERE status='A' and ENTITY_CODE= s.ENTITY_CODE) ENTITY_CODE, s.SANCTION_NO,to_char(s.SANCTION_DATE,'dd/mm/yyyy') SANCTION_DATE, ";
        qry += " (select DESCRIPTION from OC_OPERATING_UNIT o where o.ENTITY_CODE = s.ENTITY_CODE and o.OU_CODE = s.OU_CODE  ) OU_CODE, ";
        qry += "  (SELECT  B.DESCRIPTION FROM  OC_SBU_CATEGORY B WHERE  b.SBU_CODE = m.SBU_CODE and B.SBU_CATEGORY_CODE =s.SBU_CATEGORY_CODE  )SBU_CATEGORY_CODE, ";
        //--(SELECT   C.DESCRIPTION FROM  OC_BRANDS  C WHERE C.SBU_CATEGORY_CODE =  s.SBU_CATEGORY_CODE AND C.STATUS = 'A' AND EXISTS (SELECT '1' FROM OC_SBU_MAPPING D WHERE D.OU_CODE = s.OU_CODE AND D.SBU_CATEGORY_CODE = s.SBU_CATEGORY_CODE AND D.BRAND_CODE = C.BRAND_CODE AND D.STATUS = 'A'))
        qry += " (SELECT  C.DESCRIPTION FROM  OC_BRANDS C WHERE  c.SBU_CODE = m.SBU_CODE and C.BRAND_CODE = s.BRAND_CODE AND c.SBU_CATEGORY_CODE = s.SBU_CATEGORY_CODE )  BRAND_CODE, ";
        qry += " (SELECT  C.DESCRIPTION FROM  OC_PRODUCTS C WHERE  c.SBU_CODE = m.SBU_CODE and C.BRAND_CODE = s.BRAND_CODE AND c.SBU_CATEGORY_CODE = s.SBU_CATEGORY_CODE and c.PRODUCT_ID = s.PRODUCT_ID) product_ID, ";
        qry += " EXPENSE_CODE_BUDGET ||'-' || (select head_description from OC_EXPENSE_MASTER where status='A' and record_type='I' and EXPENSE_CODE_BUDGET=s.EXPENSE_CODE_BUDGET and HRIS_DEPT_CODE ='"+ lblDept.Text+"' ) EXPENSE_CODE_BUDGET, ";

        qry += " SEQ_NO,  PARTICULARS,SPECIFICATIONS,case when BUDGET_APPROVED='Y' then 'Yes' else 'No' end BUDGET_APPROVED, BUDGET_REF_NO,SANCTION_AMOUNT,BUDGET_AMOUNT,CONSUMED_AMOUNT,BALANCE_AMOUNT,BUDGET_AMOUNT_UPTO ,BALANCE_AMOUNT_UPTO ";
        qry += " from SN_SANCTIONS_DETAILS  s,SN_SANCTIONS m where PARENT_RECID = '" + lblrecid.Text + "' and s. PARENT_RECID =  m.SNS_RECID  and nvl(s.status,'A')<>'I' order by s.SEQ_NO ";
            ocon = CommonFunc.con(); 
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvDetail.DataSource = ds;
                gvDetail.DataBind();
                gvBudget.DataSource = ds;
                gvBudget.DataBind();
            }
            Label l = (Label)gvDetail.FooterRow.FindControl("lblTotal");
            if (l != null)
            {
                l.Text = lblTotal.Text;
            } getapp();  getAttach();
            string q = "select added_by,ROLE from SN_SANCTION_APPROVALS s where PARENT_RECID= '" + lblrecid.Text + "'  and emp_code= " + userid;
            ocon = CommonFunc.con();
             da = new OracleDataAdapter(qry, ocon);
             ds = new DataSet();
            da.Fill(ds);

    }

   

    protected void btnEdit_Click(object sender, EventArgs e)
    {
        Session["edit_by"] = "A";
        Response.Redirect("editSanction.aspx?sid=" + lblrecid.Text);
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {        
        
            btnSubmit.Enabled = false;
            int st = Convert.ToInt32(lblstatus.Text);
            st = st + 1;
            updateStatus(st);
            
            CommonFunc.ShowAlertMessage("Record Saved.", "ShowPendingSanctionList.aspx");
        //}
        //else
        //{
        //    CommonFunc.ShowAlert("Kindly enter remark..");
        //}        
    }

    protected void updateStatus(int status)
    {
        string toid = gettoMailId(); string toemp = gettoempcode(); string toidF = ""; string qry = ""; OracleCommand cmd1;
        //getloginempcode();
        if (toid == "")
            toidF = getCreatedMailId();
        int curr_st = status - 1;
        qry = " select nvl(count(*),0) c from 	SN_SANCTION_APPROVALS where  PARENT_RECID ='" + recid + "'   and s_no='" + curr_st + "' and approved_by is null and SKIPPED ='Y' and emp_code not in ('" + userid + "', '" + map_userid + "') ";
        
        ocon = CommonFunc.con(); ocon.Open();
        cmd1 = new OracleCommand(qry, ocon);
        int is_exist = Convert.ToInt16( cmd1.ExecuteScalar());
        
        OracleTransaction trns = ocon.BeginTransaction(); ; OracleCommand cmd; 
        try
        {
            if (ocon.State == ConnectionState.Closed)
                ocon.Open();
            if (toid == "" && lblRole.Text == "A")
            {
                double total_amt = getTotalAmount();
                qry = "update  SN_SANCTIONS set current_status='" + status + "', status='A', TOTAL_AMOUNT='" + total_amt + "', LAST_UPD_BY='" + userid + "'  ,LAST_UPD_ON = to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + "', 'dd/mm/yyyy hh:mi:ss AM') where SNS_RECID='" + recid + "' ";
                cmd = new OracleCommand(qry, ocon, trns);
                cmd.ExecuteNonQuery();

                for (int i = 0; i < gvDetail.Rows.Count; i++)
                {
                    TextBox lblamt = (TextBox)gvDetail.Rows[i].FindControl("lblamt");
                    Label lblsid = (Label)gvDetail.Rows[i].FindControl("lblsid");
                    qry = " update SN_SANCTIONS_DETAILS set SANCTION_AMOUNT='" + lblamt.Text + "', LAST_UPD_BY='" + userid + "'  ,LAST_UPD_ON = to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + "', 'dd/mm/yyyy hh:mi:ss AM')   where  SNSD_RECID= '" + lblsid.Text + "'  and  SANCTION_NO='" + lblSancNo.Text + "'";

                    cmd = new OracleCommand(qry, ocon, trns);
                    cmd.ExecuteNonQuery();
                }
            }
            else if (is_exist == 0)
              qry = "update  SN_SANCTIONS set current_status='" + status + "', LAST_UPD_BY='" + userid + "'  ,LAST_UPD_ON = to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + "', 'dd/mm/yyyy hh:mi:ss AM') where SNS_RECID='" + recid + "' ";
            else 
                qry = "update  SN_SANCTIONS set  LAST_UPD_BY='" + userid + "'  ,LAST_UPD_ON = to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + "', 'dd/mm/yyyy hh:mi:ss AM') where SNS_RECID='" + recid + "' ";
            
            
            cmd = new OracleCommand(qry, ocon, trns);
            cmd.ExecuteNonQuery();

            qry = "update SN_SANCTION_APPROVALS set REMARKS = '" + Server.HtmlEncode(txtRemark.Text) + "',   APPROVED_BY='" + userid + "', APPROVED_ON =to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + "', 'dd/mm/yyyy hh:mi:ss AM'), ADDED_BY='PORTAL' where  PARENT_RECID ='" + recid + "' and emp_code= '" + userid + "' and APPROVED_BY is null";
            cmd = new OracleCommand(qry, ocon, trns);
            cmd.ExecuteNonQuery();
            string p = Server.MapPath("~/HtmlTemplate.htm");
            string flag = "";
            if (is_exist == 0)
            {
                if (toid != "")
                    flag = CommonFunc.mailpprove(toid, email, Session["name"].ToString(), recid, p,lblSancNo.Text);
                else
                    flag = CommonFunc.mailpproveAlert(toidF, email, Session["name"].ToString(),recid,p, lblSancNo.Text);
                if (flag == "Y")
                {
                    qry = mailLog(flag, "", toemp, toid);
                    cmd = new OracleCommand(qry, ocon, trns);
                    cmd.ExecuteNonQuery();
                }
                else
                {
                    qry = mailLog("N", flag, toemp, toid);
                    cmd = new OracleCommand(qry, ocon, trns);
                    cmd.ExecuteNonQuery();
                }
            }
            trns.Commit();
            ocon.Close();
           
        }
        catch (Exception ex)
        {
            trns.Rollback();
            CommonFunc.ShowAlert("Error " + ex.Message);
            btnReinitiate.Enabled = true; btnSubmit.Enabled = true;
        }
    }
    protected void getapp()
    {
        qry = " select  S_NO SNO, (select employee_name from hrm_employee where EMP_CODE= s.EMP_CODE) EmployeeName, SKIPPED Mandatory,to_char(APPROVED_ON,'dd/mm/yyyy hh12:mi:ss AM') APPROVED_ON,REMARKS from SN_SANCTION_APPROVALS s where sanction_no= '" + lblSancNo.Text + "' and emp_code not like 'A%' and s_no<>0 order by S_NO";
        ocon = CommonFunc.con();
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvApproval.DataSource = ds;
            gvApproval.DataBind();
        }
        qry = " select  (select employee_name from hrm_employee where EMP_CODE= s.EMP_CODE) EmployeeName, to_char(APPROVED_ON,'dd/mm/yyyy hh12:mi:ss AM') dt from SN_SANCTION_APPROVALS s where sanction_no= '" + lblSancNo.Text + "' and role ='R' and emp_code not like 'A%' and APPROVED_ON is not null and SNSA_RECID in (select max(SNSA_RECID) from SN_SANCTION_APPROVALS  where sanction_no= s.sanction_no  and EMP_CODE= s.EMP_CODE) order by S_NO";
        ocon = CommonFunc.con();
        da = new OracleDataAdapter(qry, ocon);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvRevBy.DataSource = ds;
            gvRevBy.DataBind();
        }
        qry = " select (select employee_name from hrm_employee where EMP_CODE= s.EMP_CODE) EmployeeName, to_char(APPROVED_ON,'dd/mm/yyyy hh12:mi:ss AM') dt from SN_SANCTION_APPROVALS s where sanction_no= '" + lblSancNo.Text + "' and role ='A' and emp_code not like 'A%' and APPROVED_ON is not null and SNSA_RECID in (select max(SNSA_RECID) from SN_SANCTION_APPROVALS  where sanction_no= s.sanction_no  and EMP_CODE= s.EMP_CODE) order by S_NO";
        ocon = CommonFunc.con();
        da = new OracleDataAdapter(qry, ocon);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvAppBy.DataSource = ds;
            gvAppBy.DataBind();
        }
    }
    protected void getAttach()
    {
        qry = " select SUBSTR(FILE_NAME,INSTR(FILE_NAME, '_',1,2 )+1 ) FILE_NAME_disp, FILE_NAME from SN_SANCTION_ATTACHMENTS where SANCTION_NO = '" + lblSancNo.Text + "' ";
        ocon = CommonFunc.con();
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvAttachment.DataSource = ds;
            gvAttachment.DataBind();
        }
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        pnlApproval.Visible = true; getapp(); pnlAttachment.Visible = false;
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        pnlAttachment.Visible = true; getAttach(); pnlApproval.Visible = false;
    }
    protected void imgcloseA_Click(object sender, ImageClickEventArgs e)
    {
        pnlApproval.Visible = false;
    }
    protected void imgcloseA0_Click(object sender, ImageClickEventArgs e)
    {
        pnlAttachment.Visible = false;
    }
    protected void gvApproval_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        
    }
    protected void gvAttachment_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string path = e.CommandArgument.ToString();
        string fpath = Server.MapPath("~/SancDocs/") + e.CommandArgument.ToString(); // @"c:/abc/doc/abc1.doc";
        System.IO.FileInfo myDoc = new System.IO.FileInfo(fpath);

        Response.Clear();
        Response.ContentType = "Application/msword";
        Response.AddHeader("content-disposition", "attachment;filename=" + myDoc.Name);
        Response.AddHeader("Content-Length", myDoc.Length.ToString());
        Response.ContentType = "application/octet-stream";
        Response.WriteFile(myDoc.FullName);
        Response.End();
    }
    protected void btnReinitiate_Click(object sender, EventArgs e)
    {
       
        //if (txtRemark.Text != "")
        //{
            btnReinitiate.Enabled = false;            
            string toid = gettoMailId(); string toemp = gettoempcode(); 
                toid = getCreatedMailId();
            ocon = CommonFunc.con(); ocon.Open();
            OracleTransaction trns = ocon.BeginTransaction(); ; OracleCommand cmd; string qry = "";
            try
            {
                qry = "update  SN_SANCTIONS set current_status='1', VERSION_NO = VERSION_NO+1, status='E', LAST_UPD_BY='" + userid + "'  ,LAST_UPD_ON = to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + "', 'dd/mm/yyyy hh:mi:ss AM') where SNS_RECID='" + recid + "' ";
                
               if (ocon.State == ConnectionState.Closed)
                    ocon.Open();
                cmd = new OracleCommand(qry, ocon, trns);
                cmd.ExecuteNonQuery();

                qry = "update SN_SANCTION_APPROVALS set REMARKS = '" + Server.HtmlEncode(txtRemark.Text) + "',   APPROVED_BY='" + userid + "', APPROVED_ON =to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + "', 'dd/mm/yyyy hh:mi:ss AM') where  PARENT_RECID ='" + recid + "' and emp_code= '" + userid + "'  and APPROVED_BY is null";
                cmd = new OracleCommand(qry, ocon, trns);
                cmd.ExecuteNonQuery();

                //qry = "update GL_BUDGET_details set CONSUMED_AMOUNT = nvl(CONSUMED_AMOUNT,0) - " + lblamt.Text + " WHERE  ENTITY_CODE='" + lblEnt.Text + "' and   OU_CODE='" + lblOU_CODE1.Text + "' and SBU_CODE='" + lblsb.Text + "'  and SBU_CATEGORY_CODE='" + lblSBU_CATEGORY_CODE.Text + "'  and (BRAND_CODE is null or BRAND_CODE='" + lblBRAND_CODE.Text + "')  and (PRODUCT_ID is null or PRODUCT_ID= '" + lblPRODUCT_ID.Text + "')  ";
                //qry += "   and HRIS_DEPT_CODE= '" + lblDept.Text + "' and (PROJECT_CODE is null or PROJECT_CODE= '" + lblhrisFunc.Text + "') and FISCAL_YEAR= '" + lblFyear.Text + "' and EXPENSE_CODE_BUDGET= '" + lbl1.Text + "' and  BUDGET_REF_NO='" + lblBUDGET_REF_NO.Text + "' and FISCAL_PERIOD = CG$FIXED_ASSESTS_PKG.CG$GET_FISCAL_PERIOD('55', trunc(sysdate))";
                //cmd = new OracleCommand(qry, ocon, trns);
                //cmd.ExecuteNonQuery();


                string p = Server.MapPath("~/HtmlTemplate.htm");
                string flag = "";
                flag = CommonFunc.mailReint(toid, email, Session["name"].ToString(),recid,p, lblSancNo.Text);
                if (flag == "Y")
                {
                    qry = mailLog(flag, "", toemp, toid);
                    cmd = new OracleCommand(qry, ocon, trns);
                    cmd.ExecuteNonQuery();
                }
                else
                {
                    qry = mailLog("N", flag, toemp, toid);
                    cmd = new OracleCommand(qry, ocon, trns);
                    cmd.ExecuteNonQuery();
                }
                trns.Commit();
                ocon.Close();
                CommonFunc.ShowAlertMessage("Record Saved.", "ShowPendingSanctionList.aspx");
            }
            catch (Exception ex)
            {
                trns.Rollback();
                CommonFunc.ShowAlert("Error " + ex.Message);
                btnReinitiate.Enabled = true; //btnSubmit.Enabled = true;
            }
            //updateStatus(1);
        //}        
        //else {
        //    CommonFunc.ShowAlert("Kindly enter remark..");
        //}
    }
    protected void btncan_Click(object sender, EventArgs e)
    {
       
        //if (txtRemark.Text != "")
        //{
            btncan.Enabled = false;
            string toid = getcancleMailId(); string toemp = gettoempcode();
            ocon = CommonFunc.con(); ocon.Open();
            OracleTransaction trns = ocon.BeginTransaction(); ; OracleCommand cmd; string qry = "";
            try
            {
                qry = "update  SN_SANCTIONS set current_status='0' , status='R', LAST_UPD_BY='" + userid + "'  ,LAST_UPD_ON = to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + "', 'dd/mm/yyyy hh:mi:ss AM') where SNS_RECID='" + recid + "' ";
                // (SNS_RECID,ENTITY_CODE,SANCTION_NO,SANCTION_DATE,FISCAL_YEAR,SBU_CODE,DEPT_CODE,HRIS_DEPT_CODE,PROJECT,HRIS_FUNCTION_CODE,VERSION_NO,HIERARCHY_CODE,SANCTION_SOUGHT_FOR,TOTAL_AMOUNT,BACKGROUD_INFO,CRITICAL_ISSUES_DETAIL,STATUS,CREATED_BY,CREATED_ON) ";
                if (ocon.State == ConnectionState.Closed)
                    ocon.Open();
                cmd = new OracleCommand(qry, ocon, trns);
                cmd.ExecuteNonQuery();

                qry = "update SN_SANCTION_APPROVALS set REMARKS = '" + Server.HtmlEncode(txtRemark.Text) + "' ,  APPROVED_BY='" + userid + "', APPROVED_ON = to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + "', 'dd/mm/yyyy hh:mi:ss AM') where  PARENT_RECID ='" + recid + "' and EMP_CODE= '" + userid + "'  and APPROVED_BY is null";
                cmd = new OracleCommand(qry, ocon, trns);
                cmd.ExecuteNonQuery();

                string flag = CommonFunc.mailcancel(toid, email, Session["name"].ToString(),recid,"", lblSancNo.Text, txtRemark.Text);
                if (flag == "Y")
                    mailLog(flag, "",toemp,toid);
                else
                {
                    qry = mailLog("N", flag, toemp, toid);
                    cmd = new OracleCommand(qry, ocon, trns);
                    //cmd.ExecuteNonQuery();
                }
                trns.Commit();
                ocon.Close();
                CommonFunc.ShowAlertMessage("Record Saved.", "ShowPendingSanctionList.aspx");
            }
            catch (Exception ex)
            {
                trns.Rollback();
                CommonFunc.ShowAlert("Error " + ex.Message);
                btncan.Enabled = true;
            }
        //}
        //else {
        //    CommonFunc.ShowAlert("Kindly enter remark..");
        //    btncan.Enabled = true;
        //}
    }

    protected string mailLog(string flag, string message,string empcde, string toid)
    {
        qry="insert into SN_SANCTION_EMAIL_LOG (SNSEL_RECID,ENTITY_CODE,SANCTION_NO,PARENT_RECID,EMP_CODE,EMAIL_ID,EMAIL_SENT_ON,TO_EMP_CODE,TO_EMAIL_ID,DELIVERY_FLAG,MESSAGE) ";
        qry += " values (portal_RECID.nextval,'" + lblEnt.Text + "','" + lblSancNo.Text + "','" + recid + "','" + userid + "','" + email + "',to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + "', 'dd/mm/yyyy hh:mi:ss AM'),'" + empcde + "','" + toid + "','" + flag + "','" + message + "') ";
        return qry;
    }
    /*********************************************************/

    private void FillDropDownList(DropDownList ddl)
    {
        // ArrayList arr = GetDummyData();
        ds = CommonFunc.GetEmpList("");
        for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
        {
            ddl.Items.Add(new ListItem(ds.Tables[0].Rows[k]["employee_name"].ToString(), ds.Tables[0].Rows[k]["emp_code"].ToString()));
        }
    }

    private void SetInitialRow()
    {

        DataTable dt = new DataTable();
        DataRow dr = null;

        dt.Columns.Add(new DataColumn("RowNumber", typeof(string)));
        dt.Columns.Add(new DataColumn("Column1", typeof(string)));//for TextBox value 
        dt.Columns.Add(new DataColumn("Column2", typeof(string)));//for TextBox value 
        dt.Columns.Add(new DataColumn("Column3", typeof(string)));//for DropDownList selected item 
        dt.Columns.Add(new DataColumn("Column4", typeof(string)));//for DropDownList selected item 

        dr = dt.NewRow();
        dr["RowNumber"] = 1;
        dr["Column1"] = string.Empty;
        dr["Column2"] = string.Empty;
        dt.Rows.Add(dr);

        //Store the DataTable in ViewState for future reference 
        ViewState["CurrentTable"] = dt;

        //Bind the Gridview 
        Gridview1.DataSource = dt;
        Gridview1.DataBind();

        //After binding the gridview, we can then extract and fill the DropDownList with Data 
        DropDownList ddlEmp = (DropDownList)Gridview1.Rows[0].Cells[1].FindControl("ddlEmp");
        //DropDownList ddl2 = (DropDownList)Gridview1.Rows[0].Cells[4].FindControl("DropDownList2");
        FillDropDownList(ddlEmp);

    }

    private void AddNewRowToGrid()
    {

        if (ViewState["CurrentTable"] != null)
        {

            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
            DataRow drCurrentRow = null;

            if (dtCurrentTable.Rows.Count > 0)
            {
                drCurrentRow = dtCurrentTable.NewRow();
                drCurrentRow["RowNumber"] = dtCurrentTable.Rows.Count + 1;

                //add new row to DataTable 
                dtCurrentTable.Rows.Add(drCurrentRow);


                for (int i = 0; i < dtCurrentTable.Rows.Count - 1; i++)
                {

                    DropDownList ddlEmp = (DropDownList)Gridview1.Rows[i].Cells[3].FindControl("ddlEmp");
                    DropDownList ddlM = (DropDownList)Gridview1.Rows[i].Cells[4].FindControl("ddlM");
                    DropDownList ddlRole = (DropDownList)Gridview1.Rows[i].Cells[4].FindControl("ddlRole");

                    // Update the DataRow with the DDL Selected Items 

                    dtCurrentTable.Rows[i]["Column1"] = ddlEmp.SelectedItem.Text;
                    dtCurrentTable.Rows[i]["Column2"] = ddlM.SelectedItem.Text;
                    dtCurrentTable.Rows[i]["Column3"] = ddlRole.SelectedItem.Text;

                }

                //Store the current data to ViewState for future reference 
                ViewState["CurrentTable"] = dtCurrentTable;


                //Rebind the Grid with the current data to reflect changes 
                Gridview1.DataSource = dtCurrentTable;
                Gridview1.DataBind();
            }
        }
        else
        {
            Response.Write("ViewState is null");

        }
        //Set Previous Data on Postbacks 
        SetPreviousData();
    }

    private void SetPreviousData()
    {

        int rowIndex = 0;
        if (ViewState["CurrentTable"] != null)
        {

            DataTable dt = (DataTable)ViewState["CurrentTable"];
            if (dt.Rows.Count > 0)
            {

                for (int i = 0; i < dt.Rows.Count; i++)
                {

                    //TextBox box1 = (TextBox)Gridview1.Rows[i].Cells[1].FindControl("TextBox1");
                    //TextBox box2 = (TextBox)Gridview1.Rows[i].Cells[2].FindControl("TextBox2");

                    DropDownList ddlEmp = (DropDownList)Gridview1.Rows[i].Cells[3].FindControl("ddlEmp");
                    DropDownList ddlM = (DropDownList)Gridview1.Rows[i].Cells[4].FindControl("ddlM");
                    DropDownList ddlRole = (DropDownList)Gridview1.Rows[i].Cells[4].FindControl("ddlRole");

                    //Fill the DropDownList with Data 
                    FillDropDownList(ddlEmp);
                    //FillDropDownList(ddl2);

                    if (i < dt.Rows.Count)
                    {

                        //Assign the value from DataTable to the TextBox 
                        //box1.Text = dt.Rows[i]["Column1"].ToString();
                        //box2.Text = dt.Rows[i]["Column2"].ToString();

                        //Set the Previous Selected Items on Each DropDownList  on Postbacks 
                        if (dt.Rows[i]["Column1"].ToString() != "")
                        {
                            ddlEmp.ClearSelection();
                            ddlEmp.Items.FindByText(dt.Rows[i]["Column1"].ToString()).Selected = true;

                            ddlM.ClearSelection();
                            ddlM.Items.FindByText(dt.Rows[i]["Column2"].ToString()).Selected = true;

                            ddlRole.ClearSelection();
                            ddlRole.Items.FindByText(dt.Rows[i]["Column3"].ToString()).Selected = true;

                        }
                    }

                    rowIndex++;
                }
            }
        }
    }

    protected void btnEdit_click(object sender, EventArgs e)
    {
        SetInitialRow(); pnlEdit.Visible = true;
    }

    protected void ButtonAdd_Click(object sender, EventArgs e)
    {
        AddNewRowToGrid();
    }

    protected void Gridview1_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable"];
            LinkButton lb = (LinkButton)e.Row.FindControl("LinkButton1");
            if (lb != null)
            {
                if (dt.Rows.Count > 1)
                {
                    if (e.Row.RowIndex == dt.Rows.Count - 1)
                    {
                        lb.Visible = false;
                    }
                }
                else
                {
                    lb.Visible = false;
                }
            }
        }
    }

    protected void LinkDelete_Click(object sender, EventArgs e)
    {
        LinkButton lb = (LinkButton)sender;
        GridViewRow gvRow = (GridViewRow)lb.NamingContainer;
        int rowID = gvRow.RowIndex;
        DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
        //DataRow drCurrentRow = null;

        for (int i = 0; i < dtCurrentTable.Rows.Count; i++)
        {

            DropDownList ddlEmp = (DropDownList)Gridview1.Rows[i].Cells[3].FindControl("ddlEmp");
            DropDownList ddlM = (DropDownList)Gridview1.Rows[i].Cells[4].FindControl("ddlM");
            DropDownList ddlRole = (DropDownList)Gridview1.Rows[i].Cells[4].FindControl("ddlRole");

            // Update the DataRow with the DDL Selected Items 

            dtCurrentTable.Rows[i]["Column1"] = ddlEmp.SelectedItem.Text;
            dtCurrentTable.Rows[i]["Column2"] = ddlM.SelectedItem.Text;
            dtCurrentTable.Rows[i]["Column3"] = ddlRole.SelectedItem.Text;

        }

        //Store the current data to ViewState for future reference 
        ViewState["CurrentTable"] = dtCurrentTable;


        if (ViewState["CurrentTable"] != null)
        {

            DataTable dt = (DataTable)ViewState["CurrentTable"];
            if (dt.Rows.Count > 1)
            {
                if (gvRow.RowIndex <= dt.Rows.Count - 1)
                {
                    //Remove the Selected Row data and reset row number
                    dt.Rows.Remove(dt.Rows[rowID]);
                    ResetRowID(dt);
                }
            }

            //Store the current data in ViewState for future reference
            ViewState["CurrentTable"] = dt;

            //Re bind the GridView for the updated data
            Gridview1.DataSource = dt;
            Gridview1.DataBind();
        }

        //Set Previous Data on Postbacks
        SetPreviousData();
    }

    private void ResetRowID(DataTable dt)
    {
        int rowNumber = 1;
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow row in dt.Rows)
            {
                row[0] = rowNumber;
                rowNumber++;
            }
        }
    }
    protected void btnSave0_Click(object sender, EventArgs e)
    {
        try
        {
           
                if (flupd1.HasFile)
                {
                    ocon = CommonFunc.con();
                    lblFileSanc.Text = lblrecid.Text + "_" + userid + "_" + System.IO.Path.GetFileName(flupd1.FileName);
                    string uploadPath = Server.MapPath(string.Format("~/SancDocs/{0}", lblFileSanc.Text));
                    if (!System.IO.File.Exists(uploadPath))
                    {
                        flupd1.SaveAs(Server.MapPath("~/SancDocs/") + lblFileSanc.Text);
                        string qry = "insert into SN_SANCTION_ATTACHMENTS (SNSAT_RECID,ENTITY_CODE,SANCTION_NO,PARENT_RECID,FILE_NAME,FILE_PATH,CREATED_BY,CREATED_ON) ";
                        qry += "values (portal_RECID.nextval,'" + lblEnt.Text + "','" + lblSancNo.Text + "','" + lblrecid.Text + "','" + lblFileSanc.Text + "','','" + userid + "',to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + "', 'dd/mm/yyyy hh:mi:ss AM'))";
                        ocon.Open();
                        OracleCommand cmd = new OracleCommand(qry, ocon);
                        cmd.ExecuteNonQuery();
                        getAttach();
                        CommonFunc.ShowAlert("File Uplodaed");
                        //qry = "select SNSAT_RECID,FILE_NAME from SN_SANCTION_ATTACHMENTS where PARENT_RECID= '" + lblrecid.Text + "'";
                        //da = new OracleDataAdapter(qry, ocon);
                        //ds = new DataSet();
                        //da.Fill(ds);
                        //gvAttachment.DataSource = ds;
                        //gvAttachment.DataBind();
                    }
                    else
                    {
                        CommonFunc.ShowAlert("File already exists.");
                    }
                }
                else
                {
                    CommonFunc.ShowAlert("Choose a File");
                }
            
            
        }
        catch (Exception ex)
        {
            CommonFunc.ShowAlert("Error: " + ex.Message);
        }
        finally { ocon.Close(); }
    }
    /********************************************************/
    protected void btnSaveApp_Click(object sender, EventArgs e)
    {
        
        ocon = CommonFunc.con(); ocon.Open(); OracleTransaction trns = ocon.BeginTransaction(); ; OracleCommand cmd; string qry = "";
        try
        {
            int st = Convert.ToInt32(lblstatus.Text); int no_row = Gridview1.Rows.Count;
            qry = "update SN_SANCTION_APPROVALS set s_no  = s_no+" + no_row + " where parent_recid = '" + recid + "'  and s_no>= " + st + "";
            cmd = new OracleCommand(qry, ocon, trns);
            cmd.ExecuteNonQuery();
            for (int i = 0; i < Gridview1.Rows.Count; i++)
            {
                string srn0 = (st + i).ToString();//(string)Gridview1.Rows[i].Cells[0].Text.ToString(); ;
                DropDownList ddlEmp = (DropDownList)Gridview1.Rows[i].FindControl("ddlEmp");
                DropDownList ddlM = (DropDownList)Gridview1.Rows[i].FindControl("ddlM");
                DropDownList ddlRole = (DropDownList)Gridview1.Rows[i].FindControl("ddlRole");
                qry = "insert into   SN_SANCTION_APPROVALS (SNSA_RECID,ENTITY_CODE,SANCTION_NO,PARENT_RECID,HIERARCHY_CODE,S_NO,EMP_CODE,SKIPPED,ROLE,ADDED_BY) ";
                qry += " values (portal_RECID.nextval,'" + lblEnt.Text + "','" + lblSancNo.Text + "','" + recid + "','" + lblHcode.Text + "','" + srn0 + "','" + ddlEmp.SelectedValue + "','" + ddlM.SelectedValue + "','" + ddlRole.SelectedValue + "','" + userid + "')";

                cmd = new OracleCommand(qry, ocon, trns);
                cmd.ExecuteNonQuery();
            }
            trns.Commit();
            CommonFunc.ShowAlertMessage("Changes saved.", "ShowPendingSanctionList.aspx");
        }
        catch (Exception ex)
        {
            trns.Rollback();
            CommonFunc.ShowAlert("Error : " + ex.Message);
        }
        finally { ocon.Close(); }
    }

    protected double getTotalAmount()
    {
        double total = 0;
        for(int i=0; i<gvDetail.Rows.Count ;i++)
        {
            TextBox lblamt = (TextBox)gvDetail.Rows[i].FindControl("lblamt");
            total = total + Convert.ToDouble(lblamt.Text);
        }
        return total;
    }

    protected void gvDetail_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if(e.CommandName == "Del")
        {
            string id = e.CommandArgument.ToString();
            ImageButton lstunit = (ImageButton)e.CommandSource;
            GridViewRow row = (GridViewRow)lstunit.NamingContainer;
            TextBox lblaamt = (TextBox)row.FindControl("lblamt");
            if (id != "")
            {
                ocon = CommonFunc.con();
                ocon.Open(); OracleTransaction trns = ocon.BeginTransaction();
                try
                {
                    qry = " update SN_SANCTIONS_DETAILS set status='I'   where  SNSD_RECID= '"+id+"'  and  SANCTION_NO='"+lblSancNo.Text+"'";

                    OracleCommand cmd = new OracleCommand(qry, ocon, trns);
                    cmd.ExecuteNonQuery();

                    
                    for (int i = 0; i < gvDetail.Rows.Count; i++)
                    {
                        TextBox lblamt = (TextBox)gvDetail.Rows[i].FindControl("lblamt");
                        Label lblsid = (Label)gvDetail.Rows[i].FindControl("lblsid");
                        qry = " update SN_SANCTIONS_DETAILS set SANCTION_AMOUNT='" + lblamt.Text + "', LAST_UPD_BY='" + userid + "'  ,LAST_UPD_ON = to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + "', 'dd/mm/yyyy hh:mi:ss AM')   where  SNSD_RECID= '" + lblsid.Text + "'  and  SANCTION_NO='" + lblSancNo.Text + "'";

                        cmd = new OracleCommand(qry, ocon, trns);
                        cmd.ExecuteNonQuery();
                    }
                    trns.Commit();
                    getDetailData();
                    double total_amt = getTotalAmount();
                    qry = " update SN_SANCTIONS set TOTAL_AMOUNT=  " + total_amt + "   where  SNS_RECID= '" + recid + "'  and  SANCTION_NO='" + lblSancNo.Text + "'";
                    if(ocon.State == ConnectionState.Closed)
                    {
                        ocon.Open();
                    }
                    cmd = new OracleCommand(qry, ocon);
                    cmd.ExecuteNonQuery();

                    Server.Transfer("SanctionDetails.aspx?sid=" + recid);
                   
                }
                catch (Exception ex)
                { trns.Rollback(); }
                finally { ocon.Close(); }
            }
        }
    }

    protected void TextChangedEvent(object sender, EventArgs e)
    {
        try
        {
            TextBox lb = (TextBox)sender;
            decimal total = 0;
            GridView Gridview1 = (GridView)(sender as TextBox).Parent.Parent.Parent.Parent;
            //DataTable dt = (DataTable)ViewState["CurrentTable"];
            for (int i = 0; i < Gridview1.Rows.Count; i++)
            {
                TextBox lblamt = (TextBox)Gridview1.Rows[i].FindControl("lblamt");
                if (lblamt.Text != "")
                    total += Convert.ToDecimal(lblamt.Text);
            }

            Label lblTotal = (Label)Gridview1.FooterRow.FindControl("lblTotal");
            lblTotal.Text = total.ToString();
        }
        catch (Exception ex)
        {
            CommonFunc.ShowAlert("Some error found. err msg :" + ex.Message);
        }
    }
}