﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.OracleClient;
using System.Web.UI;
using System.Net;
using System.Net.Mail;
using System.Configuration;

namespace CustomClass
{
    /// <summary>
    /// Summary description for CommonFunc
    /// </summary>
    public class CustomFunc : System.Web.UI.Page
    {
        public static string conn = "";
        public static OracleConnection ocon;
        public static DataSet ds; public static OracleDataAdapter da;
        public static string q = "";
        public static string userid = "", password = "";
        /*public CommonFunc()
        {
            //
            // TODO: Add constructor logic here
            //
        }*/
       public static OracleConnection CreateConnection(string uid, string pwd)
        {
            userid = uid;
            password = pwd;
            conn = "Data Source = Dev; User Id = " + uid + "; Password = " + pwd + "; ;Integrated Security=no;";
            conn = "Data Source = Dev; User Id = imis; Password = hodport; ;Integrated Security=no;";
            //ocon = new OracleConnection();
            ocon.ConnectionString = conn;
            return ocon;
        }
        public static OracleConnection con()
        {
            ocon = new OracleConnection();
            conn = "Data Source = Dev; User Id ='skatiyar'; Password = 'dsg!2011'; Integrated Security=no;";
            //conn = "Data Source = testdms; User Id = imis; Password = hodport; ;Integrated Security=no;";
            //ocon = new OracleConnection();
            ocon.ConnectionString = conn;
            return ocon;
        }

        public static void opencon()
        {
            if (ocon.State != ConnectionState.Open)
                ocon.Open();
        }
        public static void closecon()
        {
            if (ocon.State != ConnectionState.Closed)
                ocon.Close();
        }

        public static DataSet GetCustomEntity()
        {
            ocon = con();
            string qry = "SELECT ENTITY_CODE,LEGAL_NAME FROM OC_ENTITY B WHERE status='A' and ENTITY_CODE in (select distinct ENTITY_CODE  from 	SN_USER_RIGHTS where emp_code ='" + userid + "' and status= 'A') order by LEGAL_NAME";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//
        }
        public static DataSet GetCustomOUCode(string ecode)
        {
            ocon = con();
            string qry = "select OU_CODE, DESCRIPTION from OC_OPERATING_UNIT where ENTITY_CODE ='" + ecode + "' and OU_CODE in (select distinct OU_CODE  from 	SN_USER_RIGHTS where emp_code ='" + userid + "' and status= 'A') and status='A' order by OU_CODE,DESCRIPTION";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//

        }
        public static DataSet GetBrandCode()
        {
            ocon = con();
            string qry = "SELECT A.SBU_CODE, B.SBU_CATEGORY_CODE,  C.BRAND_CODE, C.DESCRIPTION FROM OC_SBU A,  OC_SBU_CATEGORY B , OC_PRODUCTS  C   WHERE A.SBU_CODE= B.SBU_CODE AND B.SBU_CATEGORY_CODE = C.SBU_CATEGORY_CODE AND A.STATUS = 'A' AND B.STATUS = 'A' AND C.STATUS = 'A' order by DESCRIPTION";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//

        }
        public static DataSet GetExpCode(string deptcode)
        {
            ocon = con();
            string qry = "select EXPENSE_CODE_BUDGET,head_description from OC_EXPENSE_MASTER where status='A' and record_type='I' and dept_code='" + deptcode + "' order by head_description";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//SELECT A.PROJECT,  B.FUNC_DESC || ' - ' || B.FUNC_CODE , C.DEPT_CODE   FROM PROJECTS A, HRM_FUNCTION B, HRM_MAPPING_DEPT_FUNCTIONS C WHERE A.COMPANY = 'DS' AND A.HRIS_FUNCTION_CODE = B.FUNC_CODE AND A.STATUS  =  'A' AND A.HRIS_FUNCTION_CODE = C.FUNC_CODE 

        }

        public static DataSet GetFunc(string deptcode)
        {
            ocon = con();
            string qry = "SELECT A.PROJECT,  B.FUNC_DESC || ' - ' || B.FUNC_CODE code, C.DEPT_CODE   FROM PROJECTS A, HRM_FUNCTION B, HRM_MAPPING_DEPT_FUNCTIONS C WHERE A.COMPANY = 'DS' AND A.HRIS_FUNCTION_CODE = B.FUNC_CODE AND A.STATUS  =  'A' AND A.HRIS_FUNCTION_CODE = C.FUNC_CODE  and C.DEPT_CODE= '" + deptcode + "' order by PROJECT";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//SELECT BUDGET_REF_NO FROM GL_BUDGETS     WHERE ENTITY_CODE= '55' AND FISCAL_YEAR='2018'

        }
        public static DataSet GetbudRefNo(string encode,string oucode, string  sbucode, string sbucatcode, string brandcode, string prodid,string deptcode, string projcode,string expcode ,string fyear)
        {
            ocon = con();
            string qry = "SELECT BUDGET_REF_NO FROM GL_BUDGETS     WHERE ENTITY_CODE= '" + encode + "' AND FISCAL_YEAR='" + fyear + "'";

            qry = "select  BUDGET_REF_NO,SUM(nvl(BUDGET_AMOUNT,0)) BUDGET_AMOUNT, SUM(nvl(CONSUMED_AMOUNT,0)) CONSUMED_AMOUNT  from GL_BUDGET_details where ENTITY_CODE='" + encode + "' and   OU_CODE='" + oucode + "' and SBU_CODE='" + sbucode + "'  and SBU_CATEGORY_CODE='" + sbucatcode + "'  and BRAND_CODE='" + brandcode + "'  and PRODUCT_ID= '" + prodid + "'  ";
            qry += "   and DEPT_CODE= '" + deptcode + "' and PROJECT_CODE= '" + projcode + "' and FISCAL_YEAR= '" + fyear + "' and EXPENSE_CODE_BUDGET= '" + expcode + "'  GROUP BY BUDGET_REF_NO";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;

        }
        public static DataSet GetCustomSBU(string encode)
        {
           
            ocon = con();
            string qry = "select SBU_CODE,DESCRIPTION from OC_SBU A  where status='A'  AND EXISTS (SELECT 1 FROM OC_SBU_MAPPING B   WHERE  B.ENTITY_CODE = '" + encode + "'   AND  B.SBU_CODE = A.SBU_CODE )  and SBU_CODE  in (SELECT DISTINCT SBU_CODE  FROM 	SN_USER_RIGHTS WHERE EMP_CODE ='" + userid + "' AND STATUS= 'A') order by SBU_CODE,DESCRIPTION";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//
        }
               
        public static DataSet GetCustomUNIT(string en, string sbucode)
        {
            ocon = con();
            string qry = "SELECT distinct OU_CODE,DESCRIPTION FROM  OC_OPERATING_UNIT WHERE ENTITY_CODE = '"+ en+"'";
            qry = "SELECT OU_CODE, DESCRIPTION FROM OC_OPERATING_UNIT A WHERE ENTITY_CODE ='" + en + "' AND STATUS='A'AND EXISTS (SELECT '1' FROM OC_SBU_MAPPING D WHERE D.SBU_CODE = '" + sbucode + "' AND D.OU_CODE = A.OU_CODE  AND OU_CODE in (select distinct OU_CODE  from 	SN_USER_RIGHTS where emp_code ='" + userid + "' and status= 'A')	AND D.STATUS = 'A')";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//
        }

        public static DataSet GetCustomCategory(string sbucode, string oucode, string encode)
        {
            ocon = con();
            string qry = "SELECT B.SBU_CATEGORY_CODE, B.DESCRIPTION FROM  OC_SBU_CATEGORY B WHERE B.SBU_CODE= '" + sbucode + "' AND B.STATUS = 'A' AND EXISTS (SELECT 1 FROM OC_SBU_MAPPING D WHERE D.SBU_CODE = B.SBU_CODE and D.SBU_CATEGORY_CODE = B.SBU_CATEGORY_CODE   AND D.OU_CODE =  '" + oucode + "' and d.entity_code ='" + encode + "')  And SBU_CATEGORY_CODE in (SELECT DISTINCT SBU_CATEGORY_CODE  FROM 	SN_USER_RIGHTS WHERE EMP_CODE ='5500169' AND STATUS= 'A')";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//
        }
        
        public static DataSet GetBrand(string sbucode, string sbucatcode, string oucode, string encode)
        {
            ocon = con();
            string qry = "SELECT  A.DESCRIPTION, B.SBU_CATEGORY_CODE, B.DESCRIPTION, C.BRAND_CODE, C.DESCRIPTION desc1 FROM OC_SBU A,  OC_SBU_CATEGORY B , OC_BRANDS  C WHERE A.SBU_CODE= B.SBU_CODE AND B.SBU_CATEGORY_CODE = C.SBU_CATEGORY_CODE AND A.STATUS = 'A' AND B.STATUS = 'A' AND C.STATUS = 'A' and A.SBU_CODE ='"+sbucode+"' and B.SBU_CATEGORY_CODE ='"+ sbucatcode+"' ";
            qry = "SELECT  C.BRAND_CODE, C.DESCRIPTION FROM  OC_BRANDS  C WHERE C.SBU_CATEGORY_CODE =  '" + sbucatcode + "' AND C.STATUS = 'A' AND EXISTS (SELECT '1' FROM OC_SBU_MAPPING D WHERE D.OU_CODE = '"+oucode+"' AND D.SBU_CATEGORY_CODE = '" + sbucatcode + "' AND D.BRAND_CODE = C.BRAND_CODE AND D.STATUS = 'A')";
            qry= "SELECT  C.BRAND_CODE, C.DESCRIPTION FROM  OC_BRANDS  C WHERE C.SBU_CODE = '" + sbucode + "' AND C.SBU_CATEGORY_CODE =  '" + sbucatcode + "' AND C.STATUS = 'A' ";
            qry += " AND EXISTS (SELECT '1' FROM OC_SBU_MAPPING D WHERE D.ENTITY_CODE = '" +encode + "'   AND D.OU_CODE = '"+oucode+"'   AND D.SBU_CODE = '" + sbucode + "'  AND D.SBU_CATEGORY_CODE = '" + sbucatcode + "'  AND D.SBU_CODE  =C.SBU_CODE   AND  D.SBU_CATEGORY_CODE = C.SBU_CATEGORY_CODE    AND D.BRAND_CODE = C.BRAND_CODE  AND D.STATUS = 'A')";
            
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//
        }

        public static DataSet Getproduct(string brandcode, string sbucatcode, string oucode, string sbucode, string encode)
        {
            ocon = con();
            string qry = "SELECT C.PRODUCT_ID, C.DESCRIPTION  FROM  OC_PRODUCTS C, OC_SBU_MAPPING D WHERE  C.BRAND_CODE =  '" + brandcode + "' AND D.SBU_CATEGORY_CODE =  '" + sbucatcode + "' AND C.STATUS = 'A' AND C.BRAND_CODE = D.BRAND_CODE  ";

            //qry = "SELECT C.PRODUCT_ID, C.DESCRIPTION FROM  OC_PRODUCTS C WHERE  C.BRAND_CODE = '" + brandcode + "' AND EXISTS (SELECT '1' FROM  OC_SBU_MAPPING D   WHERE D.OU_CODE = '" + oucode + "'     AND D.SBU_CATEGORY_CODE = '" + sbucatcode + "'    AND D.BRAND_CODE = '" + brandcode + "'  AND D.BRAND_CODE = C.BRAND_CODE   AND D.PRODUCT_ID = C.PRODUCT_ID  )";
            qry = "SELECT C.PRODUCT_ID, C.DESCRIPTION FROM  OC_PRODUCTS C WHERE C.SBU_CODE = '" + sbucode + "' AND C.SBU_CATEGORY_CODE =  '" + sbucatcode + "' AND C.BRAND_CODE = '" + brandcode + "' AND EXISTS (SELECT '1' FROM  OC_SBU_MAPPING D   WHERE D.ENTITY_CODE = '" + encode + "'   AND D.OU_CODE = '" + oucode + "'  AND  C.SBU_CODE = '" + sbucode + "' AND D.SBU_CATEGORY_CODE = '" + sbucatcode + "'   AND D.BRAND_CODE = '" + brandcode + "'  AND D.SBU_CODE  =C.SBU_CODE  AND D.SBU_CATEGORY_CODE = C.SBU_CATEGORY_CODE  AND D.BRAND_CODE = C.BRAND_CODE   AND D.PRODUCT_ID = C.PRODUCT_ID  )";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//
        }
              

       public static SmtpClient sclient11()
       {
           System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient();
           client.UseDefaultCredentials = true;
           client.DeliveryMethod = SmtpDeliveryMethod.Network;
           client.EnableSsl = false;

           client.Host = "email.dsgroup.com";
           client.Port = 25;

           NetworkCredential cred = new NetworkCredential("intranet.admin@dsgroup.com", "admin");
           client.Credentials = cred;
           return client;
       }


       private static string createEmailBody11(string userName, string title, string message, string path, string url)
       {

           string body = string.Empty;
           //using streamreader for reading my htmltemplate   

           using (System.IO.StreamReader reader = new System.IO.StreamReader(path))
           {

               body = reader.ReadToEnd();

           }

           body = body.Replace("{UserName}", ""); //replacing the required things  

           body = body.Replace("{Title}", title);

           body = body.Replace("{message}", message);
           body = body.Replace("{Url}", url);
           return body;

       }

       private static void SendHtmlFormattedEmail11(string subject, string body, string to, string from, string cc)
       {

           using (MailMessage mailMessage = new MailMessage())
           {
               //to = ".singh@dsgroup.com";
               mailMessage.From = new MailAddress(from);

               mailMessage.Subject = subject;

               mailMessage.Body = body;

               mailMessage.IsBodyHtml = true;

               mailMessage.To.Add(new MailAddress(to));//txt_email.Text

               //SmtpClient smtp = new SmtpClient();

               //smtp.Host = ConfigurationManager.AppSettings["Host"];

               //smtp.EnableSsl = Convert.ToBoolean(ConfigurationManager.AppSettings["EnableSsl"]);

               //System.Net.NetworkCredential NetworkCred = new System.Net.NetworkCredential();

               //NetworkCred.UserName = ConfigurationManager.AppSettings["UserName"]; //reading from web.config  

               //NetworkCred.Password = ConfigurationManager.AppSettings["Password"]; //reading from web.config  

               //smtp.UseDefaultCredentials = true;

               //smtp.Credentials = NetworkCred;

               //smtp.Port = int.Parse(ConfigurationManager.AppSettings["Port"]); //reading from web.config  
               System.Net.Mail.SmtpClient client = sclient11();
               client.Send(mailMessage);

           }

       }  


      

       public static string mailpproveAlert11(string to, string from, string name, string sid)
       {
           try
           {
               to = "shikha.katiyar@dsgroup.com";
               System.Net.Mail.SmtpClient client = sclient11();
               MailMessage msg = new MailMessage(from, to);
               msg.CC.Add(from);
               msg.Subject = " Sanction final Approved Alert ";// +name;
               msg.IsBodyHtml = true;
               string htmlBody;
               //htmlBody = "Request Has been approved.<br/><br/><br/>";

               htmlBody = "Click on Following Link To See the Details  :<br/><br/>";
               htmlBody += "http://10.1.25.33/ASPAsale/Detail.aspx?sno=" + sid;

               msg.Body = htmlBody;
               client.Send(msg);
               return "Y";
           }
           catch (Exception ex)
           {
               return "N";
           }
       }

      
        
    }
}