﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.OracleClient;
using System.Web.UI;
using System.Net;
using System.Net.Mail;
using System.Configuration;

namespace MyClass
{
    /// <summary>
    /// Summary description for CommonFunc
    /// </summary>
    public class CommonFunc : System.Web.UI.Page
    {
        public static string conn = "";
        public static OracleConnection ocon;
        public static DataSet ds; public static OracleDataAdapter da;
        public static string q = "";
        public static string userid = "", password = "";
        /*public CommonFunc()
        {
            //
            // TODO: Add constructor logic here
            //
        }*/
        public static OracleConnection CreateConnection(string uid, string pwd)
        {
            userid = uid;
            password = pwd;
            ocon = new OracleConnection();
            conn = "Data Source = dsg; User Id = " + uid + "; Password = " + pwd + ";Integrated Security=no;";
            //conn = "Data Source = Dev; User Id = imis; Password = hodport; ;Integrated Security=no;";
            //ocon = new OracleConnection();
            ocon.ConnectionString = conn;
            return ocon;
        }
        public static OracleConnection con()
        {
            ocon = new OracleConnection();
            conn = "Data Source = dsg; User Id = userportal; Password = portds2; ;Integrated Security=no;";
            //conn = "Data Source = testdms; User Id = imis; Password = hodport; ;Integrated Security=no;";
            //ocon = new OracleConnection();
            ocon.ConnectionString = conn;
            return ocon;
        }
        

        public static void opencon()
        {
            if (ocon.State != ConnectionState.Open)
                ocon.Open();
        }
        public static void closecon()
        {
            if (ocon.State != ConnectionState.Closed)
                ocon.Close();
        }

        public static DataSet GetEmpList(string dept_code)
        {
            string qry  ="";
            ocon = con();
            if(dept_code !="")
             qry = "select emp_code,employee_name   from hrm_employee where status in ('C','P','N') and EMAIL_ID is not null and IMIS_LOGIN_ID is not null and dept_code ='" + dept_code + "' order by employee_name ";
            else
                qry = "select emp_code,employee_name || '-' ||emp_code employee_name   from hrm_employee where status in ('C','P','N') and EMAIL_ID is not null and IMIS_LOGIN_ID is not null  order by employee_name ";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;
        }

        public static DataSet GetDept()
        {
            ocon = con();
            string qry = "SELECT  DEPT_CODE DEPARTMENT_CODE, DESCRIPTION FROM HRM_DEPARTMENT B WHERE B.STATUS = 'A' AND EXISTS (SELECT 1 FROM HRM_MAPPING_DEPT_FUNCTIONS A WHERE A.DEPT_CODE = B.DEPT_CODE) order by DESCRIPTION ";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//OC_ENTITY
        }
        public static DataSet GetDeptbyEmp(string empcode)
        {
            ocon = con();
            string qry = "SELECT  DEPT_CODE DEPARTMENT_CODE, DESCRIPTION FROM HRM_DEPARTMENT B WHERE B.STATUS = 'A' AND EXISTS (SELECT 1 FROM HRM_MAPPING_DEPT_FUNCTIONS A WHERE A.DEPT_CODE = B.DEPT_CODE) ";
            qry += " and DEPT_CODE in(select DEPT_CODE from SN_HIERARCHY where SNH_RECID in (select PARENT_RECID from SN_HIERARCHY_DETAIL where emp_code= '" + empcode + "' and status='A')) order by DESCRIPTION ";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//OC_ENTITY
        }

        public static DataSet GetEntity()
        {
            ocon = con();
            string qry = "SELECT ENTITY_CODE,ENTITY_CODE ||'- ' || LEGAL_NAME LEGAL_NAME FROM OC_ENTITY B WHERE status='A' order by LEGAL_NAME";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//
        }

        public static DataSet GetEntity1(string empcode)
        {
            ocon = con();
            string qry = "SELECT ENTITY_CODE,ENTITY_CODE ||'- ' || LEGAL_NAME LEGAL_NAME FROM OC_ENTITY B WHERE status='A' and ENTITY_CODE in (select ENTITY_CODE from SN_HIERARCHY where SNH_RECID in (select PARENT_RECID from SN_HIERARCHY_DETAIL where emp_code= '" + empcode + "' and status='A')) order by LEGAL_NAME";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//
        }


        public static DataSet GetOUCode(string ecode)
        {
            ocon = con();
            string qry = "select OU_CODE, OU_CODE || '- ' ||DESCRIPTION DESCRIPTION from OC_OPERATING_UNIT where ENTITY_CODE ='" + ecode + "' and status='A' order by DESCRIPTION";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//

        }
        public static DataSet GetBrandCode()
        {
            ocon = con();
            string qry = "SELECT A.SBU_CODE, B.SBU_CATEGORY_CODE,  C.BRAND_CODE, C.BRAND_CODE || '- ' || C.DESCRIPTION FROM OC_SBU A,  OC_SBU_CATEGORY B , OC_PRODUCTS  C   WHERE A.SBU_CODE= B.SBU_CODE AND B.SBU_CATEGORY_CODE = C.SBU_CATEGORY_CODE AND A.STATUS = 'A' AND B.STATUS = 'A' AND C.STATUS = 'A' order by DESCRIPTION";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//

        }
        public static DataSet GetExpCode(string deptcode,string fyear)
        {
            ocon = con();
            string qry = "select EXPENSE_CODE_BUDGET, EXPENSE_CODE_BUDGET || ' - ' ||head_description head_description from OC_EXPENSE_MASTER where status='A' and record_type='I' and HRIS_DEPT_CODE='" + deptcode + "' order by head_description";

            qry="select EXPENSE_CODE_BUDGET, EXPENSE_CODE_BUDGET || ' - ' ||head_description head_description from OC_EXPENSE_MASTER a, fiscal_years f ";
            qry+=" where a.status='A' and a.record_type='I' and a.HRIS_DEPT_CODE='"+deptcode+"' ";
            qry += " and ( (f.fiscal_year_start >= a.VALID_FROM or VALID_FROM is null  ) and(f.fiscal_year_end <= a.VALID_TO  or VALID_TO is null) ) ";
            //qry+=" and f.fiscal_year_end = a.VALID_TO ";
            qry += " and f.fiscal_year= '" + fyear + "' and f.company ='55' order by head_description "; //and  (sbu_code= 'DMP' or sbu_code is null)


            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//SELECT A.PROJECT,  B.FUNC_DESC || ' - ' || B.FUNC_CODE , C.DEPT_CODE   FROM PROJECTS A, HRM_FUNCTION B, HRM_MAPPING_DEPT_FUNCTIONS C WHERE A.COMPANY = 'DS' AND A.HRIS_FUNCTION_CODE = B.FUNC_CODE AND A.STATUS  =  'A' AND A.HRIS_FUNCTION_CODE = C.FUNC_CODE 

        }

        public static DataSet GetExpCodeSbu(string deptcode, string fyear,string sbucode)
        {
            ocon = con();
            string qry = "select EXPENSE_CODE_BUDGET, EXPENSE_CODE_BUDGET || ' - ' ||head_description head_description from OC_EXPENSE_MASTER where status='A' and record_type='I' and HRIS_DEPT_CODE='" + deptcode + "' order by head_description";

            qry = "select EXPENSE_CODE_BUDGET, EXPENSE_CODE_BUDGET || ' - ' ||head_description head_description from OC_EXPENSE_MASTER a, fiscal_years f ";
            qry += " where a.status='A' and a.record_type='I' and a.HRIS_DEPT_CODE='" + deptcode + "' and  (sbu_code= '" + sbucode + "' or sbu_code is null) ";
            qry += " and ( (f.fiscal_year_start >= a.VALID_FROM or VALID_FROM is null  ) and(f.fiscal_year_end <= a.VALID_TO  or VALID_TO is null) ) ";
            //qry+=" and f.fiscal_year_end = a.VALID_TO ";
            qry += " and f.fiscal_year= '" + fyear + "' and f.company ='55' order by head_description "; //and  (sbu_code= 'DMP' or sbu_code is null)


            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//SELECT A.PROJECT,  B.FUNC_DESC || ' - ' || B.FUNC_CODE , C.DEPT_CODE   FROM PROJECTS A, HRM_FUNCTION B, HRM_MAPPING_DEPT_FUNCTIONS C WHERE A.COMPANY = 'DS' AND A.HRIS_FUNCTION_CODE = B.FUNC_CODE AND A.STATUS  =  'A' AND A.HRIS_FUNCTION_CODE = C.FUNC_CODE 

        }

        public static string ROIFlag(string expcode)
        {
            string flag = "N";
            string qry = "  select nvl(CAPITAL_EXPENSE_FLAG,'N') from oc_expense_master where EXPENSE_CODE_BUDGET  = '" + expcode + "'";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                flag = ds.Tables[0].Rows[0][0].ToString();
            }
            return flag;
        }

        public static DataSet GetFunc(string deptcode)
        {
            ocon = con();
            string qry = "SELECT A.PROJECT,  B.FUNC_DESC || ' - ' || B.FUNC_CODE code, C.DEPT_CODE   FROM PROJECTS A, HRM_FUNCTION B, HRM_MAPPING_DEPT_FUNCTIONS C WHERE A.COMPANY = 'DS' AND A.HRIS_FUNCTION_CODE = B.FUNC_CODE AND A.STATUS  =  'A' AND A.HRIS_FUNCTION_CODE = C.FUNC_CODE  and C.DEPT_CODE= '" + deptcode + "' order by PROJECT";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//SELECT BUDGET_REF_NO FROM GL_BUDGETS     WHERE ENTITY_CODE= '55' AND FISCAL_YEAR='2018'

        }
        public static DataSet GetbudRefNo(string encode, string oucode, string sbucode, string sbucatcode, string brandcode, string prodid, string deptcode, string projcode, string expcode, string fyear, string userid)
        {
            ocon = con();
            string qry = "SELECT BUDGET_REF_NO FROM GL_BUDGETS     WHERE ENTITY_CODE= '" + encode + "' AND FISCAL_YEAR='" + fyear + "'";

            qry = "select  BUDGET_REF_NO ,emp_code,SUM(nvl(BUDGET_AMOUNT,0)) BUDGET_AMOUNT, SUM(nvl(CONSUMED_AMOUNT,0)) CONSUMED_AMOUNT  from GL_BUDGET_details where ENTITY_CODE='" + encode + "' AND (OU_CODE = '" + oucode + "' OR  OU_CODE = (SELECT HO_CODE FROM OC_OPERATING_UNIT WHERE OU_CODE = '" + oucode + "') ) and SBU_CODE='" + sbucode + "'  and SBU_CATEGORY_CODE='" + sbucatcode + "'  AND ( BRAND_CODE IS NULL or BRAND_CODE='" + brandcode + "')   AND( PRODUCT_ID IS NULL OR PRODUCT_ID= '" + prodid + "')  ";
            qry += " and DEPT_CODE= '" + deptcode + "' AND( PROJECT_CODE IS NULL OR PROJECT_CODE= '" + projcode + "') and FISCAL_YEAR= '" + fyear + "' and EXPENSE_CODE_BUDGET= '" + expcode + "' ";
            qry += " and( emp_code is null or emp_code in ( select distinct EMP_CODE  from SN_HIERARCHY_DETAIL where PARENT_RECID in (select PARENT_RECID  from SN_HIERARCHY_DETAIL where   EMP_CODE='" + userid + "' and ROLE='I' )  and PARENT_RECID in   (select SNH_RECID from SN_HIERARCHY where OU_CODE ='" + oucode + "' and SBU_CODE ='" + sbucode + "' and SBU_CATEGORY_CODE ='" + sbucatcode + "' and DEPT_CODE='" + deptcode + "' and STATUS='A'  ))) ";
            qry += " GROUP BY BUDGET_REF_NO,emp_code";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;

        }

        public static DataSet GetbudAmountTotal(string encode, string oucode, string sbucode, string sbucatcode, string brandcode, string prodid, string hrisdeptcode, string projcode, string expcode, string fyear, string budrefno, string budgetEmpCode)
        {
            ocon = con();
            opencon();
            string q = " ";
            q = "SELECT DEPARTMENT_CODE   FROM ALL_DEPARTMENTS A    WHERE HRIS_DEPT_CODE = '" + hrisdeptcode + "'     AND COMPANY = 'DS'     AND STATUS = 'A'    AND ROWNUM <= 1 ";
            OracleCommand cmd1 = new OracleCommand(q, ocon);
            string dept_code = Convert.ToString(cmd1.ExecuteScalar());

            q = "SELECT distinct(a.hris_FUNCtion_CODE)   FROM PROJECTS A, HRM_FUNCTION B, HRM_MAPPING_DEPT_FUNCTIONS C WHERE A.COMPANY = 'DS' AND A.HRIS_FUNCTION_CODE = B.FUNC_CODE AND A.STATUS  =  'A' AND A.HRIS_FUNCTION_CODE = C.FUNC_CODE  and C.DEPT_CODE= '" + hrisdeptcode + "'  and a.PROJECT='" + projcode + "'";
            cmd1 = new OracleCommand(q, ocon);
            string hris_func_code = Convert.ToString(cmd1.ExecuteScalar());
            closecon();
            //string qry = "SELECT BUDGET_REF_NO FROM GL_BUDGETS     WHERE ENTITY_CODE= '" + encode + "' AND FISCAL_YEAR='" + fyear + "'";//'"++"',

            string qry = "select 'TOTAL BUDGET AMOUNT: ' || IMIS.SANCTIONS_PKG.TOTAL_BUDGET_AMOUNT('" + encode + "','" + oucode + "','" + sbucode + "','" + sbucatcode + "','" + brandcode + "','" + prodid + "','" + hrisdeptcode + "','" + hris_func_code + "','" + fyear + "','" + expcode + "','" + budrefno + "','" + budgetEmpCode + "')  TOTAL_BUDGET_AMOUNT, ";
            qry += " 'BUDGET_AMOUNT_UPTO: ' || IMIS.SANCTIONS_PKG.BUDGET_AMOUNT_UPTO('" + encode + "','" + oucode + "','" + sbucode + "','" + sbucatcode + "','" + brandcode + "','" + prodid + "','" + hrisdeptcode + "','" + hris_func_code + "','" + fyear + "','" + expcode + "',to_date('" + DateTime.Now.ToString("dd/MM/yyyy") + "', 'dd/mm/yyyy'),'" + budrefno + "','" + budgetEmpCode + "') BUDGET_AMOUNT_UPTO,  ";
            qry += " 'BUDGET_CONSUMED_AMOUNT: ' || IMIS.SANCTIONS_PKG.BUDGET_CONSUMED_AMOUNT('" + encode + "','" + oucode + "','" + sbucode + "','" + sbucatcode + "','" + brandcode + "','" + prodid + "','" + hrisdeptcode + "','" + hris_func_code + "','" + fyear + "','" + expcode + "','" + budrefno + "','" + budgetEmpCode + "') BUDGET_CONSUMED_AMOUNT, ";
            qry += " 'TOT_AVAILABLE_BUDGET_AMOUNT: ' || IMIS.SANCTIONS_PKG.TOT_AVAILABLE_BUDGET_AMOUNT('" + encode + "','" + oucode + "','" + sbucode + "','" + sbucatcode + "','" + brandcode + "','" + prodid + "','" + hrisdeptcode + "','" + hris_func_code + "','" + fyear + "','" + expcode + "','" + budrefno + "','" + budgetEmpCode + "') TOT_AVAILABLE_BUDGET_AMOUNT, ";
            qry += " 'TOT_AVAILABLE_BUDGET_AMT_UPTO: ' || IMIS.SANCTIONS_PKG.TOT_AVAILABLE_BUDGET_AMT_UPTO('" + encode + "','" + oucode + "','" + sbucode + "','" + sbucatcode + "','" + brandcode + "','" + prodid + "','" + hrisdeptcode + "','" + hris_func_code + "','" + fyear + "','" + expcode + "',to_date('" + DateTime.Now.ToString("dd/MM/yyyy") + "', 'dd/mm/yyyy'),'" + budrefno + "','" + budgetEmpCode + "') TOT_AVAILABLE_BUDGET_AMT_UPTO, ";
            qry += "  nvl(IMIS.SANCTIONS_PKG.TOT_AVAILABLE_BUDGET_AMT_UPTO('" + encode + "','" + oucode + "','" + sbucode + "','" + sbucatcode + "','" + brandcode + "','" + prodid + "','" + hrisdeptcode + "','" + hris_func_code + "','" + fyear + "','" + expcode + "',to_date('" + DateTime.Now.ToString("dd/MM/yyyy") + "', 'dd/mm/yyyy'),'" + budrefno + "','" + budgetEmpCode + "'),0) AVAILABLE_AMT_UPTO, ";
            qry += "  nvl(IMIS.SANCTIONS_PKG.TOT_AVAILABLE_BUDGET_AMOUNT('" + encode + "','" + oucode + "','" + sbucode + "','" + sbucatcode + "','" + brandcode + "','" + prodid + "','" + hrisdeptcode + "','" + hris_func_code + "','" + fyear + "','" + expcode + "','" + budrefno + "','" + budgetEmpCode + "') ,0)  AVAILABLE_AMT ";
            qry += " from dual ";
            //P_ENTITY_CODE , P_OU_CODE ,P_SBU_CODE,P_SBU_CATEGORY_CODE,P_BRAND_CODE,P_PRODUCT_ID ,P_HRIS_DEPT_CODE,P_HRIS_FUNCTION_CODE ,P_FISCAL_YEAR  ,P_EXPENSE_CODE_BUDGET
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;
            

        }

        public static DataSet UpdatebudgetAmt(string encode, string oucode, string sbucode, string sbucatcode, string brandcode, string prodid, string deptcode, string projcode, string expcode, string fyear,decimal total)
        {
            ocon = con();
            
            string qry = "update GL_BUDGET_details set CONSUMED_AMOUNT = nvl(CONSUMED_AMOUNT,0) + " + total + " WHERE  ENTITY_CODE='" + encode + "' and   OU_CODE='" + oucode + "' and SBU_CODE='" + sbucode + "'  and SBU_CATEGORY_CODE='" + sbucatcode + "'  and BRAND_CODE='" + brandcode + "'  and PRODUCT_ID= '" + prodid + "'  ";
            qry += "   and DEPT_CODE= '" + deptcode + "' and PROJECT_CODE= '" + projcode + "' and FISCAL_YEAR= '" + fyear + "' and EXPENSE_CODE_BUDGET= '" + expcode + "'  ";

            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;

        }
        public static DataSet GetSBU(string encode)
        {
           
            ocon = con();
            string qry = "select SBU_CODE, SBU_CODE || '- ' || DESCRIPTION DESCRIPTION from OC_SBU A  where status='A'  AND EXISTS (SELECT 1 FROM OC_SBU_MAPPING B   WHERE  B.ENTITY_CODE = '" + encode + "'   AND  B.SBU_CODE = A.SBU_CODE AND STATUS= 'A') ";
            
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//
        }

        public static DataSet GetSBU1(string encode,string empcode)
        {

            ocon = con();
            string qry = "select SBU_CODE, SBU_CODE || '- ' || DESCRIPTION DESCRIPTION from OC_SBU A  where status='A'  AND EXISTS (SELECT 1 FROM OC_SBU_MAPPING B   WHERE  B.ENTITY_CODE = '" + encode + "'   AND  B.SBU_CODE = A.SBU_CODE  AND STATUS= 'A' ) ";
            qry += " and SBU_CODE in(select SBU_CODE from SN_HIERARCHY where SNH_RECID in (select PARENT_RECID from SN_HIERARCHY_DETAIL where emp_code= '" + empcode + "' and status='A')) order by DESCRIPTION";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//
        }

        public static DataSet getAllOpenFiscalYear()
        {
            ocon = con();
            string qry = "select distinct FISCAL_YEAR from fiscal_years  where status='O'";
            qry= "select distinct FISCAL_YEAR from fiscal_years  where status='O' and company in (select company from companies where company_type !='T')";
            qry = "select distinct FISCAL_YEAR from fiscal_years  where status='O' and company ='55'";
            //qry = "select max( FISCAL_YEAR ) FISCAL_YEAR from fiscal_years  where status='O'";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;
            
        }

        public static DataSet Getfyear()
        {
            ocon = con();
            string qry = "select fiscal_year from fiscal_years   where company ='55' and trunc(sysdate) between to_date(fiscal_year_start)  and to_date(fiscal_year_end)";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//
        }
        public static DataSet GetUNIT(string en, string sbucode)
        {
            ocon = con();
            string qry = "SELECT distinct OU_CODE, DESCRIPTION FROM  OC_OPERATING_UNIT WHERE ENTITY_CODE = '"+ en+"'";
            qry = "SELECT OU_CODE, OU_CODE || '- ' || DESCRIPTION DESCRIPTION FROM OC_OPERATING_UNIT A WHERE ENTITY_CODE ='" + en + "' AND STATUS='A'AND EXISTS (SELECT '1' FROM OC_SBU_MAPPING D WHERE D.SBU_CODE = '" + sbucode + "' AND D.OU_CODE = A.OU_CODE	AND D.STATUS = 'A')";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//
        }
        public static DataSet GetUNITbyEmp(string en, string sbucode,string empcode )
        {
            ocon = con();
            string qry = "SELECT distinct OU_CODE, DESCRIPTION FROM  OC_OPERATING_UNIT WHERE ENTITY_CODE = '" + en + "'";
            qry = "SELECT OU_CODE, OU_CODE || '- ' || DESCRIPTION DESCRIPTION FROM OC_OPERATING_UNIT A WHERE ENTITY_CODE ='" + en + "' AND STATUS='A'AND EXISTS (SELECT '1' FROM OC_SBU_MAPPING D WHERE D.SBU_CODE = '" + sbucode + "' AND D.OU_CODE = A.OU_CODE	AND D.STATUS = 'A') and OU_CODE in(select OU_CODE from SN_HIERARCHY where SNH_RECID in (select PARENT_RECID from SN_HIERARCHY_DETAIL where emp_code= '" + empcode + "'and status='A' ))";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//
        }

        public static DataSet GetUNITWarning(string en, string sbucode, string OU_CODE)
        {
            ocon = con();
            string qry = "SELECT distinct OU_CODE,DESCRIPTION FROM  OC_OPERATING_UNIT WHERE ENTITY_CODE = '" + en + "'";
            qry = "SELECT nvl(BUDGET_ERROR_WARNING,'A') BUDGET_ERROR_WARNING FROM OC_OPERATING_UNIT A WHERE ENTITY_CODE ='" + en + "' AND OU_CODE = '" + OU_CODE + "' AND STATUS='A'AND EXISTS (SELECT '1' FROM OC_SBU_MAPPING D WHERE D.SBU_CODE = '" + sbucode + "' AND D.OU_CODE = A.OU_CODE	AND D.STATUS = 'A')";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//
        }

        public static DataSet GetUNITList(string en, string sbucode)
        {
            ocon = con();
            string qry = "SELECT distinct OU_CODE,DESCRIPTION FROM  OC_OPERATING_UNIT WHERE ENTITY_CODE = '" + en + "'";
            qry = "SELECT OU_CODE || '-' || '" + sbucode + "' || '-' || DESCRIPTION as OU_CODE, DESCRIPTION FROM OC_OPERATING_UNIT A WHERE ENTITY_CODE ='" + en + "' AND STATUS='A'AND EXISTS (SELECT '1' FROM OC_SBU_MAPPING D WHERE D.SBU_CODE = '" + sbucode + "' AND D.OU_CODE = A.OU_CODE	AND D.STATUS = 'A') order by OU_CODE";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//
        }

        public static DataSet GetCategory(string sbucode, string oucode, string encode, string empcode)
        {
            ocon = con();
            string qry = "SELECT B.SBU_CATEGORY_CODE,B.SBU_CATEGORY_CODE || ' -' ||  B.DESCRIPTION DESCRIPTION FROM  OC_SBU_CATEGORY B WHERE B.SBU_CODE= '" + sbucode + "' AND B.STATUS = 'A' AND EXISTS (SELECT 1 FROM OC_SBU_MAPPING D WHERE D.SBU_CODE = B.SBU_CODE  AND STATUS= 'A' and D.SBU_CATEGORY_CODE = B.SBU_CATEGORY_CODE   AND D.OU_CODE =  '" + oucode + "' and d.entity_code ='" + encode + "')  and SBU_CATEGORY_CODE in(select SBU_CATEGORY_CODE from SN_HIERARCHY where SNH_RECID in (select PARENT_RECID from SN_HIERARCHY_DETAIL where emp_code= '" + empcode + "' and status='A')) order by SBU_CATEGORY_CODE";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//
        }

        public static DataSet GetCategoryAll(string sbucode, string oucode, string encode)
        {
            ocon = con();
            string qry = "SELECT B.SBU_CATEGORY_CODE,B.SBU_CATEGORY_CODE || ' -' ||  B.DESCRIPTION DESCRIPTION FROM  OC_SBU_CATEGORY B WHERE B.SBU_CODE= '" + sbucode + "' AND B.STATUS = 'A' AND EXISTS (SELECT 1 FROM OC_SBU_MAPPING D WHERE D.SBU_CODE = B.SBU_CODE and D.SBU_CATEGORY_CODE = B.SBU_CATEGORY_CODE   AND D.OU_CODE =  '" + oucode + "' and d.entity_code ='" + encode + "'  AND STATUS= 'A') order by SBU_CODE";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//
        }

        public static DataSet GetCategoryList( string oucode, string encode)
        {
            string[] arr = oucode.Split('-');
            string sbucode = arr[1].ToString();
            oucode = arr[0].ToString();
            ocon = con();
            string qry = "SELECT B.SBU_CODE || '-' || '" + oucode + "' || '-' || B.SBU_CATEGORY_CODE ||'-' || DESCRIPTION as SBU_CATEGORY_CODE, B.DESCRIPTION FROM  OC_SBU_CATEGORY B WHERE B.SBU_CODE= '" + sbucode + "' AND B.STATUS = 'A' AND EXISTS (SELECT 1 FROM OC_SBU_MAPPING D WHERE D.SBU_CODE = B.SBU_CODE and D.SBU_CATEGORY_CODE = B.SBU_CATEGORY_CODE   AND D.OU_CODE =  '" + oucode + "' and d.entity_code ='" + encode + "  AND STATUS= 'A'') order by SBU_CODE";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//
        }

        public static DataSet GetBrand(string sbucode, string sbucatcode, string oucode, string encode)
        {
            ocon = con();
            string qry = "SELECT  A.DESCRIPTION, B.SBU_CATEGORY_CODE, B.DESCRIPTION, C.BRAND_CODE, C.DESCRIPTION desc1 FROM OC_SBU A,  OC_SBU_CATEGORY B , OC_BRANDS  C WHERE A.SBU_CODE= B.SBU_CODE AND B.SBU_CATEGORY_CODE = C.SBU_CATEGORY_CODE AND A.STATUS = 'A' AND B.STATUS = 'A' AND C.STATUS = 'A' and A.SBU_CODE ='"+sbucode+"' and B.SBU_CATEGORY_CODE ='"+ sbucatcode+"' ";
            qry = "SELECT  C.BRAND_CODE, C.DESCRIPTION FROM  OC_BRANDS  C WHERE C.SBU_CATEGORY_CODE =  '" + sbucatcode + "' AND C.STATUS = 'A' AND EXISTS (SELECT '1' FROM OC_SBU_MAPPING D WHERE D.OU_CODE = '"+oucode+"' AND D.SBU_CATEGORY_CODE = '" + sbucatcode + "' AND D.BRAND_CODE = C.BRAND_CODE AND D.STATUS = 'A')";
            qry = "SELECT  C.BRAND_CODE,  C.BRAND_CODE || '- ' || C.DESCRIPTION DESCRIPTION FROM  OC_BRANDS  C WHERE C.SBU_CODE = '" + sbucode + "' AND C.SBU_CATEGORY_CODE =  '" + sbucatcode + "' AND C.STATUS = 'A' ";
            qry += " AND EXISTS (SELECT '1' FROM OC_SBU_MAPPING D WHERE D.ENTITY_CODE = '" + encode + "'   AND D.OU_CODE = '" + oucode + "'   AND D.SBU_CODE = '" + sbucode + "'  AND D.SBU_CATEGORY_CODE = '" + sbucatcode + "'  AND D.SBU_CODE  =C.SBU_CODE   AND  D.SBU_CATEGORY_CODE = C.SBU_CATEGORY_CODE    AND D.BRAND_CODE = C.BRAND_CODE  AND D.STATUS = 'A' and nvl(RESTRICTED_IN_SANCTION,'N')<> 'Y')";
            
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//
        }

        public static DataSet Getproduct(string brandcode, string sbucatcode, string oucode, string sbucode, string encode)
        {
            ocon = con();
            string qry = "SELECT C.PRODUCT_ID, C.DESCRIPTION  FROM  OC_PRODUCTS C, OC_SBU_MAPPING D WHERE  C.BRAND_CODE =  '" + brandcode + "' AND D.SBU_CATEGORY_CODE =  '" + sbucatcode + "' AND C.STATUS = 'A' AND C.BRAND_CODE = D.BRAND_CODE  ";

            //qry = "SELECT C.PRODUCT_ID, C.DESCRIPTION FROM  OC_PRODUCTS C WHERE  C.BRAND_CODE = '" + brandcode + "' AND EXISTS (SELECT '1' FROM  OC_SBU_MAPPING D   WHERE D.OU_CODE = '" + oucode + "'     AND D.SBU_CATEGORY_CODE = '" + sbucatcode + "'  OC_SBU_MAPPING AND D.BRAND_CODE = '" + brandcode + "'  AND D.BRAND_CODE = C.BRAND_CODE   AND D.PRODUCT_ID = C.PRODUCT_ID  )";
            qry = "SELECT C.PRODUCT_ID, C.PRODUCT_ID || '- ' || C.DESCRIPTION DESCRIPTION FROM  OC_PRODUCTS C WHERE C.SBU_CODE = '" + sbucode + "' AND C.SBU_CATEGORY_CODE =  '" + sbucatcode + "' AND C.BRAND_CODE = '" + brandcode + "' AND EXISTS (SELECT '1' FROM  OC_SBU_MAPPING D   WHERE D.ENTITY_CODE = '" + encode + "'   AND D.OU_CODE = '" + oucode + "'  AND  C.SBU_CODE = '" + sbucode + "' AND D.SBU_CATEGORY_CODE = '" + sbucatcode + "'   AND D.BRAND_CODE = '" + brandcode + "'  AND D.SBU_CODE  =C.SBU_CODE  AND D.SBU_CATEGORY_CODE = C.SBU_CATEGORY_CODE  AND D.BRAND_CODE = C.BRAND_CODE   AND D.PRODUCT_ID = C.PRODUCT_ID AND STATUS= 'A'  )";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;//
        }

       
        

       public static DataSet Getstatus()
        {
            ocon = con();
            string qry = "select id,cname  from item_status  order by cname";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;
        }

       public static DataSet GetApproval_Detail(string precid)
       {// select S_NO,EMP_CODE,SKIPPED from SN_SANCTION_APPROVALS  where PARENT_RECID= ''
           ocon = con();
           string qry = "select S_NO,EMP_CODE,SKIPPED,ROLE,SNSA_RECID from SN_SANCTION_APPROVALS  where PARENT_RECID= '" + precid + "' ";
           OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
           DataSet ds = new DataSet();
           da.Fill(ds);
           return ds;//
       }

       public static DataSet GetHierarchy_Detail(string hcode, string encode)
       {
           ocon = con();
           string qry = "select SNHD_RECID,S_NO,EMP_CODE,MANDATORY,ROLE  from SN_HIERARCHY_DETAIL  where upper(HIERARCHY_CODE) ='" + hcode + "' and  ENTITY_CODE='" + encode + "' and status='A' ";
           OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
           DataSet ds = new DataSet();
           da.Fill(ds);
           return ds;//
       }

       public static DataSet getMasterDetail(string recid, string status)
       {
           ocon = con();

           string qry = "select SNS_RECID, (SELECT LEGAL_NAME FROM OC_ENTITY B where b.ENTITY_CODE = m.ENTITY_CODE)  ENTITY_CODE_d,ENTITY_CODE,sANCTION_NO,to_char(SANCTION_DATE,'dd/MM/yyyy')SANCTION_DATE,FISCAL_YEAR,m.CREATED_BY as CREATED_BY1, ";
           qry += " (select DESCRIPTION from OC_SBU  where status='A' and SBU_CODE= m.SBU_CODE) SBU_CODE_d,SBU_CODE,  (SELECT DESCRIPTION FROM hrm_DEPARTMENT where DEPT_CODE = hris_DEPT_CODE ) DEPT_CODE_d,DEPT_CODE, ";
           qry += " (SELECT  FUNC_DESC from HRM_FUNCTION where FUNC_CODE=   HRIS_FUNCTION_CODE) PROJECT, HRIS_FUNCTION_CODE,HRIS_DEPT_CODE,PROJECT PROJECT1, case status when 'P' then 'In Process' when 'A' then 'Approved' when 'E' then 'Re-Intiated' when 'R' then 'Rejected' end statusF,";
            //--PROJECT,    --HRIS_FUNCTION_CODE,
           qry += " VERSION_NO,HIERARCHY_CODE,SANCTION_SOUGHT_FOR,TOTAL_AMOUNT,BACKGROUD_INFO,CRITICAL_ISSUES_DETAIL,STATUS,(select employee_name   from hrm_employee where status in ('C','P','N') and emp_code =m.CREATED_BY) CREATED_BY,to_char(CREATED_ON,'dd/mm/yyyy') CREATED_ON,m.current_status ";
            qry += " From SN_SANCTIONS  m  where sns_recid ='" + recid + "' ";
           OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
           DataSet ds = new DataSet();
           da.Fill(ds);
           return ds;
       }

       public static void ShowAlertMessage(string msg, string pageurl)
       {
          Page page = HttpContext.Current.Handler as Page;

           if (page != null)
           {
               msg = msg.Replace("'", "\\");
               ScriptManager.RegisterStartupScript(page, page.GetType(), "err_msg", "alert('" + msg + "');window.location='" + pageurl + "';", true);
           }
       }
       public static void ShowAlert(string msg)
       {
           //Display javascript-alert
           //Page page = TryCast(HttpContext.Current.Handler, Page);
           Page page = HttpContext.Current.Handler as Page;

           if (page != null)
           {
               msg = msg.Replace("'", "\\");
               ScriptManager.RegisterStartupScript(page, page.GetType(), "Popup", "alert('" + msg + "');", true);
           }
       }

       public static SmtpClient sclient()
       {
           System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient();
           client.UseDefaultCredentials = true;
           client.DeliveryMethod = SmtpDeliveryMethod.Network;
           client.EnableSsl = false;

           client.Host = "email.dsgroup.com";
           client.Port = 25;

           NetworkCredential cred = new NetworkCredential("intranet.admin@dsgroup.com", "admin");
           client.Credentials = cred;
           return client;
       }


       private static string createEmailBody(string userName, string title, string message, string path, string url)
       {

           string body = string.Empty;
           //using streamreader for reading my htmltemplate   

           using (System.IO.StreamReader reader = new System.IO.StreamReader(path))
           {

               body = reader.ReadToEnd();

           }

           body = body.Replace("{UserName}", ""); //replacing the required things  

           body = body.Replace("{Title}", title);

           body = body.Replace("{message}", message);
           body = body.Replace("{Url}", url);
           return body;

       }

       private static void SendHtmlFormattedEmail(string subject, string body, string to, string from, string cc)
       {

           using (MailMessage mailMessage = new MailMessage())
           {
               
               mailMessage.From = new MailAddress(from);

               mailMessage.Subject = subject;

               mailMessage.Body = body;

               mailMessage.IsBodyHtml = true;

               mailMessage.To.Add(new MailAddress(to));//txt_email.Text

               
               System.Net.Mail.SmtpClient client = sclient();
               client.Send(mailMessage);

           }

       }

       public static string mailpprove(string to, string from, string name, string sid, string path, string sancno)
       {
           string htmlBody = "";
           try
           {
               //htmlBody += " id " + to + " <br />";
               //to = "shikha.katiyar@dsgroup.com";
               System.Net.Mail.SmtpClient client = sclient();
               MailMessage msg = new MailMessage(from, to);
               //msg.CC.Add(from);
               msg.Subject = "Sanction Memo No. " + sancno;// +name;
               msg.IsBodyHtml = true;

               htmlBody += "Sanction memo no " + sancno + " has been initiated by " + name + " , you are requested to kindly review the same by clicking on the link below. <br /><br />";
               htmlBody += "https://intranet.dsgroup.com/Sanction/sanctiondetails.aspx?sid=" + sid + " <br /><br />";
               htmlBody += "Kindly note that this is system generated email, so do not reply to this email.<br /><br />";
               htmlBody += "In case you wish to get back to Initiator regarding some clarification on this Sanction memo, then please write an email to the Initiator. Else please select one of the Action boxes in the Sanction memo and specify Comments , if any.<br /><br />";
               htmlBody += "Post your submission of the action, the process will move forward.";


               msg.Body = htmlBody;

               string url = "";
               string body = createEmailBody("", "Sanction Memo No. " + sancno, htmlBody, path, url);

               SendHtmlFormattedEmail(msg.Subject, body, to, from, from);
               return "Y";
               //client.Send(msg);
               //return ("mail send to " + to + " from " + from + "  " + DateTime.Now.ToString());
           }
           catch (Exception ex)
           {
               return htmlBody;
               //return ("mail not send to -" + to + " from -" + from + "  " + DateTime.Now.ToString() + " error -" + ex.Message);
           }
       }

       public static string mailpproveAlert(string to, string from, string name, string sid, string path, string sancno)
       {
           string htmlBody = "";
           try
           {
               htmlBody += " id " + to + " <br />";
               //to = "shikh.katiyar@dsgroup.com";
               System.Net.Mail.SmtpClient client = sclient();
               MailMessage msg = new MailMessage(from, to);
               msg.CC.Add(from);
               msg.Subject = " Sanction Memo No " + sancno;// +name;
               msg.IsBodyHtml = true;
               htmlBody += "Sanction memo no " + sancno + " has been approved by " + name + " . Please click on the link below for details:<br/>";
               htmlBody += "https://intranet.dsgroup.com/Sanction/sanctiondetails.aspx?sid=" + sid + " <br /><br />";
               htmlBody += "Kindly note that this is system generated email, so do not reply to this email.";


               msg.Body = htmlBody;
               client.Send(msg);
               return "Y";
           }
           catch (Exception ex)
           {
               return htmlBody;
           }
       }

       public static string mailReint(string to, string from, string name, string sid, string path, string sancno)
       {
           string htmlBody = "";
           try
           {
               //htmlBody += " id " + to + " <br />";
               //to = "shikha.katiyar@dsgroup.com";
               System.Net.Mail.SmtpClient client = sclient();
               MailMessage msg = new MailMessage(from, to);
               msg.CC.Add(from);
               msg.Subject = " Sanction Memo No " + sancno;// +name;
               msg.IsBodyHtml = true;

               //htmlBody = "Request Has been approved.<br/><br/><br/>";

               htmlBody += "Sanction memo no " + sancno + " has been asked for reinitiating  by " + name + " . Please click on the link below for details:<br/>";
               htmlBody += "https://intranet.dsgroup.com/Sanction/sanctiondetails.aspx?sid=" + sid + " <br /><br />";
               htmlBody += "Kindly note that this is system generated email, so do not reply to this email.";

               //

               msg.Body = htmlBody;
               client.Send(msg);
               return "Y";
           }
           catch (Exception ex)
           {
               return htmlBody;
           }
       }

       public static string mailFinalpprove(string to, string from, string name, string sid, System.IO.MemoryStream ms, string fs)
       {
           try
           {
               System.Net.Mail.SmtpClient client = sclient();
               MailMessage msg = new MailMessage(from, to);
               //msg.Bcc.Add("shikha.katiyar@dsgroup.com");
               msg.Subject = "ASPA Sanction Approved ";// +name;
               msg.IsBodyHtml = true;
               msg.Attachments.Add(new Attachment(ms, "Sanction.pdf"));
               if (fs != "")
                   msg.Attachments.Add(new Attachment(fs));
               string htmlBody;
               //htmlBody = "Request Has been approved.<br/><br/><br/>";

               htmlBody = "One sanction has been approved.<br/><br/Pl find attached Details  :<br/><br/>";

               msg.Body = htmlBody;
               client.Send(msg);
               return ("mail send to " + to + " from " + from + "  " + DateTime.Now.ToString());
           }
           catch (Exception ex)
           {
               return ("mail not send to -" + to + " from -" + from + "  " + DateTime.Now.ToString() + " error -" + ex.Message);
           }
       }

       public static string mailcancel(string to, string from, string name, string sid, string path, string sancno, string Remark)
       {
           string htmlBody = ""; ;
           try
           {
               System.Net.Mail.SmtpClient client = sclient();
               //htmlBody += " id " + to + " <br />";
               //to = "shikha.katiyar@dsgroup.com";
               MailMessage msg = new MailMessage(from, to);
               msg.CC.Add(from);
               msg.Subject = " Sanction Memo No " + sancno;// +name;
               msg.IsBodyHtml = true;

               //htmlBody = "Request Has been approved.<br/><br/><br/>";

               htmlBody += "Sanction memo no " + sancno + " has been cancelled by " + name + " . <br/>";
               //htmlBody += "Remark : " + Remark + " . <br/>";
               //htmlBody += "https://intranet.dsgroup.com/Sanction/SanctionDetails.aspx?sid=" + sid + " <br /><br />";
               htmlBody += "Kindly note that this is system generated email, so do not reply to this email.";

               msg.Body = htmlBody;
               client.Send(msg);
               return "Y";
               //return ("mail send to " + to + " from " + from + "  " + DateTime.Now.ToString());
           }
           catch (Exception ex)
           {
               return htmlBody;
               //return ("mail not send to -" + to + " from -" + from + "  " + DateTime.Now.ToString() + " error -" + ex.Message);
           }
       }



       public static string mailtoRecomm(string to, string from, string name, string sid, string path, string sancno)
       {
           string htmlBody = "";
           try
           {
               //htmlBody += " id " + to + " <br />";
               //to = "shikha.katiyar@dsgroup.com";
               System.Net.Mail.SmtpClient client = sclient();
               MailMessage msg = new MailMessage(from, to);
               msg.CC.Add(from);
               msg.Subject = "Sanction Memo No. " + sancno;// +name;
               msg.IsBodyHtml = true;

               htmlBody += "Sanction memo no " + sancno + " has been initiated by " + name + " , you are requested to kindly review the same by clicking on the link below. <br /><br />";
               htmlBody += "https://intranet.dsgroup.com/Sanction/sanctiondetails.aspx?sid=" + sid + " <br /><br />";
               htmlBody += "Kindly note that this is system generated email, so do not reply to this email.<br /><br />";
               htmlBody += "In case you wish to get back to Initiator regarding some clarification on this Sanction memo, then please write an email to the Initiator. Else please select one of the Action boxes in the Sanction memo and specify Comments , if any.<br /><br />";
               htmlBody += "Post your submission of the action, the process will move forward.";


               msg.Body = htmlBody;

               string url = "";
               string body = createEmailBody("", "Sanction Memo No. " + sancno, htmlBody, path, url);

               SendHtmlFormattedEmail(msg.Subject, body, to, from, from);
               return "Y";
               //client.Send(msg);
               //return ("mail send to " + to + " from " + from + "  " + DateTime.Now.ToString());
           }
           catch (Exception ex)
           {
               return htmlBody;
               //return ("mail not send to -" + to + " from -" + from + "  " + DateTime.Now.ToString() + " error -" + ex.Message);
           }
       }

       public static string mailtoRecall(string to, string from, string sancno, string path)
       {
           string htmlBody = "";
           try
           {
               //htmlBody += " id " + to + " <br />";
               //to = "shikha.katiyar@dsgroup.com";
               System.Net.Mail.SmtpClient client = sclient();
               MailMessage msg = new MailMessage(from, to);
               //msg.CC.Add("shikha.katiyar@dsgroup.com");
               msg.CC.Add(from);
               msg.Subject = "Sanction Memo No. " + sancno;// +name;
               msg.IsBodyHtml = true;

               //htmlBody += "Testing mail kindly ignore <br /><br />";

               htmlBody += "Sanction memo no " + sancno + " has been Recalled by " + from + ". <br /><br />";
               //htmlBody += "https://intranet.dsgroup.com/Sanction/sanctiondetails.aspx?sid=" + sid + " <br /><br />";
               htmlBody += "Kindly note that this is system generated email, so do not reply to this email.<br /><br />";
               //htmlBody += "In case you wish to get back to Initiator regarding some clarification on this Sanction memo, then please write an email to the Initiator. Else please select one of the Action boxes in the Sanction memo and specify Comments , if any.<br /><br />";
               //htmlBody += "Post your submission of the action, the process will move forward.";


               msg.Body = htmlBody;

               string url = "";
               string body = createEmailBody("", "Sanction Memo No. " + sancno, htmlBody, path, url);

               SendHtmlFormattedEmail(msg.Subject, body, to, from, from);
               return "Y";
               //client.Send(msg);
               //return ("mail send to " + to + " from " + from + "  " + DateTime.Now.ToString());
           }
           catch (Exception ex)
           {
               return htmlBody;
               //return ("mail not send to -" + to + " from -" + from + "  " + DateTime.Now.ToString() + " error -" + ex.Message);
           }
       }

       public static string mailtoDiscuss(string to, string from, string sancno, string path, string sid)
       {
           string htmlBody = "";
           try
           {
               //htmlBody += " id " + to + " <br />";
               //to = "shikha.katiyar@dsgroup.com";
               System.Net.Mail.SmtpClient client = sclient();
               MailMessage msg = new MailMessage(from, to);
               //msg.CC.Add("shikha.katiyar@dsgroup.com");
               msg.CC.Add(from);
               msg.Subject = "Sanction Memo No. " + sancno;// +name;
               msg.IsBodyHtml = true;

               // htmlBody += "Testing mail kindly ignore <br /><br />";

               htmlBody += "Sanction memo no " + sancno + " has been Submitted For Discussion. . <br /><br />";
               htmlBody += "https://intranet.dsgroup.com/Sanction/sanctiondetails.aspx?sid=" + sid + " <br /><br />";
               htmlBody += "Kindly note that this is system generated email, so do not reply to this email.<br /><br />";
               //htmlBody += "In case you wish to get back to Initiator regarding some clarification on this Sanction memo, then please write an email to the Initiator. Else please select one of the Action boxes in the Sanction memo and specify Comments , if any.<br /><br />";
               //htmlBody += "Post your submission of the action, the process will move forward.";


               msg.Body = htmlBody;

               string url = "";
               string body = createEmailBody("", "Sanction Memo No. " + sancno, htmlBody, path, url);

               SendHtmlFormattedEmail(msg.Subject, body, to, from, from);
               return "Y";
               //client.Send(msg);
               //return ("mail send to " + to + " from " + from + "  " + DateTime.Now.ToString());
           }
           catch (Exception ex)
           {
               return htmlBody + ex.Message;
               //return ("mail not send to -" + to + " from -" + from + "  " + DateTime.Now.ToString() + " error -" + ex.Message);
           }
       }

       public static string mailToApprover(string to, string from, string name, string sid, string path, string sancno)
       {
           string htmlBody = "";
           try
           {
               //htmlBody += " id " + to + " <br />";
              // to = "shikha.katiyar@dsgroup.com";
               System.Net.Mail.SmtpClient client = sclient();
               MailMessage msg = new MailMessage(from, to);
               //msg.CC.Add(from);
               msg.Subject = "Sanction Memo No. " + sancno;// +name;
               msg.IsBodyHtml = true;

               htmlBody += "Sanction memo no " + sancno + " has been initiated by " + name + " and reviewed by all in the Approval cycle.<br /><br />";
               htmlBody += "This Sanction memo is now being forwarded to you to review and give final decision  by selecting one of the Action boxes. Please click on the link below :<br /><br />";
               htmlBody += "https://intranet.dsgroup.com/Sanction/sanctiondetails.aspx?sid=" + sid + " <br /><br />";
               htmlBody += "Kindly note that this is system generated email, so do not reply to this email.<br /><br />";
               htmlBody += "In case you wish to get back to Initiator/ Reviewer(s) regarding some clarification on this Sanction memo, then please write an email to the Initiator.<br /><br />";
               //htmlBody += "Post your submission of the action, the process will move forward.";


               msg.Body = htmlBody;

               string url = "";
               string body = createEmailBody("", "Sanction Memo No. " + sancno, htmlBody, path, url);

               SendHtmlFormattedEmail(msg.Subject, body, to, from, from);
               return "Y";
               //client.Send(msg);
               //return ("mail send to " + to + " from " + from + "  " + DateTime.Now.ToString());
           }
           catch (Exception ex)
           {
               return htmlBody;
               //return ("mail not send to -" + to + " from -" + from + "  " + DateTime.Now.ToString() + " error -" + ex.Message);
           }
       }

       public static string mailFinalApproveAlert(string to, string cc, string from, string name, string sid, string path, string sancno)
       {
           string htmlBody = "";
           try
           {
               //htmlBody += " id " + to + " <br />";
               //htmlBody += " id cc" + cc + " <br />";
               //to = "shikha.katiyar@dsgroup.com";
               System.Net.Mail.SmtpClient client = sclient();
               MailMessage msg = new MailMessage(from, to);
               msg.CC.Add(cc);
               msg.Subject = "Sanction Memo No. " + sancno;// +name;
               msg.IsBodyHtml = true;

               htmlBody += "Sanction memo no " + sancno + " has been approved by " + name + ".<br /><br />";
               htmlBody += "Please click on the link below :<br /><br />";
               htmlBody += "https://intranet.dsgroup.com/Sanction/sanctiondetails.aspx?sid=" + sid + " <br /><br />";
               htmlBody += "Kindly note that this is system generated email, so do not reply to this email.<br /><br />";





               msg.Body = htmlBody;

               string url = "";
               string body = createEmailBody("", "Sanction Memo No. " + sancno, htmlBody, path, url);

               SendHtmlFormattedEmail(msg.Subject, body, to, from, from);
               return "Y";
               //client.Send(msg);
               //return ("mail send to " + to + " from " + from + "  " + DateTime.Now.ToString());
           }
           catch (Exception ex)
           {
               return htmlBody;
               //return ("mail not send to -" + to + " from -" + from + "  " + DateTime.Now.ToString() + " error -" + ex.Message);
           }
       }

    }
}