﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OracleClient;
using MyClass;

public partial class ShowSN_HIERARCHY : System.Web.UI.Page
{
    OracleConnection ocon = new OracleConnection();
    OracleDataAdapter da; DataSet ds; string userid = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //if (Session["dept"] != null && Session["dept"].ToString() != "")
            //{
            //    getData(Session["dept"].ToString());
            //}
            if (Session["emp_code"] != null && Session["emp_code"].ToString() != "")
            {
                userid = Session["emp_code"].ToString();
                getData(userid);
                //email = Session["email"].ToString();
            }
        }
    }

    protected void getData(string userid1)
    {
        ocon = CommonFunc.con();
        string qry = "select SNH_RECID,ou_code, (select LEGAL_NAME from OC_ENTITY where ENTITY_CODE= s.ENTITY_CODE) ENTITY_CODE1,ENTITY_CODE || ',' || SNH_RECID ENTITY_CODE,(SELECT department_desc FROM ALL_DEPARTMENTS  where DEPARTMENT_CODE =   s.DEPT_CODE and company='DS') DEPT_CODE1, upper(HIERARCHY_CODE) HIERARCHY_CODE,upper(DESCRIPTION) DESCRIPTION from  SN_HIERARCHY s where SNH_RECID in (select PARENT_RECID from SN_HIERARCHY_detail where emp_code='"+userid1+"' and role='I' and status= 'A') order by SNH_RECID";
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvData.DataSource = ds;
            gvData.DataBind();
        }
        qry = "select SNH_RECID,ou_code, (select LEGAL_NAME from OC_ENTITY where ENTITY_CODE= s.ENTITY_CODE) ENTITY_CODE1,ENTITY_CODE || ',' || SNH_RECID ENTITY_CODE,(SELECT department_desc FROM ALL_DEPARTMENTS  where DEPARTMENT_CODE =   s.DEPT_CODE and company='DS') DEPT_CODE1, upper(HIERARCHY_CODE) HIERARCHY_CODE,upper(DESCRIPTION) DESCRIPTION from  SN_HIERARCHY s where SNH_RECID in (select PARENT_RECID from SN_HIERARCHY_detail where emp_code='" + userid1 + "' and role in ('R','A') and status= 'A') order by SNH_RECID";
        da = new OracleDataAdapter(qry, ocon);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvApp.DataSource = ds;
            gvApp.DataBind();
        }
    }
    protected void gvData_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "show")
        {
            string id = e.CommandArgument.ToString();
            int k = id.IndexOf(',');
            string ecode = id.Substring(0, k);
            string hcode = id.Substring(k+1);

            ocon = CommonFunc.con();
            string qry = "select SNHD_RECID, (select LEGAL_NAME from OC_ENTITY where ENTITY_CODE= s.ENTITY_CODE) ENTITY_CODE1,ENTITY_CODE,HIERARCHY_CODE,S_NO, (select employee_name from hrm_employee where EMP_CODE= s.EMP_CODE) EMP_CODE, ";
            qry += " case when  MANDATORY= 'Y' then 'Yes' else 'No' end MANDATORY, case when  ROLE= 'I' then 'Initiator' when  ROLE= 'R' then 'Reviewer' else 'Approver' end ROLE  from SN_HIERARCHY_DETAIL s where  PARENT_RECID='" + hcode + "' order by S_NO";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvDetail.DataSource = ds;
                gvDetail.DataBind();
                gvDetail.Visible = true;
            }
            else
                gvDetail.Visible = false;
        }
        if (e.CommandName == "select")
        {
            string id = e.CommandArgument.ToString();
            Session["hid"] = id.ToString();
            GridViewRow row = (GridViewRow)((LinkButton)e.CommandSource).NamingContainer;
            row.BackColor = System.Drawing.Color.Yellow;
            CommonFunc.ShowAlert("Hierarchy Selected.");
        }
    }
}
    
