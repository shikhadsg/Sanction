﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MyClass;
using System.Data;
using System.Data.OracleClient;

public partial class ShowSavedSanctionList : System.Web.UI.Page
{
    OracleConnection ocon = new OracleConnection(); string myQ = "";
    OracleDataAdapter da; DataSet ds; string userid = ""; 
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["emp_code"] != null && Session["emp_code"].ToString() != "")
        {
            userid = Session["emp_code"].ToString();
            //email = Session["email"].ToString();
        }
        if (!IsPostBack)
        {
            getdata();
        }
    }

    protected void getdata()
    {
        ocon = CommonFunc.con();
        string qry = "select SNS_RECID, (SELECT LEGAL_NAME FROM OC_ENTITY B where b.ENTITY_CODE = m.ENTITY_CODE)  ENTITY_CODE,sANCTION_NO,to_char(SANCTION_DATE,'dd/MM/yyyy')SANCTION_DATE,FISCAL_YEAR, ";
        qry += " (select DESCRIPTION from OC_SBU  where status='A' and SBU_CODE= m.SBU_CODE) SBU_CODE,  (SELECT DEPARTMENT_DESC FROM ALL_DEPARTMENTS where DEPARTMENT_CODE = DEPT_CODE AND COMPANY = 'DS') DEPT_CODE, ";
        qry += " (SELECT  B.FUNC_DESC    FROM PROJECTS A, HRM_FUNCTION B, HRM_MAPPING_DEPT_FUNCTIONS C WHERE A.COMPANY = 'DS' AND A.HRIS_FUNCTION_CODE = B.FUNC_CODE AND A.STATUS  =  'A' AND A.HRIS_FUNCTION_CODE = C.FUNC_CODE  and C.DEPT_CODE= m.DEPT_CODE and A.PROJECT  = m.PROJECT) PROJECT, ";
        //--PROJECT,    --HRIS_FUNCTION_CODE,
        qry += " VERSION_NO,HIERARCHY_CODE,SANCTION_SOUGHT_FOR,TOTAL_AMOUNT,BACKGROUD_INFO,CRITICAL_ISSUES_DETAIL,STATUS,CREATED_BY,CREATED_ON ";
        qry += " From SN_SANCTIONS  m where (status='N' or status= 'E') and  CREATED_BY= '"+userid+"'";
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
        DataSet ds = new DataSet();
        da.Fill(ds);//SNS_RECID  ENTITY_CODE sANCTION_NO SANCTION_DATE SBU_CODE PROJECT TOTAL_AMOUNT
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvData.DataSource = ds;
            gvData.DataBind();
        }
    }
    protected void gvData_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "view")
        {
            Response.Redirect("PrevieSanction.aspx?sid=" + e.CommandArgument.ToString());
        }
    }
}