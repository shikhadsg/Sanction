﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MyClass;
using System.Data;
using System.Data.OracleClient;

public partial class PrevieSanction : System.Web.UI.Page
{
    OracleConnection ocon = new OracleConnection(); string qry = "", budgetEmpCode=null;
    OracleDataAdapter da; DataSet ds; string userid = "skatiyar"; string recid = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if(Session["recid"] !=null && Session["recid"].ToString()!="")
        {
            recid = Session["recid"].ToString();
        }
        if (Request.QueryString["sid"] != null && Request.QueryString["sid"].ToString() != "")
        {
            recid = Request.QueryString["sid"].ToString();
        }
        if (Session["emp_code"] != null && Session["emp_code"].ToString() != "")
        {
            userid = Session["emp_code"].ToString();
            //email = Session["email"].ToString();
        }
        if (!IsPostBack)
        {
            ds = CommonFunc.getMasterDetail(recid,"");
            //   FISCAL_YEAR     VERSION_NO HIERARCHY_CODE  TOTAL_AMOUNT           } HRIS_FUNCTION_CODE,HRIS_DEPT_CODE
            if(ds.Tables[0].Rows.Count>0)
            {
                DataRow dr =ds.Tables[0].Rows[0];
                lblSancDate.Text = dr["SANCTION_DATE"].ToString();
                lblSancNo.Text = dr["SANCTION_NO"].ToString();
                lblEntity.Text = dr["ENTITY_CODE_d"].ToString();
                lblEnt.Text = dr["ENTITY_CODE"].ToString();
                lblVersion.Text = dr["VERSION_NO"].ToString();
                lblTotal.Text = dr["TOTAL_AMOUNT"].ToString();
                lblSBU.Text = dr["SBU_CODE_d"].ToString();
                lblsb.Text = dr["SBU_CODE"].ToString();
                lblDepartment.Text = dr["DEPT_CODE_d"].ToString();
                lblDept.Text = dr["hris_DEPT_CODE"].ToString();
                lblFunction.Text = dr["PROJECT"].ToString();
                lblFyear.Text = dr["FISCAL_YEAR"].ToString();
                lblSoughtFor.Text = dr["SANCTION_SOUGHT_FOR"].ToString();
                txtback.Text = Server.HtmlDecode( dr["BACKGROUD_INFO"].ToString());
                txtback.Rows = (txtback.Text.Split('\n').Length);
                txtIssues.Text = dr["CRITICAL_ISSUES_DETAIL"].ToString();
                lblhrisDept.Text = dr["HRIS_DEPT_CODE"].ToString();//CREATED_BY  CREATED_ON
                lblhrisFunc.Text = dr["PROJECT1"].ToString();
                lblIntBy.Text = dr["CREATED_BY"].ToString();
                lblInton.Text = dr["CREATED_ON"].ToString();
                getDetailData(); getapp(); getAttach();
                lblStatus.Text = dr["STATUS"].ToString();
            }
            getDetailData();
            btnSubmit.Visible = false;
            // Session["flag"] = "Y";
            if (lblSancNo.Text.Contains("Temp"))
            {
                btnSubmit.Visible = true;
            }
            else if(Session["flag"] != null &&  Session["flag"].ToString() == recid)
            {
                btnSubmit.Visible = true;
            }
            
              
        }
    }

    protected void getDetailData()
    {                        
        qry = " select  SNSD_RECID,  (SELECT LEGAL_NAME FROM OC_ENTITY B WHERE status='A' and ENTITY_CODE= s.ENTITY_CODE) ENTITY_CODE, s.SANCTION_NO,to_char(s.SANCTION_DATE,'dd/mm/yyyy') SANCTION_DATE,OU_CODE OU_CODE1,SBU_CATEGORY_CODE SBU_CATEGORY_CODE1,BRAND_CODE BRAND_CODE1,product_ID product_ID1, EXPENSE_CODE_BUDGET EXPENSE_CODE_BUDGET1, ";
        qry += " (select DESCRIPTION from OC_OPERATING_UNIT o where o.ENTITY_CODE = s.ENTITY_CODE and o.OU_CODE = s.OU_CODE  ) OU_CODE, ";
        qry += "  (SELECT  B.DESCRIPTION FROM  OC_SBU_CATEGORY B WHERE  b.SBU_CODE = m.SBU_CODE and B.SBU_CATEGORY_CODE =s.SBU_CATEGORY_CODE  )SBU_CATEGORY_CODE,  ";
        //--(SELECT   C.DESCRIPTION FROM  OC_BRANDS  C WHERE C.SBU_CATEGORY_CODE =  s.SBU_CATEGORY_CODE AND C.STATUS = 'A' AND EXISTS (SELECT '1' FROM OC_SBU_MAPPING D WHERE D.OU_CODE = s.OU_CODE AND D.SBU_CATEGORY_CODE = s.SBU_CATEGORY_CODE AND D.BRAND_CODE = C.BRAND_CODE AND D.STATUS = 'A'))
        qry += " (SELECT  C.DESCRIPTION FROM  OC_BRANDS C WHERE  c.SBU_CODE = m.SBU_CODE and C.BRAND_CODE = s.BRAND_CODE AND c.SBU_CATEGORY_CODE = s.SBU_CATEGORY_CODE )  BRAND_CODE, ";
        qry += " (SELECT  C.DESCRIPTION FROM  OC_PRODUCTS C WHERE  c.SBU_CODE = m.SBU_CODE and C.BRAND_CODE = s.BRAND_CODE AND c.SBU_CATEGORY_CODE = s.SBU_CATEGORY_CODE and c.PRODUCT_ID = s.PRODUCT_ID) product_ID, ";
        qry += " EXPENSE_CODE_BUDGET ||'-' || (select head_description from OC_EXPENSE_MASTER where status='A' and record_type='I' and EXPENSE_CODE_BUDGET=s.EXPENSE_CODE_BUDGET  and HRIS_DEPT_CODE ='" + lblDept.Text + "' ) EXPENSE_CODE_BUDGET, ";

        qry += " SEQ_NO,  PARTICULARS,SPECIFICATIONS,case when BUDGET_APPROVED='Y' then 'Yes' else 'No' end BUDGET_APPROVED, BUDGET_REF_NO,SANCTION_AMOUNT,BUDGET_AMOUNT ,CONSUMED_AMOUNT,BALANCE_AMOUNT,SANCTION_AMOUNT_GST, ";

        qry += " ( select IMIS.SANCTIONS_PKG.TOTAL_BUDGET_AMOUNT(s.ENTITY_CODE , s.OU_CODE ,m.SBU_CODE,s.SBU_CATEGORY_CODE,s.BRAND_CODE,s.PRODUCT_ID ,m.HRIS_DEPT_CODE,m.HRIS_FUNCTION_CODE ,m.FISCAL_YEAR  ,s.EXPENSE_CODE_BUDGET,s.BUDGET_REF_NO,s.emp_code)   from dual) TOTAL_BUDGET_AMOUNT, ";  //TOTAL_BUDGET_AMOUNT BUDGET_AMOUNT_UPTO  BUDGET_CONSUMED_AMOUNT  TOT_AVAILABLE_BUDGET_AMOUNT  TOT_AVAILABLE_BUDGET_AMT_UPTO
        qry += " (select IMIS.SANCTIONS_PKG.BUDGET_AMOUNT_UPTO(s.ENTITY_CODE , s.OU_CODE ,m.SBU_CODE,s.SBU_CATEGORY_CODE,s.BRAND_CODE,s.PRODUCT_ID ,m.HRIS_DEPT_CODE,m.HRIS_FUNCTION_CODE ,m.FISCAL_YEAR  ,s.EXPENSE_CODE_BUDGET,to_date('" + DateTime.Now.ToString("dd/MM/yyyy") + "', 'dd/mm/yyyy'), BUDGET_REF_NO,s.emp_code) BUDGET_AMOUNT_UPTO from dual) BUDGET_AMOUNT_UPTO  ,";
        qry += " (select IMIS.SANCTIONS_PKG.BUDGET_CONSUMED_AMOUNT(s.ENTITY_CODE , s.OU_CODE ,m.SBU_CODE,s.SBU_CATEGORY_CODE,s.BRAND_CODE,s.PRODUCT_ID ,m.HRIS_DEPT_CODE,m.HRIS_FUNCTION_CODE ,m.FISCAL_YEAR  ,s.EXPENSE_CODE_BUDGET,s.BUDGET_REF_NO,s.emp_code )  from dual) BUDGET_CONSUMED_AMOUNT,";
        qry += " (select IMIS.SANCTIONS_PKG.TOT_AVAILABLE_BUDGET_AMOUNT(s.ENTITY_CODE , s.OU_CODE ,m.SBU_CODE,s.SBU_CATEGORY_CODE,s.BRAND_CODE,s.PRODUCT_ID ,m.HRIS_DEPT_CODE,m.HRIS_FUNCTION_CODE ,m.FISCAL_YEAR  ,s.EXPENSE_CODE_BUDGET,s.BUDGET_REF_NO,s.emp_code) TOT_AVAILABLE_BUDGET_AMOUNT from dual) TOT_AVAILABLE_BUDGET_AMOUNT ,";
        qry += " (select IMIS.SANCTIONS_PKG.TOT_AVAILABLE_BUDGET_AMT_UPTO(s.ENTITY_CODE , s.OU_CODE ,m.SBU_CODE,s.SBU_CATEGORY_CODE,s.BRAND_CODE,s.PRODUCT_ID ,m.HRIS_DEPT_CODE,m.HRIS_FUNCTION_CODE ,m.FISCAL_YEAR  ,s.EXPENSE_CODE_BUDGET,to_date('" + DateTime.Now.ToString("dd/MM/yyyy") + "', 'dd/mm/yyyy'), BUDGET_REF_NO,s.emp_code) TOT_AVAILABLE_BUDGET_AMT_UPTO from dual ) TOT_AVAILABLE_BUDGET_AMT_UPTO ";

        qry += " ,s.emp_code from SN_SANCTIONS_DETAILS  s,SN_SANCTIONS m where PARENT_RECID = '" + recid + "' and s. PARENT_RECID =  m.SNS_RECID and nvl(s.status,'A')='A' order by SEQ_NO ";//and m.status in ('N','E')
            ocon = CommonFunc.con(); 
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvDetail.DataSource = ds;
                gvDetail.DataBind();
                gvBudget.DataSource = ds;
                gvBudget.DataBind();
                budgetEmpCode = ds.Tables[0].Rows[0]["emp_code"].ToString();
            }
            //if (ds.Tables[0].Rows.Count >0 && ds.Tables[0].Rows[0]["BUDGET_APPROVED"].ToString() == "No" )
            //{
            //    gvBudget.Visible = false;
            //}
            if (gvDetail.Rows.Count>0 )
            {
                Label l = (Label)gvDetail.FooterRow.FindControl("lblTotal");
                if (l != null)
                {
                    l.Text = lblTotal.Text;
                }
            }
            btnSubmit.Visible = true;

            for (int i = 0; i < gvDetail.Rows.Count; i++)
            {                
                Label lblBUDGET_AMOUNT = (Label)gvDetail.Rows[i].FindControl("lblBUDGET_AMOUNT");
                Label lblBUDGET_AMOUNT_UPTO = (Label)gvDetail.Rows[i].FindControl("lblBUDGET_AMOUNT_UPTO");
                Label lblBUDGET_CONSUMED_AMOUNT = (Label)gvDetail.Rows[i].FindControl("lblBUDGET_CONSUMED_AMOUNT");
                Label lblBALANCE_AMOUNT = (Label)gvDetail.Rows[i].FindControl("lblBALANCE_AMOUNT");
                Label lblBALANCE_AMOUNT_UPTO = (Label)gvDetail.Rows[i].FindControl("lblBALANCE_AMOUNT_UPTO");
                Label lblSId = (Label)gvDetail.Rows[i].FindControl("lblSId");//    lblOU_CODE  lblBUDGET_REF_NO  lblamt
                Label lblOU_CODE1 = (Label)gvDetail.Rows[i].FindControl("lblOU_CODE1");
                Label lblSBU_CATEGORY_CODE = (Label)gvDetail.Rows[i].FindControl("lblSBU_CATEGORY_CODE");
                Label lblBRAND_CODE = (Label)gvDetail.Rows[i].FindControl("lblBRAND_CODE");
                Label lblPRODUCT_ID = (Label)gvDetail.Rows[i].FindControl("lblPRODUCT_ID");
                Label lblBUDGET_REF_NO = (Label)gvDetail.Rows[i].FindControl("lblBUDGET_REF_NO");
                Label lblamt = (Label)gvDetail.Rows[i].FindControl("lblamt");//lblBUDGET_APPROVED lbl1   lblEXPENSE_CODE_BUDGET1
                Label lblBUDGET_APPROVED = (Label)gvDetail.Rows[i].FindControl("lblBUDGET_APPROVED");
                Label lblEXPENSE_CODE_BUDGET1 = (Label)gvDetail.Rows[i].FindControl("lblEXPENSE_CODE_BUDGET1");

                decimal amtupto = 0;

                if (lblBUDGET_APPROVED.Text == "Yes")
                {
                    DataSet ds11 = CommonFunc.GetbudAmountTotal(lblEnt.Text, lblOU_CODE1.Text, lblsb.Text, lblSBU_CATEGORY_CODE.Text, lblBRAND_CODE.Text, lblPRODUCT_ID.Text, lblDept.Text, lblhrisFunc.Text, lblEXPENSE_CODE_BUDGET1.Text, lblFyear.Text, lblBUDGET_REF_NO.Text, budgetEmpCode);
                    if (ds11.Tables[0].Rows.Count > 0)
                    {
                        //string aa = ds11.Tables[0].Rows[0][0].ToString() + " " + ds1.Tables[0].Rows[0][1].ToString() + " " + ds1.Tables[0].Rows[0][2].ToString() + " " + ds1.Tables[0].Rows[0][3].ToString() + " " + ds1.Tables[0].Rows[0][4].ToString();
                        amtupto = Convert.ToDecimal(ds11.Tables[0].Rows[0]["AVAILABLE_AMT_UPTO"].ToString());
                        //CommonFunc.ShowAlert(aa);
                    }
                    ds = CommonFunc.GetUNITWarning(lblEnt.Text, lblsb.Text, lblOU_CODE1.Text);
                    if (ds.Tables[0].Rows[0][0].ToString() == "E")
                    {
                        if (lblamt.Text != "")
                            if (amtupto < Convert.ToDecimal(lblamt.Text))
                            {
                                CommonFunc.ShowAlert("Not allowed. Sanction Amount exceed Error.");

                            }
                    }
                    if (ds.Tables[0].Rows[0][0].ToString() == "W")
                    {
                        if (lblamt.Text != "")
                            if (amtupto < Convert.ToDecimal(lblamt.Text))
                            {
                                CommonFunc.ShowAlert("Warning: Sanction Amount exceeding.");
                            }
                    }
                }
                
            }
    }
    protected void btnEdit_Click(object sender, EventArgs e)
    {
        Response.Redirect("editSanction.aspx?sid=" + recid);
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
       

        ocon = CommonFunc.con(); ocon.Open();
        OracleTransaction trns = ocon.BeginTransaction(); ; OracleCommand cmd; string qry = "";
        try
        {
            //qry = "select max(substr(sanction_no,18)+1) from sn_sanctions where SANCTION_NO not like '%Temp%'";

            qry = "select max(substr(sanction_no,INSTR(sanction_no, '/', -1)+1)+1) from sn_sanctions where SANCTION_NO not like '%Temp%'";
            qry = "select nvl( max(substr(sanction_no,INSTR(sanction_no, '/', -1)+1)+1),1) from sn_sanctions where SANCTION_NO not like '%Temp%' and FISCAL_YEAR ='"+lblFyear.Text+"'";
            cmd = new OracleCommand(qry, ocon,trns);
            string sno = cmd.ExecuteScalar().ToString();
            string[] arr = sno.Split('/');
            int n = Convert.ToInt32(arr[arr.Length - 1]);
            //n = n + 1;
            string sancNo = lblEnt.Text + "/" + lblsb.Text + "/" + lblDept.Text + "/" + lblFyear.Text + "/" + n;
            if (lblStatus.Text == "E")
                sancNo = lblSancNo.Text;
            qry = "update  SN_SANCTIONS set SANCTION_NO='" + sancNo  + "', status='P', LAST_UPD_BY='" + userid + "'  ,LAST_UPD_ON = to_date('" + DateTime.Now.ToString("dd/MM/yyyy") + "', 'dd/mm/yyyy') where SNS_RECID='" + recid + "' ";
            // (SNS_RECID,ENTITY_CODE,SANCTION_NO,SANCTION_DATE,FISCAL_YEAR,SBU_CODE,DEPT_CODE,HRIS_DEPT_CODE,PROJECT,HRIS_FUNCTION_CODE,VERSION_NO,HIERARCHY_CODE,SANCTION_SOUGHT_FOR,TOTAL_AMOUNT,BACKGROUD_INFO,CRITICAL_ISSUES_DETAIL,STATUS,CREATED_BY,CREATED_ON) ";
            if(ocon.State== ConnectionState.Closed)
                ocon.Open();
            cmd = new OracleCommand(qry, ocon,trns);
            cmd.ExecuteNonQuery();
            qry = "update SN_SANCTIONS_DETAILS set  SANCTION_NO='" + sancNo + "' where  PARENT_RECID ='" + recid + "'";
            cmd = new OracleCommand(qry, ocon,trns);
            cmd.ExecuteNonQuery();
            qry = "update SN_SANCTION_APPROVALS set  SANCTION_NO='" + sancNo + "' where  PARENT_RECID ='" + recid + "'";
            cmd = new OracleCommand(qry, ocon, trns);
            cmd.ExecuteNonQuery();
            qry = "update SN_SANCTION_ATTACHMENTS set  SANCTION_NO='" + sancNo + "' where  PARENT_RECID ='" + recid + "'";
            cmd = new OracleCommand(qry, ocon, trns);
            cmd.ExecuteNonQuery();
            // lblBUDGET_AMOUNT  lblBUDGET_AMOUNT_UPTO  lblBUDGET_CONSUMED_AMOUNT  lblBALANCE_AMOUNT  lblBALANCE_AMOUNT_UPTO lblSId
            for(int i=0; i<gvDetail.Rows.Count; i++)
            {
                Label lblBUDGET_AMOUNT = (Label)gvDetail.Rows[i].FindControl("lblBUDGET_AMOUNT");
                Label lblBUDGET_AMOUNT_UPTO = (Label)gvDetail.Rows[i].FindControl("lblBUDGET_AMOUNT_UPTO");
                Label lblBUDGET_CONSUMED_AMOUNT = (Label)gvDetail.Rows[i].FindControl("lblBUDGET_CONSUMED_AMOUNT");
                Label lblBALANCE_AMOUNT = (Label)gvDetail.Rows[i].FindControl("lblBALANCE_AMOUNT");
                Label lblBALANCE_AMOUNT_UPTO = (Label)gvDetail.Rows[i].FindControl("lblBALANCE_AMOUNT_UPTO");
                Label lblSId = (Label)gvDetail.Rows[i].FindControl("lblSId");//    lblOU_CODE  lblBUDGET_REF_NO  lblamt
                Label lblOU_CODE1 = (Label)gvDetail.Rows[i].FindControl("lblOU_CODE1");
                Label lblSBU_CATEGORY_CODE = (Label)gvDetail.Rows[i].FindControl("lblSBU_CATEGORY_CODE");
                Label lblBRAND_CODE = (Label)gvDetail.Rows[i].FindControl("lblBRAND_CODE");
                Label lblPRODUCT_ID = (Label)gvDetail.Rows[i].FindControl("lblPRODUCT_ID");
                Label lblBUDGET_REF_NO = (Label)gvDetail.Rows[i].FindControl("lblBUDGET_REF_NO");
                Label lblamt = (Label)gvDetail.Rows[i].FindControl("lblamt");//lblBUDGET_APPROVED lbl1
                Label lblBUDGET_APPROVED = (Label)gvDetail.Rows[i].FindControl("lblBUDGET_APPROVED");
                Label lbl1 = (Label)gvDetail.Rows[i].FindControl("lblEXPENSE_CODE_BUDGET1");

                string flagROI = "N";
                qry = "  select nvl(CAPITAL_EXPENSE_FLAG,'N') from oc_expense_master where EXPENSE_CODE_BUDGET  = '" + lbl1.Text + "'";
                OracleCommand c1 = new OracleCommand(qry, ocon, trns);
                da = new OracleDataAdapter(c1);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    flagROI = ds.Tables[0].Rows[0][0].ToString();
                }
               
                if (flagROI == "Y")
                {
                     qry = "select nvl(count(SNSAT_RECID),0) from SN_SANCTION_ATTACHMENTS where PARENT_RECID= '" + recid + "' and FILE_TYPE ='ROI'";
                    c1 = new OracleCommand(qry, ocon,trns);
                    da = new OracleDataAdapter(c1);
                    DataSet dsROI = new DataSet();
                    da.Fill(dsROI);
                    if (dsROI.Tables[0].Rows.Count > 0)
                    {
                        if (dsROI.Tables[0].Rows[0][0].ToString() == "0")
                        {
                            CommonFunc.ShowAlert("ROI attachment not found.");                            
                            trns.Rollback();
                            return;
                        }
                    }
                }
                decimal amtupto = 0;
                if (lblBUDGET_APPROVED.Text == "Yes")
                {
                    DataSet ds11 = CommonFunc.GetbudAmountTotal(lblEnt.Text, lblOU_CODE1.Text, lblsb.Text, lblSBU_CATEGORY_CODE.Text, lblBRAND_CODE.Text, lblPRODUCT_ID.Text, lblhrisDept.Text, lblhrisFunc.Text, lbl1.Text, lblFyear.Text, lblBUDGET_REF_NO.Text, budgetEmpCode);
                    if (ds11.Tables[0].Rows.Count > 0)
                    {
                        //string aa = ds11.Tables[0].Rows[0][0].ToString() + " " + ds1.Tables[0].Rows[0][1].ToString() + " " + ds1.Tables[0].Rows[0][2].ToString() + " " + ds1.Tables[0].Rows[0][3].ToString() + " " + ds1.Tables[0].Rows[0][4].ToString();
                        amtupto = Convert.ToDecimal(ds11.Tables[0].Rows[0]["AVAILABLE_AMT_UPTO"].ToString());
                        //CommonFunc.ShowAlert(aa);
                    }
                    ds = CommonFunc.GetUNITWarning(lblEnt.Text, lblsb.Text, lblOU_CODE1.Text);
                    if (ds.Tables[0].Rows[0][0].ToString() == "E")
                    {
                        if (lblamt.Text != "")
                            if (amtupto < Convert.ToDecimal(lblamt.Text))
                            {
                                CommonFunc.ShowAlert("Not allowed. Sanction Amount exceed Error.");
                                trns.Rollback(); return;
                            }
                    }
                    if (ds.Tables[0].Rows[0][0].ToString() == "W")
                    {
                        if (lblamt.Text != "")
                            if (amtupto < Convert.ToDecimal(lblamt.Text))
                            {
                                CommonFunc.ShowAlert("Warning: Sanction Amount exceeding.");

                            }
                    }
                }
                

                qry = "update SN_SANCTIONS_DETAILS set  BUDGET_AMOUNT='" + lblBUDGET_AMOUNT.Text + "', BUDGET_AMOUNT_UPTO='" + lblBUDGET_AMOUNT_UPTO.Text + "' , BALANCE_AMOUNT='" + lblBALANCE_AMOUNT.Text + "', BALANCE_AMOUNT_UPTO='" + lblBALANCE_AMOUNT_UPTO.Text + "',  BUDGET_CONSUMED_AMOUNT='" + lblBUDGET_CONSUMED_AMOUNT.Text + "' where  SNSD_RECID ='" + lblSId.Text + "'";
            cmd = new OracleCommand(qry, ocon, trns);
            cmd.ExecuteNonQuery();

            qry = "update GL_BUDGET_details set CONSUMED_AMOUNT = nvl(CONSUMED_AMOUNT,0) + " + lblamt.Text + " WHERE  ENTITY_CODE='" + lblEnt.Text + "' and   OU_CODE='" + lblOU_CODE1.Text + "' and SBU_CODE='" + lblsb.Text + "'  and SBU_CATEGORY_CODE='" + lblSBU_CATEGORY_CODE.Text + "'  and (BRAND_CODE is null or BRAND_CODE='" + lblBRAND_CODE.Text + "')  and (PRODUCT_ID is null or PRODUCT_ID= '" + lblPRODUCT_ID.Text + "')  ";
            qry += "   and HRIS_DEPT_CODE= '" + lblDept.Text + "' and (PROJECT_CODE is null or PROJECT_CODE= '" + lblhrisFunc.Text + "') and FISCAL_YEAR= '" + lblFyear.Text + "' and EXPENSE_CODE_BUDGET= '" + lbl1.Text + "' and  BUDGET_REF_NO='" + lblBUDGET_REF_NO.Text + "' and FISCAL_PERIOD = CG$FIXED_ASSESTS_PKG.CG$GET_FISCAL_PERIOD('55', trunc(sysdate) ) and( emp_code is null or emp_code in ( select distinct EMP_CODE  from SN_HIERARCHY_DETAIL where PARENT_RECID in (select PARENT_RECID  from SN_HIERARCHY_DETAIL where   EMP_CODE='" + userid + "' and ROLE='I' )))";
            cmd = new OracleCommand(qry, ocon, trns);
            cmd.ExecuteNonQuery();

                //update gl_budget_detil
                //,OU_CODE1,SBU_CATEGORY_CODE1,BRAND_CODE1, productID1, EXPENSE_CODE_BUDGET1

            }

            trns.Commit();
            string toid = gettoMailId();
            string email = Session["email"].ToString(); string flag = "";
            string p = Server.MapPath("~/HtmlTemplate.htm");
            if (toid != "")
                flag = CommonFunc.mailpprove(toid, email, Session["name"].ToString(), recid, p,sancNo);

            if (flag == "Y")
            {
                qry = mailLog(flag, "", "AB", toid, email);
                cmd = new OracleCommand(qry, ocon, trns);
                cmd.ExecuteNonQuery();
            }
            else
            {
                qry = mailLog("N", flag, "AB", toid, email);
                cmd = new OracleCommand(qry, ocon, trns);
                cmd.ExecuteNonQuery();
            }
            ocon.Close();
            CommonFunc.ShowAlertMessage("Record Saved.", "ShowSavedSanctionList.aspx");
        }
        catch (Exception ex)
        {
            trns.Rollback();
            lblmsg.Text = ex.Message;
            CommonFunc.ShowAlert("Error " + ex.Message);
        }
    }


    protected string mailLog(string flag, string message, string empcde, string toid, string email)
    {
        qry = "insert into SN_SANCTION_EMAIL_LOG (SNSEL_RECID,ENTITY_CODE,SANCTION_NO,PARENT_RECID,EMP_CODE,EMAIL_ID,EMAIL_SENT_ON,TO_EMP_CODE,TO_EMAIL_ID,DELIVERY_FLAG,MESSAGE) ";
        qry += " values (portal_RECID.nextval,'" + lblEnt.Text + "','" + lblSancNo.Text + "','" + recid + "','" + userid + "','" + email + "',to_date('" + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + "', 'dd/mm/yyyy hh:mi:ss AM'),'" + empcde + "','" + toid + "','" + flag + "','" + message + "') ";
        return qry;
    }
    protected string gettoMailId()
    {
        int st = 0;
        st = st + 1;
        qry = "select distinct (select email_id from hrm_employee where  emp_code = s.emp_code) mailid from SN_SANCTION_APPROVALS s where PARENT_RECID= '" + recid + "'  and S_NO= " + st;
        //qry = "select case  when s.emp_code like 'A%' then  (select email_id from hrm_employee v, EMP_MAPPING_APPROVAL m where v.emp_code = m.emp_code and m.MAPPING_CODE= s.emp_code ) ";
        //qry += " else (select email_id from hrm_employee vhe where  vhe.emp_code = s.emp_code) end enail_id  from SN_SANCTION_APPROVALS s where PARENT_RECID= '" + recid + "'  and S_NO= " + st;
        ocon = CommonFunc.con();
        if (ocon.State == ConnectionState.Closed)
            ocon.Open();
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
        DataSet ds = new DataSet();
        da.Fill(ds); string toid = "";
        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        {
            if(toid =="")
            {
                toid =  ds.Tables[0].Rows[i][0].ToString() ;
            }
            else
                toid = toid + "," + ds.Tables[0].Rows[i][0].ToString();
        }
        return toid;
    }

    protected void getapp()
    {
        qry = " select  S_NO SNO, (select employee_name from hrm_employee where EMP_CODE= s.EMP_CODE) EmployeeName, SKIPPED Mandatory ,REMARKS from SN_SANCTION_APPROVALS s where sanction_no= '" + lblSancNo.Text + "' and emp_code not like 'A%' order by S_NO";
        ocon = CommonFunc.con();
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvApproval.DataSource = ds;
            gvApproval.DataBind();
        }
        qry = " select (select employee_name from hrm_employee where EMP_CODE= s.EMP_CODE) EmployeeName, to_char(APPROVED_ON,'dd/mm/yyyy') dt from SN_SANCTION_APPROVALS s where sanction_no= '" + lblSancNo.Text + "' and role ='R' and emp_code not like 'A%'   and APPROVED_ON is not null order by S_NO";
        ocon = CommonFunc.con();
        da = new OracleDataAdapter(qry, ocon);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvRevBy.DataSource = ds;
            gvRevBy.DataBind();
        }
        qry = " select (select employee_name from hrm_employee where EMP_CODE= s.EMP_CODE) EmployeeName, to_char(APPROVED_ON,'dd/mm/yyyy') dt from SN_SANCTION_APPROVALS s where sanction_no= '" + lblSancNo.Text + "' and role ='A' and emp_code not like 'A%'  and APPROVED_ON is not null order by S_NO";
        ocon = CommonFunc.con();
        da = new OracleDataAdapter(qry, ocon);
        ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvAppBy.DataSource = ds;
            gvAppBy.DataBind();
        }
    }
    protected void getAttach()
    {
        qry = " select SUBSTR(FILE_NAME,INSTR(FILE_NAME, '_',1,2 )+1 ) FILE_NAME_disp, FILE_NAME from SN_SANCTION_ATTACHMENTS where SANCTION_NO = '" + lblSancNo.Text + "'";
        ocon = CommonFunc.con();
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvAttachment.DataSource = ds;
            gvAttachment.DataBind(); lblAttach.Visible = false;
        }
        else lblAttach.Visible = true;
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        pnlApproval.Visible = true; getapp(); pnlAttachment.Visible = false;
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        pnlAttachment.Visible = true; getAttach(); pnlApproval.Visible = false;
    }
    protected void imgcloseA_Click(object sender, ImageClickEventArgs e)
    {
        pnlApproval.Visible = false;
    }
    protected void imgcloseA0_Click(object sender, ImageClickEventArgs e)
    {
        pnlAttachment.Visible = false;
    }
    protected void gvApproval_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        
    }
    protected void gvAttachment_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string path = e.CommandArgument.ToString();
        string fpath = Server.MapPath("~/SancDocs/") + e.CommandArgument.ToString(); // @"c:/abc/doc/abc1.doc";
        System.IO.FileInfo myDoc = new System.IO.FileInfo(fpath);

        Response.Clear();
        Response.ContentType = "Application/msword";
        Response.AddHeader("content-disposition", "attachment;filename=" + myDoc.Name);
        Response.AddHeader("Content-Length", myDoc.Length.ToString());
        Response.ContentType = "application/octet-stream";

        Response.WriteFile(myDoc.FullName);

        Response.End();
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        try
        {
            ocon = CommonFunc.con();
            qry = "update  SN_SANCTIONS set  status='C', LAST_UPD_BY='" + userid + "'  ,LAST_UPD_ON = to_date('" + DateTime.Now.ToString("dd/MM/yyyy") + "', 'dd/mm/yyyy') where SNS_RECID='" + recid + "' ";
            // (SNS_RECID,ENTITY_CODE,SANCTION_NO,SANCTION_DATE,FISCAL_YEAR,SBU_CODE,DEPT_CODE,HRIS_DEPT_CODE,PROJECT,HRIS_FUNCTION_CODE,VERSION_NO,HIERARCHY_CODE,SANCTION_SOUGHT_FOR,TOTAL_AMOUNT,BACKGROUD_INFO,CRITICAL_ISSUES_DETAIL,STATUS,CREATED_BY,CREATED_ON) ";
            if (ocon.State == ConnectionState.Closed)
                ocon.Open();
            OracleCommand cmd = new OracleCommand(qry, ocon);
            cmd.ExecuteNonQuery();
            ocon.Close();
            CommonFunc.ShowAlertMessage("Record Saved.", "ShowSavedSanctionList.aspx");
        }
        catch (Exception ex)
        {

        }
    }
}