﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MyClass;
using System.Data;
using System.Configuration;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using CustomClass;
using System.Data.OracleClient;

public partial class Home : System.Web.UI.Page
{
    OracleConnection con1 = new OracleConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        string userid = "";
        if (!IsPostBack)
        {
            
        }
        CommonFunc.ShowAlert(Request.QueryString["user"].ToString());
        if (Request.QueryString["user"] != null && Request.QueryString["user"].ToString() != "")
        { userid = Request.QueryString["user"].ToString(); CommonFunc.ShowAlert(""); }
        CommonFunc.ShowAlert(userid);
        if (userid != "")
        {
            //userid = Encrypt("shikha.katiyar");
            //string m = Request.QueryString["user"].ToString();
            string nametext = DecodeFrom64(userid);
            con1 = CommonFunc.con();
            string q = "select TITLE,initcap(employee_name) as employee_name,emp_code,to_char(dob,'mm-dd') dob,(select role from hrm_role r where r.EMP_CODE= h.EMP_CODE) as role,company,EMAIL_ID,imis_login_id,dept_code from hrm_employee h where trim(lower(EMAIL_ID)) = '" + nametext.ToLower() + "@dsgroup.com' and   (Status='C' or Status='P' or Status='N')";
            OracleDataAdapter da = new OracleDataAdapter(q, con1);
            DataSet ds = new DataSet();
            da.Fill(ds);
            //CommonFunc.ShowAlert(nametext);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Session["name"] = ds.Tables[0].Rows[0]["TITLE"].ToString() + " " + ds.Tables[0].Rows[0]["employee_name"].ToString();
                Session["emp_code"] = ds.Tables[0].Rows[0]["emp_code"].ToString();
                Session["dept"] = ds.Tables[0].Rows[0]["dept_code"].ToString();
                Session["email"] = ds.Tables[0].Rows[0]["email_id"].ToString();
                Session["imisid"] = ds.Tables[0].Rows[0]["imis_login_id"].ToString(); ;
                //Session["name"] = ds.Tables[0].Rows[0]["employee_name"].ToString();
                CustomFunc.userid = ds.Tables[0].Rows[0]["emp_code"].ToString(); ;
                q = "select MAPPING_CODE from EMP_MAPPING_APPROVAL where EMP_CODE = '" + ds.Tables[0].Rows[0]["emp_code"].ToString() + "'   ";
                da = new OracleDataAdapter(q, con1);
                DataSet ds1 = new DataSet();
                da.Fill(ds1);
                if (ds1.Tables[0].Rows.Count > 0)
                {
                    Session["emp_code_map"] = ds1.Tables[0].Rows[0]["MAPPING_CODE"].ToString();
                    Session["org_emp_code"] = ds.Tables[0].Rows[0]["emp_code"].ToString();
                }

                if (Request.QueryString["sid"] != null && Request.QueryString["sid"].ToString() != "")
                {
                    string recid = Request.QueryString["sid"].ToString();
                    Response.Redirect("~/SanctionDetails.aspx?sid=" + recid);
                }
                //else
                //    Response.Redirect("~/about.aspx");
            }
            else
            {
                //lblmsg.Text += " No Details Found in sso.";
                //Session["err"] = lblmsg.Text;
                //lblmsg.Visible = true;
                //btnLogin.Visible = false;
                //pnlLogin.Visible = true;
                //pnlUser.Visible = false;
            }
        }
        else if (Session["emp_code"] != null && Session["emp_code"].ToString() != "")
        {
        }
        else
        { //isvaild();
        }

    }

    public string DecodeFrom64(string password)
    {
        System.Text.UTF8Encoding encoder = new System.Text.UTF8Encoding();
        System.Text.Decoder utf8Decode = encoder.GetDecoder();
        byte[] todecode_byte = Convert.FromBase64String(password);
        int charCount = utf8Decode.GetCharCount(todecode_byte, 0, todecode_byte.Length);
        char[] decoded_char = new char[charCount];
        utf8Decode.GetChars(todecode_byte, 0, todecode_byte.Length, decoded_char, 0);
        string result = new String(decoded_char);
        return result;
    }

    private string Decrypt(string cipherText)
    {
        string EncryptionKey = "MAKV2SPBNI99212";
        byte[] cipherBytes = Convert.FromBase64String(cipherText);
        using (Aes encryptor = Aes.Create())
        {
            Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
            encryptor.Key = pdb.GetBytes(32);
            encryptor.IV = pdb.GetBytes(16);
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(cipherBytes, 0, cipherBytes.Length);
                    cs.Close();
                }
                cipherText = Encoding.Unicode.GetString(ms.ToArray());
            }
        }
        return cipherText;
    }


    private string Encrypt(string clearText)
    {
        string EncryptionKey = "MAKV2SPBNI99212";
        byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
        using (Aes encryptor = Aes.Create())
        {
            Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
            encryptor.Key = pdb.GetBytes(32);
            encryptor.IV = pdb.GetBytes(16);
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(clearBytes, 0, clearBytes.Length);
                    cs.Close();
                }
                clearText = Convert.ToBase64String(ms.ToArray());
            }
        }
        return clearText;
    }
    
    protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
        string id = Session["dept"].ToString();
        DropDownList ddlunit = (DropDownList)this.Parent.FindControl(Session["dept"].ToString());
        
        ddlunit.ClearSelection();
        ddlunit.Items.FindByValue(ListBox1.SelectedValue).Selected = true;
        //lstunit.Visible = false;
        //ddlCategory.Items.Clear(); ddlCategory.Items.Add("--Select--");
        //ds = CommonFunc.GetCategory(ddlSBU.SelectedValue, ddlunit.SelectedValue);
        //for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
        //{
        //    ddlCategory.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["SBU_CATEGORY_CODE"].ToString()));
        //}
    }
    protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
    {

    }

    protected void isvaild()
    {
        string domainName = System.Net.NetworkInformation.IPGlobalProperties.GetIPGlobalProperties().DomainName;
        //string nametext = WindowsIdentity.GetCurrent().Name.Split('\\')[1];
        Session["role"] = "";
        //lblmsg.Text = Environment.UserName;
        string nametext = Environment.UserName;
        string fullname = String.Format("{0}@{1}", nametext, domainName);
        //CommonFunc.ShowAlert(nametext);
        con1 = CommonFunc.con();

        string q = "select TITLE,initcap(employee_name) as employee_name,emp_code,to_char(dob,'mm-dd') dob,(select role from hrm_role r where r.EMP_CODE= h.EMP_CODE) as role,company,EMAIL_ID,imis_login_id,dept_code from hrm_employee h where trim(lower(EMAIL_ID)) = '" + nametext.ToLower() + "@dsgroup.com' and   (Status='C' or Status='P' or Status='N')";
        OracleDataAdapter da = new OracleDataAdapter(q, con1);
        DataSet ds = new DataSet();
        da.Fill(ds);
        //CommonFunc.ShowAlert(nametext);
        if (ds.Tables[0].Rows.Count > 0)
            if (ds.Tables[0].Rows.Count > 0)
            {
                Session["name"] = ds.Tables[0].Rows[0]["TITLE"].ToString() + " " + ds.Tables[0].Rows[0]["employee_name"].ToString();
                Session["emp_code"] = ds.Tables[0].Rows[0]["emp_code"].ToString();
                Session["dept"] = ds.Tables[0].Rows[0]["dept_code"].ToString();
                Session["email"] = ds.Tables[0].Rows[0]["email_id"].ToString();
                Session["imisid"] = ds.Tables[0].Rows[0]["imis_login_id"].ToString();
                //Session["name"] = ds.Tables[0].Rows[0]["employee_name"].ToString();
                CustomFunc.userid = ds.Tables[0].Rows[0]["emp_code"].ToString(); ;
                q = "select MAPPING_CODE from EMP_MAPPING_APPROVAL where EMP_CODE = '" + ds.Tables[0].Rows[0]["emp_code"].ToString() + "'   ";
                da = new OracleDataAdapter(q, con1);
                DataSet ds1 = new DataSet();
                da.Fill(ds1);
                if (ds1.Tables[0].Rows.Count > 0)
                {
                    Session["emp_code_map"] = ds1.Tables[0].Rows[0]["MAPPING_CODE"].ToString();
                    Session["org_emp_code"] = ds.Tables[0].Rows[0]["emp_code"].ToString();
                }

                if (Request.QueryString["sid"] != null && Request.QueryString["sid"].ToString() != "")
                {
                    string recid = Request.QueryString["sid"].ToString();
                    Response.Redirect("SanctionDetails.aspx?sid=" + recid);
                }
                //else
                //    Response.Redirect("~/about.aspx");
            }
            else
            {
                //lblmsg.Text += " No Details Found in sso.";
                //Session["err"] = lblmsg.Text;
                //lblmsg.Visible = true;
                //btnLogin.Visible = false;
                //pnlLogin.Visible = true;
                //pnlUser.Visible = false;
            }
    }
}
