﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MyClass;
using System.Data;
using System.Data.OracleClient;

using System.Globalization;
using System.Threading;

public partial class ShowRecallSanctionList : System.Web.UI.Page
{
    OracleConnection ocon = new OracleConnection(); string myQ = "";
    OracleDataAdapter da; DataSet ds; string userid = "", email = "", imisid="", map_userid = "";
    CultureInfo hindi = new CultureInfo("hi-IN");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["emp_code"] != null && Session["emp_code"].ToString() != "")
        {
            userid = Session["emp_code"].ToString();
            email = Session["email"].ToString();
            imisid = Session["imisid"].ToString();
        }

        if (Session["emp_code_map"] != null && Session["emp_code_map"].ToString() != "")
        {
            map_userid = Session["emp_code_map"].ToString();
        }
        
        if (!IsPostBack)
        {
            getdata();
        }
    }

    protected override void InitializeCulture()
    {
        //CultureInfo ci = new CultureInfo("en-IN");
        hindi.NumberFormat.CurrencySymbol = "₹";
        Thread.CurrentThread.CurrentCulture = hindi;

        base.InitializeCulture();
    }
    protected void getdata()
    {
        ocon = CommonFunc.con();
        string qry = "select distinct SNS_RECID, (SELECT LEGAL_NAME FROM OC_ENTITY B where b.ENTITY_CODE = m.ENTITY_CODE)  ENTITY_CODE,m.sANCTION_NO,to_char(m.SANCTION_DATE,'dd/MM/yyyy')SANCTION_DATE,FISCAL_YEAR,m.LAST_UPD_ON, ";
        qry += " (select DESCRIPTION from OC_SBU  where status='A' and SBU_CODE= m.SBU_CODE) SBU_CODE,  (SELECT DEPARTMENT_DESC FROM ALL_DEPARTMENTS where DEPARTMENT_CODE = DEPT_CODE AND COMPANY = 'DS') DEPT_CODE, ";
        qry += " (SELECT  B.FUNC_DESC    FROM PROJECTS A, HRM_FUNCTION B, HRM_MAPPING_DEPT_FUNCTIONS C WHERE A.COMPANY = 'DS' AND A.HRIS_FUNCTION_CODE = B.FUNC_CODE AND A.STATUS  =  'A' AND A.HRIS_FUNCTION_CODE = C.FUNC_CODE  and C.DEPT_CODE= m.DEPT_CODE and A.PROJECT  = m.PROJECT) PROJECT, ";
        //--PROJECT,    --HRIS_FUNCTION_CODE,
        qry += " VERSION_NO,m.HIERARCHY_CODE,SANCTION_SOUGHT_FOR,TOTAL_AMOUNT,BACKGROUD_INFO,CRITICAL_ISSUES_DETAIL,current_status,STATUS,CREATED_BY,CREATED_ON ";
        qry += " From SN_SANCTIONS  m , SN_SANCTION_APPROVALS a  where  m.current_status-1 =  a.S_NO  ";
        qry += "  and  m.HIERARCHY_CODE=   a.  HIERARCHY_CODE  and m.SANCTION_NO = a.SANCTION_NO   and m.ENTITY_CODE = a.ENTITY_CODE    and emp_code='" + userid + "' and status='P' order by m.LAST_UPD_ON";

        if (map_userid != "")
        {
            qry = "select distinct SNS_RECID, (SELECT LEGAL_NAME FROM OC_ENTITY B where b.ENTITY_CODE = m.ENTITY_CODE)  ENTITY_CODE,m.sANCTION_NO,to_char(m.SANCTION_DATE,'dd/MM/yyyy')SANCTION_DATE,FISCAL_YEAR, m.LAST_UPD_ON,";
            qry += " (select DESCRIPTION from OC_SBU  where status='A' and SBU_CODE= m.SBU_CODE) SBU_CODE,  (SELECT DEPARTMENT_DESC FROM ALL_DEPARTMENTS where DEPARTMENT_CODE = DEPT_CODE AND COMPANY = 'DS') DEPT_CODE, ";
            qry += " (SELECT  B.FUNC_DESC    FROM PROJECTS A, HRM_FUNCTION B, HRM_MAPPING_DEPT_FUNCTIONS C WHERE A.COMPANY = 'DS' AND A.HRIS_FUNCTION_CODE = B.FUNC_CODE AND A.STATUS  =  'A' AND A.HRIS_FUNCTION_CODE = C.FUNC_CODE  and C.DEPT_CODE= m.DEPT_CODE and A.PROJECT  = m.PROJECT) PROJECT, ";
            //--PROJECT,    --HRIS_FUNCTION_CODE,
            qry += " VERSION_NO,m.HIERARCHY_CODE,SANCTION_SOUGHT_FOR,TOTAL_AMOUNT,BACKGROUD_INFO,CRITICAL_ISSUES_DETAIL,STATUS,CREATED_BY,CREATED_ON ";
            qry += " From SN_SANCTIONS  m , SN_SANCTION_APPROVALS a  where  m.current_status =  a.S_NO  ";
            qry += "  and  m.HIERARCHY_CODE=   a.  HIERARCHY_CODE  and m.SANCTION_NO = a.SANCTION_NO   and m.ENTITY_CODE = a.ENTITY_CODE    and (emp_code='" + userid + "' or emp_code='" + map_userid + "') and status='R' and approved_by is null order by m.LAST_UPD_ON desc";

        }

        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
        DataSet ds = new DataSet();
        da.Fill(ds);//SNS_RECID  ENTITY_CODE sANCTION_NO SANCTION_DATE SBU_CODE PROJECT TOTAL_AMOUNT
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvData.DataSource = ds;
            gvData.DataBind();
        }
    }
    protected void gvData_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "view")
        {
            Response.Redirect("SanctionFormat.aspx?sid=" + e.CommandArgument.ToString());
        }
        if (e.CommandName == "recall")
        {
            ocon = CommonFunc.con();
            
            string srecid = e.CommandArgument.ToString();
            GridViewRow gvr = ((Control)e.CommandSource).Parent.Parent as GridViewRow;
            Label lblcStatus = (Label)gvr.FindControl("lblcStatus");//lblSanNo
            Label lblSanNo = (Label)gvr.FindControl("lblSanNo");
            if (srecid != "")
            {
                if (ocon.State == ConnectionState.Closed)
                    ocon.Open();
                OracleTransaction trns = ocon.BeginTransaction(); ; OracleCommand cmd;
                try
                {
                    int st = Convert.ToInt16(lblcStatus.Text) - 1;
                    string qry = "update  SN_SANCTIONS set current_status= '"+st+"' , LAST_UPD_BY='" + userid + "'  ,LAST_UPD_ON = to_date('" + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + "', 'dd/mm/yyyy hh24:mi:ss') where SNS_RECID='" + srecid + "' ";
                    cmd = new OracleCommand(qry, ocon,trns);
                    cmd.ExecuteNonQuery();
                    

                    qry = "update SN_SANCTION_APPROVALS set APPROVED_BY= null,APPROVED_ON=null  where PARENT_RECID= '" + srecid + "'  and S_NO= " + st;
                    cmd = new OracleCommand(qry, ocon, trns);
                    cmd.ExecuteNonQuery();

                    qry =" insert into  sn_sanction_info (  SNI_RECID,PARENT_RECID,SANCTION_NO,CREATED_BY,CREATED_ON,SANCTION_INFO) ";
                    qry += " values (  portal_RECID.nextval ,'" + srecid + "','" + lblSanNo.Text + "','" + userid + "',to_date('" + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + "', 'dd/mm/yyyy hh24:mi:ss'),'Recalled') ";
                    cmd = new OracleCommand(qry, ocon, trns);
                    cmd.ExecuteNonQuery();
                    trns.Commit();
                    getdata();
                    string mailid = gettoMailId(lblcStatus.Text, srecid);
                    string path = Server.MapPath("~/HtmlTemplate.htm");
                    CommonFunc.mailtoRecall(mailid, email, lblSanNo.Text,path);
                    
                    CommonFunc.ShowAlert("Recalled sucessfully!!");
                }
                catch (Exception ex)
                {
                    trns.Rollback();
                    CommonFunc.ShowAlert("Some error found.");
                }
                finally { ocon.Close(); }
            }
        }
    }


    protected string gettoMailId(string st,string recid)
    {
        string toid = "";
        try
        {

            string qry = "select   (select email_id from hrm_employee where  emp_code = s.emp_code) mailid,ROLE from SN_SANCTION_APPROVALS s where PARENT_RECID= '" + recid + "'  and S_NO= " + st;
            //qry = "select distinct case  when s.emp_code like 'A%' then  (select email_id from hrm_employee v, EMP_MAPPING_APPROVAL m where v.emp_code = m.emp_code and m.MAPPING_CODE= s.emp_code ) ";
            //qry += " else (select email_id from hrm_employee vhe where  vhe.emp_code = s.emp_code) end enail_id  from SN_SANCTION_APPROVALS s where PARENT_RECID= '" + recid + "'  and S_NO= " + st;
            ocon = CommonFunc.con();
            if (ocon.State == ConnectionState.Closed)
                ocon.Open();
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds); 
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                //lbltoRole.Text = ds.Tables[0].Rows[i][1].ToString();
                if (toid == "")
                    toid = ds.Tables[0].Rows[i][0].ToString();
                else
                    toid = toid + "," + ds.Tables[0].Rows[i][0].ToString();
            }
        }
        catch (Exception ex)
        {
            CommonFunc.ShowAlert("Error " + ex.Message);
        }
        return toid;
    }
}