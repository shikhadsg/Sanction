﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SiteMaster : System.Web.UI.MasterPage
{
    string userid = "", map_userid="",empid="";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["emp_code"] != null && Session["emp_code"].ToString() != "")
        {
            userid = Session["name"].ToString();
            lblName.Text = userid;
            empid = Session["emp_code"].ToString();

            if (empid == "5502624" || empid == "5503394" || empid == "5504477" || empid == "5500994" || empid == "5504105" || empid == "4S00005" || empid == "4S00273" || empid == "4R00131" || empid == "4R00130" || empid == "5501185")
            {
            }
             else
            {
                MenuItem item = NavigationMenu.FindItem("Report");
                //item.Parent.ChildItems.Remove(item); 
                try
                {
                    NavigationMenu.Items.Remove(NavigationMenu.FindItem("Report"));
                }
                catch (Exception ex) { }
            }
            if (Session["emp_code_map"] != null && Session["emp_code_map"].ToString() != "")
            {
                map_userid = Session["emp_code_map"].ToString();
            }
            if (map_userid != "")
            {
            }
            else
            {
                try
                {
                    NavigationMenu.Items.Remove(NavigationMenu.FindItem("View Sanction's"));
                }
                catch (Exception ex) { }
            }
            //else NavigationMenu.Items.Remove(NavigationMenu.FindItem("Reports"));
        }
        else { Server.Transfer("login.aspx"); }
       
    }
    protected void HeadLoginStatus_Click(object sender, EventArgs e)
    {

    }
}
