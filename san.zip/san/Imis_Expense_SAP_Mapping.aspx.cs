﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OracleClient;
using MyClass;
using MyAppClass;

public partial class Imis_Expense_SAP_Mapping : System.Web.UI.Page
{
    OracleConnection ocon = new OracleConnection();
    OracleDataAdapter da; DataSet ds; string userid = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["emp_code"] != null && Session["emp_code"].ToString() != "")
        {
            userid = Session["emp_code"].ToString();
        }
        ocon = CommonFunc.con();
        if (!IsPostBack)
        {
            //if (Session["dept"] != null && Session["dept"].ToString() != "")
            //{
            //    getData(Session["dept"].ToString());
            //}
            //if (Session["emp_code"] != null && Session["emp_code"].ToString() != "")
            //{
            //    userid = Session["emp_code"].ToString();
            //    //getData(userid);
            //    //email = Session["email"].ToString();
            //}
           
            string q = @"SELECT OU_CODE, OU_CODE || '- ' || DESCRIPTION DESCRIPTION FROM OC_OPERATING_UNIT A WHERE  STATUS='A'
           AND EXISTS (SELECT '1' FROM OC_SBU_MAPPING D WHERE  D.OU_CODE = A.OU_CODE	AND D.STATUS = 'A')
           and OU_CODE in (select distinct OU_CODE from  SN_HIERARCHY s where SNH_RECID in (select PARENT_RECID from SN_HIERARCHY_detail where emp_code = '" + userid + "'  ))";

            OracleDataAdapter da = new OracleDataAdapter(q, ocon);
            ds = new DataSet();
            da.Fill(ds);
            //ds = CommonAppFunc.GetUNITbyEmp(ddlEntity.SelectedValue, ddlSBU.SelectedValue, userid); //DataSet ds1 = CommonAppFunc.GetbudRefNo(ddlEntity.SelectedValue, lblFyear.Text);
            ddlUnit.Items.Clear(); ddlUnit.Items.Add(new ListItem("--Select--", "0"));
            for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
            {
                ddlUnit.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["OU_CODE"].ToString()));
            }

            q = "SELECT  DEPT_CODE DEPARTMENT_CODE, DESCRIPTION FROM HRM_DEPARTMENT B WHERE B.STATUS = 'A' AND EXISTS (SELECT 1 FROM HRM_MAPPING_DEPT_FUNCTIONS A WHERE A.DEPT_CODE = B.DEPT_CODE) ";
            q += " and DEPT_CODE in(select distinct dept_code from  SN_HIERARCHY s where SNH_RECID in (select PARENT_RECID from SN_HIERARCHY_detail where emp_code = '" + userid + "' )) order by DESCRIPTION ";
            da = new OracleDataAdapter(q, ocon);
            ds = new DataSet();
            da.Fill(ds);

            ddlDept.Items.Clear(); //ddlDept.Items.Add("--Select--");

            if (ds.Tables[0].Rows.Count > 0)
            {
                for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                {
                    ddlDept.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["DEPARTMENT_CODE"].ToString()));
                }
            }
        }
    }

    protected void getData(string userid1)
    {
        ocon = CommonFunc.con();
        string qry = @"select
distinct
ENTITY_CODE,
OU_CODE,
(SELECT DISTINCT O1.SAP_ENTITY_CODE FROM OC_OPERATING_UNIT O1 WHERE O1.OU_CODE = S.OU_CODE AND ROWNUM=1)  BUKRS,
(SELECT  DISTINCT O2.SAP_OU_CODE FROM OC_OPERATING_UNIT O2 WHERE O2.OU_CODE= S.OU_CODE AND ROWNUM=1) WERKS,
HRIS_DEPT_CODE,
HRIS_FUNCTION_CODE,
EXPENSE_CODE_BUDGET,
(SELECT DISTINCT A1.KOKRS FROM IMIS_EXPENSE_COST_MAPPING A1 WHERE A1.EXPENSE_CODE     = S.EXPENSE_CODE_BUDGET  AND A1.COMPANY = S.OU_CODE  AND ROWNUM < 2)  COST_CENTRE,
(SELECT DISTINCT A2.RFUNDSCTR FROM IMIS_EXPENSE_COST_MAPPING A2 WHERE A2.EXPENSE_CODE = S.EXPENSE_CODE_BUDGET AND A2.COMPANY = S.OU_CODE AND A2.DEPT_CODE = S.HRIS_DEPT_CODE AND ROWNUM < 2)  FUND_CENTRE,
(SELECT  DISTINCT A3.RCMMTITEM FROM IMIS_EXPENSE_COST_MAPPING A3 WHERE A3.EXPENSE_CODE = S.EXPENSE_CODE_BUDGET AND A3.COMPANY = S.OU_CODE AND A3.DEPT_CODE = S.HRIS_DEPT_CODE  AND ROWNUM < 2)  COMMITMENT_ITEM
FROM GL_BUDGET_DETAILS S
 WHERE FISCAL_YEAR >= 2022
 AND   EXISTS (SELECT  '1' FROM IMIS_EXPENSE_COST_MAPPING A4
            WHERE A4.EXPENSE_CODE     = S.EXPENSE_CODE_BUDGET
               AND A4.COMPANY = S.OU_CODE
            )
            and ou_code in(select distinct OU_CODE from  SN_HIERARCHY s where SNH_RECID in (select PARENT_RECID from SN_HIERARCHY_detail where emp_code='"+userid+"'";
        qry+=" and role='I'   ))  ";

       
        if (ddlUnit.SelectedIndex > 0)
        {
            qry += " and  ou_code in ('" + ddlUnit.SelectedValue + "') ";
        }
        if (ddlDept.SelectedIndex >= 0)
        {
            qry += " and dept_code in ('" + ddlDept.SelectedValue + "') ";
        }
        qry += " order by 1, 4";
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
        DataSet ds = new DataSet();
        da.Fill(ds);
        gvData.Visible = false;
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvData.DataSource = ds;
            gvData.DataBind();
            gvData.Visible = true;
        }
        qry = @"select
distinct
ENTITY_CODE,
OU_CODE,
(SELECT DISTINCT O1.SAP_ENTITY_CODE FROM OC_OPERATING_UNIT O1 WHERE O1.OU_CODE = S.OU_CODE AND ROWNUM=1)  BUKRS,
(SELECT  DISTINCT O2.SAP_OU_CODE FROM OC_OPERATING_UNIT O2 WHERE O2.OU_CODE= S.OU_CODE AND ROWNUM=1) WERKS,
HRIS_DEPT_CODE,
HRIS_FUNCTION_CODE,
EXPENSE_CODE_BUDGET,
(SELECT DISTINCT A1.KOKRS FROM IMIS_EXPENSE_COST_MAPPING A1 WHERE A1.EXPENSE_CODE     = S.EXPENSE_CODE_BUDGET  AND A1.COMPANY = S.OU_CODE  AND ROWNUM < 2)  COST_CENTRE,
(SELECT DISTINCT A2.RFUNDSCTR FROM IMIS_EXPENSE_COST_MAPPING A2 WHERE A2.EXPENSE_CODE = S.EXPENSE_CODE_BUDGET AND A2.COMPANY = S.OU_CODE AND A2.DEPT_CODE = S.HRIS_DEPT_CODE AND ROWNUM < 2) FUND_CENTRE,
(SELECT  DISTINCT A3.RCMMTITEM FROM IMIS_EXPENSE_COST_MAPPING A3 WHERE A3.EXPENSE_CODE = S.EXPENSE_CODE_BUDGET AND A3.COMPANY = S.OU_CODE AND A3.DEPT_CODE = S.HRIS_DEPT_CODE  AND ROWNUM < 2) COMMITMENT_ITEM
FROM GL_BUDGET_DETAILS S
 WHERE FISCAL_YEAR >= 2022
 AND  NOT EXISTS (SELECT  '1' FROM IMIS_EXPENSE_COST_MAPPING A4
            WHERE A4.EXPENSE_CODE     = S.EXPENSE_CODE_BUDGET
               AND A4.COMPANY         = S.OU_CODE
            )
            and ou_code in(select distinct OU_CODE from  SN_HIERARCHY s where SNH_RECID in (select PARENT_RECID from SN_HIERARCHY_detail where emp_code='"+userid+"'";
        qry += " and role='I'   ))  ";
       
        if (ddlUnit.SelectedIndex > 0)
        {
            qry += " and  ou_code in ('" + ddlUnit.SelectedValue + "') ";
        }
        if (ddlDept.SelectedIndex >= 0)
        {
            qry += " and dept_code in ('" + ddlDept.SelectedValue + "') ";
        }
        qry += " order by 1, 4";
        da = new OracleDataAdapter(qry, ocon);
        ds = new DataSet();
        da.Fill(ds);
        gvApp.Visible = false;
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvApp.DataSource = ds;
            gvApp.DataBind();
            gvApp.Visible = true;
        }
    }
    protected void gvData_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "show")
        {
            string id = e.CommandArgument.ToString();
            int k = id.IndexOf(',');
            string ecode = id.Substring(0, k);
            string hcode = id.Substring(k+1);

            ocon = CommonFunc.con();
            string qry = "select SNHD_RECID, (select LEGAL_NAME from OC_ENTITY where ENTITY_CODE= s.ENTITY_CODE) ENTITY_CODE1,ENTITY_CODE,HIERARCHY_CODE,S_NO, (select employee_name from hrm_employee where EMP_CODE= s.EMP_CODE) EMP_CODE, ";
            qry += " case when  MANDATORY= 'Y' then 'Yes' else 'No' end MANDATORY, case when  ROLE= 'I' then 'Initiator' when  ROLE= 'R' then 'Reviewer' else 'Approver' end ROLE  from SN_HIERARCHY_DETAIL s where  PARENT_RECID='" + hcode + "' order by S_NO";
            OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvDetail.DataSource = ds;
                gvDetail.DataBind();
                gvDetail.Visible = true;
            }
            else
                gvDetail.Visible = false;
        }
        if (e.CommandName == "select")
        {
            string id = e.CommandArgument.ToString();
            Session["hid"] = id.ToString();
            GridViewRow row = (GridViewRow)((LinkButton)e.CommandSource).NamingContainer;
            row.BackColor = System.Drawing.Color.Yellow;
            CommonFunc.ShowAlert("Hierarchy Selected.");
        }
    }

    protected void ddlUnit_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlUnit.SelectedIndex > 0)
        {
            //ds = CommonAppFunc.GetDeptbyEmpUnit(userid, ddlUnit.SelectedValue);

            string qry = "SELECT  DEPT_CODE DEPARTMENT_CODE, DESCRIPTION FROM HRM_DEPARTMENT B WHERE B.STATUS = 'A' AND EXISTS (SELECT 1 FROM HRM_MAPPING_DEPT_FUNCTIONS A WHERE A.DEPT_CODE = B.DEPT_CODE) ";
            qry += " and DEPT_CODE in(select distinct dept_code from  SN_HIERARCHY s where SNH_RECID in (select PARENT_RECID from SN_HIERARCHY_detail where emp_code = '"+userid+"' )) order by DESCRIPTION ";
            da = new OracleDataAdapter(qry, ocon);
            ds = new DataSet();
            da.Fill(ds);

            ddlDept.Items.Clear(); //ddlDept.Items.Add("--Select--");

            if (ds.Tables[0].Rows.Count > 0)
            {
                for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                {
                    ddlDept.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["DEPARTMENT_CODE"].ToString()));
                }
            }
            else
            {
                ds = CommonAppFunc.GetDeptOthers();
                ddlDept.Items.Clear();
                for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                {
                    ddlDept.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["DEPARTMENT_CODE"].ToString()));
                }
            }

            ds = CommonAppFunc.GetUNITdetails(ddlUnit.SelectedValue, userid); //OU_CODE,ENTITY_CODE,SBU_CODE,SBU_CATEGORY_CODE
            if (ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = ds.Tables[0].Rows[0];
                //ddlEntity.Items.FindByValue(dr["ENTITY_CODE"].ToString()).Selected = true;
                //ddlSBU.Items.Clear();
                //ddlSBU.Items.Add("--Select--");
                //DataSet ds1ds = CommonAppFunc.GetSBU(dr["ENTITY_CODE"].ToString());
                //for (int k = 0; k < ds1ds.Tables[0].Rows.Count; k++)
                //{
                //    ddlSBU.Items.Add(new ListItem(ds1ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds1ds.Tables[0].Rows[k]["SBU_CODE"].ToString()));
                //}
                //ddlSBU.Items.FindByValue(dr["SBU_CODE"].ToString()).Selected = true;
              
                ds = CommonAppFunc.GetDeptbyEmpUnit(userid, ddlUnit.SelectedValue);
                ddlDept.Items.Clear(); //ddlDept.Items.Add("--Select--");

                if (ds.Tables[0].Rows.Count > 0)
                {
                    for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                    {
                        ddlDept.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["DEPARTMENT_CODE"].ToString()));
                    }
                }
                else
                {
                    ds = CommonAppFunc.GetDeptOthers();
                    ddlDept.Items.Clear();
                    for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                    {
                        ddlDept.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["DEPARTMENT_CODE"].ToString()));
                    }
                }

                if (userid == "2W00769" && ddlUnit.SelectedValue == "4R")
                {
                    ds = CommonAppFunc.GetDeptAll();


                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        ddlDept.Items.Clear();
                        for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                        {
                            ddlDept.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["DEPARTMENT_CODE"].ToString()));
                        }
                    }
                }
                else if (userid == "2W00769" && ddlUnit.SelectedValue != "4R")
                {
                    ds = CommonAppFunc.GetDeptOthers1();
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        ddlDept.Items.Clear();
                        for (int k = 0; k < ds.Tables[0].Rows.Count; k++)
                        {
                            ddlDept.Items.Add(new ListItem(ds.Tables[0].Rows[k]["DESCRIPTION"].ToString(), ds.Tables[0].Rows[k]["DEPARTMENT_CODE"].ToString()));
                        }
                    }
                }
            }
        }
    }

   

   
    protected void btnCreate_Click(object sender, EventArgs e)
    {
        getData(userid);
    }
}
    
