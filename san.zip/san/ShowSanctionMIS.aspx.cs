﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MyClass;
using System.Data;
using System.Data.OracleClient;
using System.Globalization;
using System.Threading;

public partial class ShowSanctionMIS : System.Web.UI.Page
{
    OracleConnection ocon = new OracleConnection(); string myQ = "";
    OracleDataAdapter da; DataSet ds; string userid = "";
    CultureInfo hindi = new CultureInfo("hi-IN");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["emp_code"] != null && Session["emp_code"].ToString() != "")
        {
            userid = Session["emp_code"].ToString();
            //email = Session["email"].ToString();
        }
        else
        {
            Response.Redirect("mislogin.aspx");
        }
        if (!IsPostBack)
        {
            getdata();

            
        }
    }
    protected override void InitializeCulture()
    {
        //CultureInfo ci = new CultureInfo("en-IN");
        hindi.NumberFormat.CurrencySymbol = "₹";
        Thread.CurrentThread.CurrentCulture = hindi;

        base.InitializeCulture();
    }

    protected void getdata()
    {
        ocon = CommonFunc.con();
        string qry = "select SNS_RECID, (SELECT LEGAL_NAME FROM OC_ENTITY B where b.ENTITY_CODE = m.ENTITY_CODE)  ENTITY_CODE,  ";
        qry = "select distinct SNS_RECID, (SELECT LEGAL_NAME FROM OC_ENTITY B where b.ENTITY_CODE = m.ENTITY_CODE)  ENTITY_CODE, ";
        qry += " m.sANCTION_NO, d.BRAND_CODE, d.EXPENSE_CODE_BUDGET ,d.PRODUCT_ID,";
        qry += " m.current_status, case m.status when 'P' then 'Yet To be Aprroved by ' ||(select (select title|| ' ' || employee_name from hrm_employee where emp_code=a.emp_code) emp_code from SN_SANCTION_APPROVALS a  where  m.current_status =  a.S_NO and a.PARENT_RECID= m.SNS_RECID and approved_by is null and rownum=1) else '' end curr_status, ";
        qry += " to_char(m.SANCTION_DATE,'dd/MM/yyyy')SANCTION_DATE, current_status, ";//'Yet To be Aprrov by ' ||(select (select title|| ' ' || employee_name from hrm_employee where emp_code=a.emp_code) emp_code from SN_SANCTION_APPROVALS a  where  m.current_status =  a.S_NO and a.PARENT_RECID= m.SNS_RECID) curr_status, 
        qry += " FISCAL_YEAR,  (select DESCRIPTION from OC_SBU  where status='A' and SBU_CODE= m.SBU_CODE) SBU_CODE, ";
        qry += " (SELECT DEPARTMENT_DESC FROM ALL_DEPARTMENTS where DEPARTMENT_CODE = DEPT_CODE AND COMPANY = 'DS') DEPT_CODE, ";
        qry += " (SELECT  B.FUNC_DESC    FROM PROJECTS A, HRM_FUNCTION B, HRM_MAPPING_DEPT_FUNCTIONS C WHERE A.COMPANY = 'DS' AND A.HRIS_FUNCTION_CODE = B.FUNC_CODE AND A.STATUS  =  'A' AND A.HRIS_FUNCTION_CODE = C.FUNC_CODE  and C.DEPT_CODE= m.DEPT_CODE and A.PROJECT  = m.PROJECT) PROJECT, ";
        qry += " m.VERSION_NO,m.HIERARCHY_CODE,m.SANCTION_SOUGHT_FOR,m.TOTAL_AMOUNT,m.BACKGROUD_INFO,m.CRITICAL_ISSUES_DETAIL,m.STATUS,m.CREATED_BY,m.CREATED_ON, case m.status when 'P' then 'In Process' when 'A' then 'Approved' when 'E' then 'Re-Intiated' when 'R' then 'Rejected' end status1 ";
        qry += " From SN_SANCTIONS  m, SN_SANCTION_APPROVALS a, SN_SANCTIONS_details d where  (m.ENTITY_CODE='DSL' and  m.DEPT_CODE= 'MKT' ) and m.status in ('P','A','E','R') and a.PARENT_RECID= m.SNS_RECID  and d.PARENT_RECID= m.SNS_RECID ";
        DataSet ds = new DataSet();
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
        da.Fill(ds);//SNS_RECID  ENTITY_CODE sANCTION_NO SANCTION_DATE SBU_CODE PROJECT TOTAL_AMOUNT
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvData.DataSource = ds;
            gvData.DataBind();
        }

        string q = "select emp_code,employee_name from hrm_employee where dept_code='MKT'  and status ='C' and company not in ('4S','4R')   order by employee_name";
        ds = new DataSet();
         da = new OracleDataAdapter(q, ocon);
        da.Fill(ds);//SNS_RECID  ENTITY_CODE sANCTION_NO SANCTION_DATE SBU_CODE PROJECT TOTAL_AMOUNT
        if (ds.Tables[0].Rows.Count > 0)
        {
            ddlEmp.Items.Add("Select");
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                ddlEmp.Items.Add(new ListItem(ds.Tables[0].Rows[i][1].ToString(), ds.Tables[0].Rows[i][0].ToString()));
            }
        }

        ddlYear.Items.Clear();
        ddlYear.Items.Add("Select");
        for (int i = 2018; i <= DateTime.Now.Year; i++)
        {
            ddlYear.Items.Add(new ListItem(i.ToString(),i.ToString()));
        }

    }
    protected void gvData_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "view")
        {
            Response.Redirect("SanctionFormat.aspx?sid=" + e.CommandArgument.ToString());
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        ocon = CommonFunc.con();
        string qry = "select SNS_RECID, (SELECT LEGAL_NAME FROM OC_ENTITY B where b.ENTITY_CODE = m.ENTITY_CODE)  ENTITY_CODE,  ";
        qry = "select distinct SNS_RECID, (SELECT LEGAL_NAME FROM OC_ENTITY B where b.ENTITY_CODE = m.ENTITY_CODE)  ENTITY_CODE, ";
        qry += " m.sANCTION_NO, d.BRAND_CODE, d.EXPENSE_CODE_BUDGET ,d.PRODUCT_ID,";
        qry += " m.current_status, case m.status when 'P' then 'Yet To be Aprroved by ' ||(select (select title|| ' ' || employee_name from hrm_employee where emp_code=a.emp_code) emp_code from SN_SANCTION_APPROVALS a  where  m.current_status =  a.S_NO and a.PARENT_RECID= m.SNS_RECID and approved_by is null and rownum=1) else '' end curr_status, ";
        qry += " to_char(m.SANCTION_DATE,'dd/MM/yyyy')SANCTION_DATE, current_status, ";//'Yet To be Aprrov by ' ||(select (select title|| ' ' || employee_name from hrm_employee where emp_code=a.emp_code) emp_code from SN_SANCTION_APPROVALS a  where  m.current_status =  a.S_NO and a.PARENT_RECID= m.SNS_RECID) curr_status, 
        qry += " FISCAL_YEAR,  (select DESCRIPTION from OC_SBU  where status='A' and SBU_CODE= m.SBU_CODE) SBU_CODE, ";
        qry += " (SELECT DEPARTMENT_DESC FROM ALL_DEPARTMENTS where DEPARTMENT_CODE = DEPT_CODE AND COMPANY = 'DS') DEPT_CODE, ";
        qry += " (SELECT  B.FUNC_DESC    FROM PROJECTS A, HRM_FUNCTION B, HRM_MAPPING_DEPT_FUNCTIONS C WHERE A.COMPANY = 'DS' AND A.HRIS_FUNCTION_CODE = B.FUNC_CODE AND A.STATUS  =  'A' AND A.HRIS_FUNCTION_CODE = C.FUNC_CODE  and C.DEPT_CODE= m.DEPT_CODE and A.PROJECT  = m.PROJECT) PROJECT, ";
        qry += " m.VERSION_NO,m.HIERARCHY_CODE,m.SANCTION_SOUGHT_FOR,m.TOTAL_AMOUNT,m.BACKGROUD_INFO,m.CRITICAL_ISSUES_DETAIL,m.STATUS,m.CREATED_BY,m.CREATED_ON, case m.status when 'P' then 'In Process' when 'A' then 'Approved' when 'E' then 'Re-Intiated' when 'R' then 'Rejected' end status1 ";
        qry += " From SN_SANCTIONS  m, SN_SANCTION_APPROVALS a, SN_SANCTIONS_details d where  ((m.ENTITY_CODE='"+ ddlEntity.SelectedValue+"') and  m.DEPT_CODE= 'MKT' ) and m.status in ('P','A','E','R') and a.PARENT_RECID= m.SNS_RECID  and d.PARENT_RECID= m.SNS_RECID ";
        if (txtSanc.Text != "")
        {
            qry += " and m.sANCTION_NO like '%" + txtSanc.Text + "%' ";
        }
        if (txtAmtFrom.Text != "")
        {
            qry += " and m.TOTAL_AMOUNT >= '" + txtAmtFrom.Text + "' ";
        }
        if (txtAmtTo.Text != "")
        {
            qry += " and m.TOTAL_AMOUNT <= '" + txtAmtTo.Text + "' ";
        }
        if (ddlmonth.SelectedIndex >0)
        {
            qry += " and to_char(m.SANCTION_DATE,'MM') = '" + ddlmonth.SelectedValue + "' ";
        }
        if (ddlYear.SelectedIndex > 0)
        {
            qry += " and to_char(m.SANCTION_DATE,'YYYY') = '" + ddlYear.SelectedValue + "' ";
        }
        if (ddlEmp.SelectedIndex > 0)
        {
            qry += " and m.CREATED_BY = '" + ddlEmp.SelectedValue + "' ";
        }
        qry += " order by to_date(SANCTION_DATE,'dd/MM/yyyy') desc";

        DataSet ds = new DataSet();
        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
        da.Fill(ds);//SNS_RECID  ENTITY_CODE sANCTION_NO SANCTION_DATE SBU_CODE PROJECT TOTAL_AMOUNT
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvData.DataSource = ds;
            gvData.DataBind();
            gvData.Visible = true;
        }
        else
        {
            
            gvData.Visible = false;
            CommonFunc.ShowAlert("No Record Find");
        }
    }
}