﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MyClass;
using System.Data;
using System.Data.OracleClient;

using System.Globalization;
using System.Threading;

public partial class ShowListRuchie : System.Web.UI.Page
{
    OracleConnection ocon = new OracleConnection(); string myQ = "";
    OracleDataAdapter da; DataSet ds; string userid = "", map_userid="";
    CultureInfo hindi = new CultureInfo("hi-IN");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["emp_code"] != null && Session["emp_code"].ToString() != "")
        {
            userid = Session["emp_code"].ToString();
        }
        if (Session["emp_code_map"] != null && Session["emp_code_map"].ToString() != "")
        {
            map_userid = Session["emp_code_map"].ToString();
        }
        
        if (!IsPostBack)
        {
            if (userid == "4O01169" || userid == "5501189")
                getdata();
        }
    }

    protected override void InitializeCulture()
    {
        //CultureInfo ci = new CultureInfo("en-IN");
        hindi.NumberFormat.CurrencySymbol = "₹";
        Thread.CurrentThread.CurrentCulture = hindi;

        base.InitializeCulture();
    }
    protected void getdata()
    {
        ocon = CommonFunc.con();
        string qry = "select distinct SNS_RECID, (SELECT LEGAL_NAME FROM OC_ENTITY B where b.ENTITY_CODE = m.ENTITY_CODE)  ENTITY_CODE,m.sANCTION_NO,to_char(m.SANCTION_DATE,'dd/MM/yyyy')SANCTION_DATE,FISCAL_YEAR, ";
        qry += " (select DESCRIPTION from OC_SBU  where status='A' and SBU_CODE= m.SBU_CODE) SBU_CODE,  (SELECT DEPARTMENT_DESC FROM ALL_DEPARTMENTS where DEPARTMENT_CODE = DEPT_CODE AND COMPANY = 'DS') DEPT_CODE, ";
        qry += " (SELECT  B.FUNC_DESC    FROM PROJECTS A, HRM_FUNCTION B, HRM_MAPPING_DEPT_FUNCTIONS C WHERE A.COMPANY = 'DS' AND A.HRIS_FUNCTION_CODE = B.FUNC_CODE AND A.STATUS  =  'A' AND A.HRIS_FUNCTION_CODE = C.FUNC_CODE  and C.DEPT_CODE= m.DEPT_CODE and A.PROJECT  = m.PROJECT) PROJECT, ";
        //--PROJECT,    --HRIS_FUNCTION_CODE,
        qry += " VERSION_NO,m.HIERARCHY_CODE,SANCTION_SOUGHT_FOR,TOTAL_AMOUNT,BACKGROUD_INFO,CRITICAL_ISSUES_DETAIL,STATUS,CREATED_BY,CREATED_ON,(select employee_name from hrm_employee where emp_code= m.CREATED_BY) nm ";
        qry += " From SN_SANCTIONS  m , SN_SANCTION_APPROVALS a  where  m.current_status =  a.S_NO  ";
        qry += "  and  m.HIERARCHY_CODE=   a.  HIERARCHY_CODE  and m.SANCTION_NO = a.SANCTION_NO   and m.ENTITY_CODE = a.ENTITY_CODE    and emp_code='4O01169' and status='P' and approved_by is not null order by CREATED_ON desc";

        //if (map_userid != "")
        //{
        //    qry = "select distinct SNS_RECID, (SELECT LEGAL_NAME FROM OC_ENTITY B where b.ENTITY_CODE = m.ENTITY_CODE)  ENTITY_CODE,m.sANCTION_NO,to_char(m.SANCTION_DATE,'dd/MM/yyyy')SANCTION_DATE,FISCAL_YEAR, ";
        //    qry += " (select DESCRIPTION from OC_SBU  where status='A' and SBU_CODE= m.SBU_CODE) SBU_CODE,  (SELECT DEPARTMENT_DESC FROM ALL_DEPARTMENTS where DEPARTMENT_CODE = DEPT_CODE AND COMPANY = 'DS') DEPT_CODE, ";
        //    qry += " (SELECT  B.FUNC_DESC    FROM PROJECTS A, HRM_FUNCTION B, HRM_MAPPING_DEPT_FUNCTIONS C WHERE A.COMPANY = 'DS' AND A.HRIS_FUNCTION_CODE = B.FUNC_CODE AND A.STATUS  =  'A' AND A.HRIS_FUNCTION_CODE = C.FUNC_CODE  and C.DEPT_CODE= m.DEPT_CODE and A.PROJECT  = m.PROJECT) PROJECT, ";
        //    //--PROJECT,    --HRIS_FUNCTION_CODE,
        //    qry += " VERSION_NO,m.HIERARCHY_CODE,SANCTION_SOUGHT_FOR,TOTAL_AMOUNT,BACKGROUD_INFO,CRITICAL_ISSUES_DETAIL,STATUS,CREATED_BY,CREATED_ON ";
        //    qry += " From SN_SANCTIONS  m , SN_SANCTION_APPROVALS a  where  m.current_status =  a.S_NO  ";
        //    qry += "  and  m.HIERARCHY_CODE=   a.  HIERARCHY_CODE  and m.SANCTION_NO = a.SANCTION_NO   and m.ENTITY_CODE = a.ENTITY_CODE    and (emp_code='4O01162' ) and status='P' and approved_by is null order by m.SANCTION_NO";

        //}

        OracleDataAdapter da = new OracleDataAdapter(qry, ocon);
        DataSet ds = new DataSet();
        da.Fill(ds);//SNS_RECID  ENTITY_CODE sANCTION_NO SANCTION_DATE SBU_CODE PROJECT TOTAL_AMOUNT
        if (ds.Tables[0].Rows.Count > 0)
        {
            gvData.DataSource = ds;
            gvData.DataBind();
        }
    }
    protected void gvData_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "view")
        {
            Response.Redirect("SanctionDetails.aspx?sid=" + e.CommandArgument.ToString());
        }
    }
}